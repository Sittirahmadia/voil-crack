package net.fabricmc.fabric.utils.render;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.systems.module.impl.render.SwingAnimation;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public class ItemRenderUtil {
    public static float start;
    public static float end;
    public static float current;
    public static double translateX;
    public static double translateY;
    public static double translateZ;
    public static float rotateX;
    public static float rotateY;
    public static float rotateZ;
    public static float scale;
    private static long lastFrameTime;

    public static void init() {
        end = start = -90.0f;
        current = start;
    }

    public static void onUpdate() {
        if (ClientMain.mc.field_1724.method_6047().method_7909() instanceof class_1829 && ClientMain.mc.field_1690.field_1886.method_1436() && !ClientMain.mc.field_1724.method_6039()) {
            if (ClientMain.mc.field_1692 != null) {
                ClientMain.mc.field_1761.method_2918((class_1657)ClientMain.mc.field_1724, ClientMain.mc.field_1692);
            }
            ItemRenderUtil.swing();
        }
    }

    public static void render(class_1799 stack, class_4587 matrices) {
        long currentTime = System.currentTimeMillis();
        long elapsedTime = currentTime - lastFrameTime;
        lastFrameTime = currentTime;
        float swingIncrement = 200.0f;
        float swingProgress = swingIncrement * ((float)elapsedTime / 1000.0f);
        if (current > end) {
            current -= swingProgress;
        } else if (current < end) {
            current += swingProgress;
        }
        if (end == -130.0f && current <= end) {
            end = start;
        }
        if (end == start && current >= end) {
            current = end;
        }
        try {
            if (ModuleManager.INSTANCE.getModuleByClass(SwingAnimation.class).isEnabled()) {
                matrices.method_22904(translateX, translateY, translateZ);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(rotateY));
                matrices.method_22907(class_7833.field_40718.rotationDegrees(rotateZ));
                matrices.method_22907(class_7833.field_40714.rotationDegrees(current));
                matrices.method_22904(0.0, 0.6, 0.7);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void swing() {
        if (ModuleManager.INSTANCE.getModuleByClass(SwingAnimation.class).isEnabled()) {
            end = -130.0f;
        } else {
            ClientMain.mc.field_1724.method_6104(ClientMain.mc.field_1724.method_6058());
        }
    }

    public static boolean isValid(class_1799 stack) {
        return stack.method_7909() instanceof class_1829;
    }

    public static void setTranslation(double x, double y, double z) {
        translateX = x;
        translateY = y;
        translateZ = z;
    }

    public static void setRotation(float x, float y, float z) {
        rotateX = x;
        rotateY = y;
        rotateZ = z;
    }

    public static void setScale(float newScale) {
        scale = newScale;
    }

    static {
        translateX = 0.4;
        translateY = -0.2;
        translateZ = -0.1;
        rotateX = 0.0f;
        rotateY = 85.0f;
        rotateZ = -17.0f;
        scale = 0.68f;
        lastFrameTime = 0L;
    }
}
