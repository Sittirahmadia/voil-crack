package net.fabricmc.fabric.utils.render;

import net.minecraft.class_332;
import net.minecraft.class_4587;
import org.joml.Matrix4f;

public class RenderHelper {
    public static Matrix4f projectionMatrix = new Matrix4f();
    public static Matrix4f modelViewMatrix = new Matrix4f();
    public static Matrix4f positionMatrix = new Matrix4f();
    public static class_332 context;
    public static class_4587 matrixStack;

    public static Matrix4f getProjectionMatrix() {
        return projectionMatrix;
    }

    public static Matrix4f getModelViewMatrix() {
        return modelViewMatrix;
    }

    public static Matrix4f getPositionMatrix() {
        return positionMatrix;
    }

    public static class_332 getContext() {
        return context;
    }

    public static void setContext(class_332 context) {
        RenderHelper.context = context;
    }

    public static class_4587 getMatrixStack() {
        return matrixStack;
    }

    public static void setMatrixStack(class_4587 matrixStack) {
        RenderHelper.matrixStack = matrixStack;
    }

    public static void setProjectionMatrix(Matrix4f projectionMatrix) {
        RenderHelper.projectionMatrix = projectionMatrix;
    }

    public static void setModelViewMatrix(Matrix4f modelViewMatrix) {
        RenderHelper.modelViewMatrix = modelViewMatrix;
    }

    public static void setPositionMatrix(Matrix4f positionMatrix) {
        RenderHelper.positionMatrix = positionMatrix;
    }
}
