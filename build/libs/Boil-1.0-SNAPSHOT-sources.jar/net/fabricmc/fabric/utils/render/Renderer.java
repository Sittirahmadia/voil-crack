package net.fabricmc.fabric.utils.render;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.systems.module.impl.render.SwingAnimation;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_4587;
import net.minecraft.class_7833;

public class Renderer {
    public static float start;
    public static float end;
    public static float current;
    public static boolean override;
    private static long lastFrameTime;

    public static void init() {
        end = start = -90.0f;
        current = start;
    }

    public static void onUpdate() {
        if (ClientMain.mc.field_1724.method_6047().method_7909() instanceof class_1829 && ClientMain.mc.field_1690.field_1886.method_1436() && !ClientMain.mc.field_1724.method_6039()) {
            if (ClientMain.mc.field_1692 != null) {
                ClientMain.mc.field_1761.method_2918((class_1657)ClientMain.mc.field_1724, ClientMain.mc.field_1692);
            }
            Renderer.swing();
        }
    }

    public static void render(class_1799 stack, class_4587 matrices) {
        long currentTime = System.currentTimeMillis();
        long elapsedTime = currentTime - lastFrameTime;
        lastFrameTime = currentTime;
        float swingIncrement = 200.0f;
        float swingProgress = swingIncrement * ((float)elapsedTime / 1000.0f);
        if (current > end) {
            current -= swingProgress;
        } else if (current < end) {
            current += swingProgress;
        }
        if (end == -130.0f && current <= end) {
            end = start;
        }
        if (end == start && current >= end) {
            current = end;
        }
        try {
            if (ModuleManager.INSTANCE.getModuleByClass(SwingAnimation.class).isEnabled()) {
                matrices.method_22904(0.4, -0.2, -0.1);
                matrices.method_22907(class_7833.field_40716.rotationDegrees(85.0f));
                matrices.method_22907(class_7833.field_40718.rotationDegrees(-17.0f));
                matrices.method_22907(class_7833.field_40714.rotationDegrees(current));
                matrices.method_22904(0.0, 0.6, 0.7);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void swing() {
        if (ModuleManager.INSTANCE.getModuleByClass(SwingAnimation.class).isEnabled()) {
            end = -130.0f;
        } else {
            ClientMain.mc.field_1724.method_6104(ClientMain.mc.field_1724.method_6058());
        }
    }

    public static boolean isValid(class_1799 stack) {
        return stack.method_7909() instanceof class_1829;
    }

    static {
        override = false;
        lastFrameTime = 0L;
    }
}
