package net.fabricmc.fabric.utils.player;

import net.fabricmc.fabric.ClientMain;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;

public class MovementUtils {
    public static boolean hasMovement() {
        class_243 playerMovement = ClientMain.mc.field_1724.method_18798();
        return playerMovement.method_10216() != 0.0 || playerMovement.method_10214() != 0.0 || playerMovement.method_10215() != 0.0;
    }

    public static double motionY(double motionY) {
        class_243 vec3d = ClientMain.mc.field_1724.method_18798();
        ClientMain.mc.field_1724.method_18800(vec3d.field_1352, motionY, vec3d.field_1350);
        return motionY;
    }

    public static double motionYPlus(double motionY) {
        class_243 vec3d = ClientMain.mc.field_1724.method_18798();
        ClientMain.mc.field_1724.method_18800(vec3d.field_1352, vec3d.field_1351 + motionY, vec3d.field_1350);
        return motionY;
    }

    public static double getDistanceToGround(class_1297 entity) {
        double playerX = ClientMain.mc.field_1724.method_23317();
        int playerHeight = (int)Math.floor(ClientMain.mc.field_1724.method_23318());
        double playerZ = ClientMain.mc.field_1724.method_23321();
        for (int height = playerHeight; height > 0; --height) {
            class_2338 checkPosition = new class_2338((int)playerX, height, (int)playerZ);
            if (ClientMain.mc.field_1687.method_22347(checkPosition)) continue;
            return playerHeight - height;
        }
        return 0.0;
    }

    public static void setHorizontalVelocity(double speed) {
        if (ClientMain.mc.field_1724.field_6250 != 0.0f || ClientMain.mc.field_1724.field_6212 != 0.0f) {
            double yaw = Math.toRadians(ClientMain.mc.field_1724.method_36454());
            double x = -Math.sin(yaw) * speed;
            double z = Math.cos(yaw) * speed;
            ClientMain.mc.field_1724.method_18800(x, ClientMain.mc.field_1724.method_18798().field_1351, z);
        }
    }

    public static float getSpeed() {
        return (float)Math.sqrt(ClientMain.mc.field_1724.method_18798().field_1352 * ClientMain.mc.field_1724.method_18798().field_1352 + ClientMain.mc.field_1724.method_18798().field_1350 * ClientMain.mc.field_1724.method_18798().field_1350);
    }

    public static float setSpeed(float speed) {
        if (ClientMain.mc.field_1724 == null) {
            return 0.0f;
        }
        ClientMain.mc.field_1724.method_18800(ClientMain.mc.field_1724.method_18798().field_1352, 0.0, ClientMain.mc.field_1724.method_18798().field_1350);
        ClientMain.mc.field_1724.method_18800((double)speed, 0.0, (double)speed);
        return MovementUtils.getSpeed();
    }

    public static void strafe() {
        MovementUtils.strafe(MovementUtils.getSpeed());
    }

    public static boolean test() {
        return ClientMain.mc.field_1690.field_1894.method_1434() || ClientMain.mc.field_1690.field_1881.method_1434() || ClientMain.mc.field_1690.field_1913.method_1434() || ClientMain.mc.field_1690.field_1849.method_1434();
    }

    public static void setMotionY(double y) {
        if (ClientMain.mc.field_1724 == null) {
            return;
        }
        ClientMain.mc.field_1724.method_18800(ClientMain.mc.field_1724.method_18798().field_1352, y, ClientMain.mc.field_1724.method_18798().field_1350);
    }

    public static boolean isMoving() {
        return ClientMain.mc.field_1724 != null && MovementUtils.test();
    }

    public static double direction(float rotationYaw, double moveForward, double moveStrafing) {
        float rotationYawCalced = rotationYaw;
        if (moveForward < 0.0) {
            rotationYawCalced += 180.0f;
        }
        float forward = 1.0f;
        if (moveForward < 0.0) {
            forward = -0.5f;
        } else if (moveForward > 0.0) {
            forward = 0.5f;
        }
        if (moveStrafing > 0.0) {
            rotationYawCalced -= 90.0f * forward;
        }
        if (moveStrafing < 0.0) {
            rotationYawCalced += 90.0f * forward;
        }
        return Math.toRadians(rotationYawCalced);
    }

    public static void resetMotion(Boolean y) {
        ClientMain.mc.field_1724.method_18800(0.0, ClientMain.mc.field_1724.method_18798().field_1351, 0.0);
        if (y.booleanValue()) {
            ClientMain.mc.field_1724.method_18800(0.0, 0.0, 0.0);
        }
    }

    public static double[] forward(double multiplier) {
        if (ClientMain.mc.field_1724 == null) {
            return new double[]{0.0, 0.0};
        }
        double direction = MovementUtils.getDirection();
        double x = -Math.sin(direction) * multiplier;
        double z = Math.cos(direction) * multiplier;
        return new double[]{x, z};
    }

    public static void strafe(float speed) {
        if (!MovementUtils.isMoving()) {
            return;
        }
        double direction = MovementUtils.getDirection();
        double x = -Math.sin(direction) * (double)speed;
        double z = Math.cos(direction) * (double)speed;
        class_243 motion = new class_243(x, ClientMain.mc.field_1724.method_18798().field_1351, z);
        ClientMain.mc.field_1724.method_18799(motion);
    }

    private static double getDirection() {
        double rotationYaw = class_310.method_1551().field_1724.method_36454();
        if (class_310.method_1551().field_1724.field_3913.field_3905 < 0.0f) {
            rotationYaw += 180.0;
        }
        double forward = 1.0;
        if (class_310.method_1551().field_1724.field_3913.field_3905 < 0.0f) {
            forward = -0.5;
        } else if (class_310.method_1551().field_1724.field_3913.field_3905 > 0.0f) {
            forward = 0.5;
        }
        if (class_310.method_1551().field_1724.field_3913.field_3907 > 0.0f) {
            rotationYaw -= 90.0 * forward;
        }
        if (class_310.method_1551().field_1724.field_3913.field_3907 < 0.0f) {
            rotationYaw += 90.0 * forward;
        }
        return Math.toRadians(rotationYaw);
    }

    public static float getForward() {
        if (ClientMain.mc.field_1724 == null) {
            return 0.0f;
        }
        return ClientMain.mc.field_1724.field_3913.field_3905;
    }

    public static float getStrafe() {
        if (ClientMain.mc.field_1724 == null) {
            return 0.0f;
        }
        return ClientMain.mc.field_1724.field_3913.field_3907;
    }
}
