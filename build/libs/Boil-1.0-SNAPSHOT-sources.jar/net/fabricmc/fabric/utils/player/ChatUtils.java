package net.fabricmc.fabric.utils.player;

import net.fabricmc.fabric.ClientMain;
import net.minecraft.class_2561;

public class ChatUtils {
    private static final String paragraph = "\u00a7";

    public static void addChatMessage(String message) {
        ClientMain.mc.field_1705.method_1743().method_1812((class_2561)class_2561.method_43470((String)message));
    }

    public void sendMsg(String text) {
        if (ClientMain.mc.field_1724 != null) {
            ClientMain.mc.field_1724.method_43496(class_2561.method_30163((String)ChatUtils.translate(text)));
        }
    }

    public void sendMsg(class_2561 text) {
        if (ClientMain.mc.field_1724 != null) {
            ClientMain.mc.field_1724.method_43496(text);
        }
    }

    public static String translate(String text) {
        return text.replace("&", paragraph);
    }

    public static void runCommand(String command) {
        if (ClientMain.mc.field_1687 != null && ClientMain.mc.field_1724 != null) {
            ClientMain.mc.field_1724.field_3944.method_45731(command);
        }
    }

    public static void message(String player, String msg) {
        if (player != null) {
            ClientMain.mc.field_1724.field_3944.method_45731("msg " + player + " " + msg);
        }
    }

    public static void pmessage(String msg) {
        if (ClientMain.mc.field_1724 != null) {
            ClientMain.mc.field_1724.field_3944.method_45729(msg);
        }
    }
}
