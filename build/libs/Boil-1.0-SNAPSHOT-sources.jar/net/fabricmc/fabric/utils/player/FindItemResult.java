package net.fabricmc.fabric.utils.player;

import net.fabricmc.fabric.ClientMain;
import net.minecraft.class_1268;

public class FindItemResult {
    private final int slot;
    private final int count;

    public FindItemResult(int slot, int count) {
        this.slot = slot;
        this.count = count;
    }

    public int getSlot() {
        return this.slot;
    }

    public int getCount() {
        return this.count;
    }

    public boolean found() {
        return this.slot != -1;
    }

    public void switchTo() {
        ClientMain.mc.field_1724.method_31548().field_7545 = this.slot;
    }

    public class_1268 getHand() {
        if (this.slot == 40) {
            return class_1268.field_5810;
        }
        if (this.slot == ClientMain.mc.field_1724.method_31548().field_7545) {
            return class_1268.field_5808;
        }
        return null;
    }

    public boolean isMainHand() {
        return this.getHand() == class_1268.field_5808;
    }

    public boolean isOffhand() {
        return this.getHand() == class_1268.field_5810;
    }

    public boolean isHotbar() {
        return this.slot >= 0 && this.slot <= 8;
    }

    public boolean isMain() {
        return this.slot >= 9 && this.slot <= 35;
    }

    public boolean isArmor() {
        return this.slot >= 36 && this.slot <= 39;
    }
}
