package net.fabricmc.fabric.utils.player;

import net.minecraft.class_1657;
import net.minecraft.class_243;

public class PlayerSimulation {
    private final class_1657 player;
    private class_243 predictedPosition;

    public PlayerSimulation(class_1657 player) {
        this.player = player;
        this.predictedPosition = player.method_19538();
    }

    public void tick(int ticks) {
        if (this.player == null) {
            return;
        }
        class_243 velocity = this.player.method_18798();
        class_243 position = this.player.method_19538();
        class_243 inputMovement = this.getMovement();
        velocity = velocity.method_1019(inputMovement);
        if (!this.player.method_24828()) {
            velocity = velocity.method_1031(0.0, -0.08, 0.0);
        }
        velocity = this.friction(velocity);
        this.predictedPosition = position.method_1019(velocity);
        for (int i = 0; i < ticks; ++i) {
            velocity = velocity.method_1019(this.getMovement());
            if (!this.player.method_24828()) {
                velocity = velocity.method_1031(0.0, -0.08, 0.0);
            }
            velocity = this.friction(velocity);
            this.predictedPosition = this.predictedPosition.method_1019(velocity);
        }
    }

    private class_243 getMovement() {
        class_243 velocity = this.player.method_18798();
        double speed = Math.sqrt(velocity.field_1352 * velocity.field_1352 + velocity.field_1350 * velocity.field_1350);
        if (speed == 0.0) {
            return class_243.field_1353;
        }
        double x = velocity.field_1352 / speed * speed;
        double z = velocity.field_1350 / speed * speed;
        return new class_243(x, 0.0, z);
    }

    private class_243 friction(class_243 velocity) {
        double friction = this.player.method_24828() ? 0.91 : 0.98;
        return velocity.method_1021(friction);
    }

    public class_243 getPredictedPosition() {
        return this.predictedPosition;
    }
}
