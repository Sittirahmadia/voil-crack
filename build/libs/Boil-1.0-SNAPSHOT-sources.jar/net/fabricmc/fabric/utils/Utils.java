package net.fabricmc.fabric.utils;

import java.io.File;
import java.net.URISyntaxException;
import java.util.Random;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.security.checks.SecurityManager;
import net.fabricmc.fabric.systems.module.impl.render.SwingAnimation;
import net.minecraft.class_1309;
import net.minecraft.class_1743;
import net.minecraft.class_1819;
import net.minecraft.class_1829;

public class Utils {
    private static final String SYMBOLS = "!@#$%^&*()_+-=[]|,.<>/?";
    private static final Random RANDOM = new Random();

    public static char randomSymbols() {
        int index = RANDOM.nextInt(SYMBOLS.length());
        return SYMBOLS.charAt(index);
    }

    public static boolean isWeaponBlocking(class_1309 entity) {
        return entity.method_6115() && Utils.canWeaponBlock(entity);
    }

    public static boolean canWeaponBlock(class_1309 entity) {
        return ModuleManager.INSTANCE.getModuleByClass(SwingAnimation.class).isEnabled() && (entity.method_6047().method_7909() instanceof class_1829 || entity.method_6047().method_7909() instanceof class_1743) && entity.method_6079().method_7909() instanceof class_1819 || (entity.method_6079().method_7909() instanceof class_1829 || entity.method_6079().method_7909() instanceof class_1743) && entity.method_6047().method_7909() instanceof class_1819;
    }

    public static File getVoilJar() throws URISyntaxException {
        return new File(SecurityManager.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
    }

    public static float getTick() {
        return ClientMain.mc.method_60646().method_60637(false);
    }
}
