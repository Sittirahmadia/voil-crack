package net.fabricmc.fabric.utils.world;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.fabricmc.fabric.ClientMain;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1421;
import net.minecraft.class_1439;
import net.minecraft.class_1473;
import net.minecraft.class_1480;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class EntityUtils {
    public static boolean isDeadBodyNearby() {
        return ClientMain.mc.field_1687.method_18456()
                .parallelStream()
                .filter(e -> e != ClientMain.mc.field_1724)
                .filter(e -> e.method_5858(ClientMain.mc.field_1724) <= 36.0)
                .anyMatch(class_1309::method_29504);
    }

    public static <T extends class_1297> List<T> findEntities(Class<T> entityClass) {
        ArrayList<T> entities = new ArrayList<>();
        for (class_1297 entity : ClientMain.mc.field_1687.method_18112()) {
            if (entity.equals(ClientMain.mc.field_1724) || !entityClass.isAssignableFrom(entity.getClass())) continue;
            entities.add((T) entity);
        }
        return entities;
    }



    public static class_1657 findPlayerByUUID(UUID uuid) {
        return class_310.method_1551().field_1687.method_18456().stream().filter(p -> p.method_5667().equals(uuid)).findFirst().orElse(null);
    }

    public static <T extends class_1297> T findClosest(Class<T> entityClass, float range) {
        for (class_1297 entity : ClientMain.mc.field_1687.method_18112()) {
            if (!entityClass.isAssignableFrom(entity.getClass()) || entity.equals((Object)ClientMain.mc.field_1724) || !(entity.method_5739((class_1297)ClientMain.mc.field_1724) <= range)) continue;
            return (T)entity;
        }
        return null;
    }

    public static boolean isAnimal(class_1297 e) {
        return e instanceof class_1296 || e instanceof class_1421 || e instanceof class_1480 || e instanceof class_1439 || e instanceof class_1473;
    }
}
