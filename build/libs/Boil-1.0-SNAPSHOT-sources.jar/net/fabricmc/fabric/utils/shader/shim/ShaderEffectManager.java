package net.fabricmc.fabric.utils.shader.shim;

import net.minecraft.class_293;
import net.minecraft.class_2960;

public final class ShaderEffectManager {
    private static final ShaderEffectManager INSTANCE = new ShaderEffectManager();

    public static ShaderEffectManager getInstance() {
        return INSTANCE;
    }

    public ManagedCoreShader manageCoreShader(class_2960 id, class_293 vf) {
        return new ManagedCoreShader();
    }
}



