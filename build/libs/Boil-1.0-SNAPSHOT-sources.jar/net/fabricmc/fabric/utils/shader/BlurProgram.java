package net.fabricmc.fabric.utils.shader;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.utils.shader.shim.ManagedCoreShader;
import net.fabricmc.fabric.utils.shader.shim.SamplerUniform;
import net.fabricmc.fabric.utils.shader.shim.ShaderEffectManager;
import net.fabricmc.fabric.utils.shader.shim.Uniform1f;
import net.fabricmc.fabric.utils.shader.shim.Uniform2f;
import net.minecraft.class_276;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_6367;
import net.minecraft.class_757;
import org.lwjgl.opengl.GL30;

public class BlurProgram {
    private Uniform2f uSize;
    private Uniform2f uLocation;
    private Uniform1f radius;
    private Uniform2f inputResolution;
    private Uniform1f brightness;
    private Uniform1f quality;
    private SamplerUniform sampler;
    private class_276 input;
    public static final ManagedCoreShader BLUR = ShaderEffectManager.getInstance().manageCoreShader(class_2960.method_60655((String)"tulip", (String)"blur"), class_290.field_1592);

    public BlurProgram() {
        this.setup();
    }

    public void setParameters(float x, float y, float width, float height, float r, float blurStrength, float blurOpacity) {
        if (this.input == null) {
            this.input = new class_6367(ClientMain.mc.method_22683().method_4486(), ClientMain.mc.method_22683().method_4502(), false, class_310.field_1703);
        }
        float i = (float)ClientMain.mc.method_22683().method_4495();
        this.radius.set(r * i);
        this.uLocation.set(x * i, -y * i + (float)ClientMain.mc.method_22683().method_4502() * i - height * i);
        this.uSize.set(width * i, height * i);
        this.brightness.set(blurOpacity);
        this.quality.set(blurStrength);
        this.sampler.set(this.input.method_30277());
    }

    public void use() {
        class_276 buffer = ClientMain.mc.method_1522();
        if (this.input.field_1482 != buffer.field_1482 || this.input.field_1481 != buffer.field_1481) {
            this.input.method_1234(buffer.field_1482, buffer.field_1481, class_310.field_1703);
        }
        this.input.method_1235(false);
        GL30.glBindFramebuffer((int)36008, (int)buffer.field_1476);
        GL30.glBlitFramebuffer((int)0, (int)0, (int)buffer.field_1482, (int)buffer.field_1481, (int)0, (int)0, (int)buffer.field_1482, (int)buffer.field_1481, (int)16384, (int)9729);
        buffer.method_1235(false);
        this.inputResolution.set(buffer.field_1482, buffer.field_1481);
        this.sampler.set(this.input.method_30277());
        RenderSystem.setShader(class_757::method_34539);
    }

    protected void setup() {
        this.inputResolution = BLUR.findUniform2f("InputResolution");
        this.brightness = BLUR.findUniform1f("Brightness");
        this.quality = BLUR.findUniform1f("Quality");
        this.uSize = BLUR.findUniform2f("uSize");
        this.uLocation = BLUR.findUniform2f("uLocation");
        this.radius = BLUR.findUniform1f("radius");
        this.sampler = BLUR.findSampler("InputSampler");
    }
}
