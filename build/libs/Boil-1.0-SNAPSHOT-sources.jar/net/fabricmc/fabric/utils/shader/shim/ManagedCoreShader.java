package net.fabricmc.fabric.utils.shader.shim;

import net.minecraft.class_5944;

public final class ManagedCoreShader {
    public class_5944 getProgram() {
        return null;
    }

    public Uniform1f findUniform1f(String name) {
        return new Uniform1f();
    }

    public Uniform2f findUniform2f(String name) {
        return new Uniform2f();
    }

    public Uniform4f findUniform4f(String name) {
        return new Uniform4f();
    }

    public SamplerUniform findSampler(String name) {
        return new SamplerUniform();
    }
}



