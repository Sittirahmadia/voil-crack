package net.fabricmc.fabric.utils.packet.backtrack;

import net.fabricmc.fabric.utils.packet.backtrack.CooldownTimer;
import net.minecraft.class_2596;

public class TimedPacket {
    private final class_2596<?> packet;
    private final CooldownTimer time;
    private final long millis;

    public TimedPacket(class_2596<?> packet) {
        this.packet = packet;
        this.time = new CooldownTimer();
        this.millis = System.currentTimeMillis();
    }

    public TimedPacket(class_2596<?> packet, long millis) {
        this.packet = packet;
        this.millis = millis;
        this.time = new CooldownTimer();
    }

    public class_2596 getPacket() {
        return this.packet;
    }

    public CooldownTimer getTimer() {
        return this.getTime();
    }

    public CooldownTimer getTime() {
        return this.time;
    }

    public long getMillis() {
        return this.millis;
    }
}
