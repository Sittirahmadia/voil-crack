package net.fabricmc.fabric.utils.packet;

import java.util.Objects;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.mixin.IClientWorldMixin;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_7202;
import net.minecraft.class_7204;

public class PacketUtils {
    public static void sendPacket(class_2596 packet) {
        if (ClientMain.mc.field_1724 != null) {
            ClientMain.mc.method_1562().method_52787(packet);
        }
    }

    public static void sendPosition(class_243 pos) {
        if (ClientMain.mc.field_1724 != null) {
            ClientMain.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(pos.method_10216(), pos.method_10214(), pos.method_10215(), ClientMain.mc.field_1724.method_24828()));
        }
    }

    public static void sendSequencedPacket(class_7204 packetCreator) {
        if (ClientMain.mc.method_1562() == null || ClientMain.mc.field_1687 == null) {
            return;
        }
        try (class_7202 pendingUpdateManager = ((IClientWorldMixin)ClientMain.mc.field_1687).getPendingUpdateManager().method_41937();){
            int i = pendingUpdateManager.method_41942();
            ClientMain.mc.method_1562().method_52787(packetCreator.predict(i));
        }
    }

    public static void sendPacketSilently(class_2596 packet) {
        ClientMain.mc.method_1562().method_48296().method_10752(packet, null);
    }

    public void sendPacket2(class_2596<?> packetIn) {
        if (packetIn == null) {
            return;
        }
        Objects.requireNonNull(ClientMain.mc.method_1562()).method_48296().method_10743(packetIn);
    }
}
