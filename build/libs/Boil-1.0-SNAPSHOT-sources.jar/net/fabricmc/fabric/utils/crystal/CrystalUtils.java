package net.fabricmc.fabric.utils.crystal;

import java.util.List;
import net.fabricmc.fabric.ClientMain;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_746;

public final class CrystalUtils {

    private CrystalUtils() {}

    public static boolean canPlaceCrystalServer(class_2338 pos) {
        if (ClientMain.mc.field_1687 == null) return false;

        class_2680 state = ClientMain.mc.field_1687.method_8320(pos);
        if (state.method_26204() != class_2246.field_10540 && state.method_26204() != class_2246.field_9987) return false;

        class_2338 crystalPos = pos.method_10084();
        if (!ClientMain.mc.field_1687.method_22347(crystalPos)) return false;

        class_238 box = new class_238(crystalPos).method_989(0.5, 0.0, 0.5).method_1012(0.0, 2.0, 0.0);
        List<class_1297> entities = ClientMain.mc.field_1687.method_8390(class_1297.class, box, e -> !(e instanceof class_746));
        for (class_1297 entity : entities) {
            if (entity instanceof class_1511) return false;
        }

        return true;
    }

    public static boolean canPlaceCrystalClient(class_2338 pos) {
        if (ClientMain.mc.field_1687 == null) return false;

        class_2680 state = ClientMain.mc.field_1687.method_8320(pos);
        if (state.method_26204() != class_2246.field_10540 && state.method_26204() != class_2246.field_9987) return false;

        return canPlaceCrystalClientAssumeObsidian(pos);
    }

    public static boolean canPlaceCrystalClientAssumeObsidian(class_2338 block) {
        class_2338 crystalPos = block.method_10084();
        if (!ClientMain.mc.field_1687.method_22347(crystalPos)) return false;

        class_238 box = new class_238(crystalPos).method_989(0.5, 0.0, 0.5).method_1012(0.0, 2.0, 0.0);
        List<class_1297> entities = ClientMain.mc.field_1687.method_8390(class_1297.class, box, e -> !(e instanceof class_746));
        for (class_1297 entity : entities) {
            if (entity instanceof class_1511) return false;
        }

        return true;
    }
}
