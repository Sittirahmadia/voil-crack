package net.fabricmc.fabric.security.components;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.utils.render.Render2DEngine;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4587;

public class TextField
extends class_342 {
    private static final int INNER_PADDING = 4;
    private static final long fade = 500L;
    private final Map<Integer, Long> charAppearTimes = new HashMap<Integer, Long>();

    public TextField(class_327 textRenderer, int x, int y, int width, int height, class_2561 message) {
        super(textRenderer, x, y, width, height, message);
    }

    public void method_1867(String text) {
        super.method_1867(text);
        long currentTime = System.currentTimeMillis();
        for (int i = this.method_1882().length() - text.length(); i < this.method_1882().length(); ++i) {
            this.charAppearTimes.put(i, currentTime);
        }
    }

    public void method_48579(class_332 matrices, int mouseX, int mouseY, float delta) {
        Color backgroundColor = new Color(44, 44, 44, 255);
        double cornerRadius = 5.0;
        Render2DEngine.drawRoundedBlur(matrices.method_51448(), this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, (float)cornerRadius, 14.0f, 0.0f, false);
        long currentTime = System.currentTimeMillis();
        String text = this.method_1882();
        int x = this.method_46426() + 4;
        int y = this.method_46427() + (this.field_22759 - 18) / 2;
        for (int i = 0; i < text.length(); ++i) {
            long appearTime = this.charAppearTimes.getOrDefault(i, currentTime);
            float fadeFactor = Math.min(1.0f, (float)(currentTime - appearTime) / 500.0f);
            int alpha = (int)(fadeFactor * 255.0f);
            int color = new Color(255, 255, 255, alpha).getRGB();
            ClientMain.fontRenderer.draw(matrices.method_51448(), String.valueOf(text.charAt(i)), x, y, color);
            x += (int)ClientMain.fontRenderer.getWidth(String.valueOf(text.charAt(i)));
        }
        if (this.method_25370()) {
            int cursorX = (int)((float)this.method_46426() + ClientMain.fontRenderer.getWidth(text.substring(0, this.method_1881())) + 4.0f);
            int cursorY = this.method_46427() + (this.field_22759 - 8) / 2;
            int cursorEndY = cursorY + 9;
            this.renderCursor(matrices.method_51448(), cursorX, cursorY, cursorEndY);
        }
    }

    private void renderCursor(class_4587 matrices, int cursorX, int cursorY, int cursorEndY) {
        RenderSystem.disableDepthTest();
        RenderSystem.enableColorLogicOp();
        RenderSystem.logicOp((GlStateManager.class_1030)GlStateManager.class_1030.field_5110);
        Render2DEngine.fill(matrices, cursorX, cursorY - 1, cursorX + 1, cursorEndY, -1);
        RenderSystem.disableColorLogicOp();
        RenderSystem.enableDepthTest();
    }
}
