package net.fabricmc.fabric.security.components;

import java.awt.Color;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.utils.render.Render2DEngine;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_4587;

public class Button
extends class_4185 {
    public Button(int x, int y, int width, int height, class_2561 message, class_4185.class_4241 onPress) {
        super(x, y, width, height, message, onPress, button -> class_2561.method_43469((String)"narration.button", (Object[])new Object[]{message}));
    }

    public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
        class_310 mc = class_310.method_1551();
        class_327 textRenderer = mc.field_1772;
        boolean isHovered = mouseX >= this.method_46426() && mouseY >= this.method_46427() && mouseX < this.method_46426() + this.field_22758 && mouseY < this.method_46427() + this.field_22759;
        int borderAlpha = 175;
        int backgroundAlpha = 127;
        Color borderColor = isHovered ? new Color(0x3F3D3F | borderAlpha << 24, true) : new Color(0x2E2D2E | borderAlpha << 24, true);
        int borderPadding = 2;
        Color backgroundColor = new Color(0x404040 | backgroundAlpha << 24, true);
        Render2DEngine.drawRoundedBlur(context.method_51448(), this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, 5.0f, 16.0f, 0.0f, false);
        int textColor = isHovered ? 0xFFFFFF : 0xCCCCCC;
        this.drawCenteredText(context.method_51448(), textRenderer, this.method_25369(), this.method_46426() + this.field_22758 / 2, this.method_46427() + (this.field_22759 - 18) / 2, textColor);
    }

    private void drawCenteredText(class_4587 matrices, class_327 textRenderer, class_2561 text, int x, int y, int color) {
        String textString = text.getString();
        float textWidth = ClientMain.fontRenderer.getWidth(textString);
        float centeredX = (float)x - textWidth / 2.0f;
        ClientMain.fontRenderer.draw(matrices, textString, centeredX, y, color);
    }
}
