package net.fabricmc.fabric.security;

import java.awt.Color;
import java.util.Map;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.security.LoginHandler;
import net.fabricmc.fabric.security.UserConstants;
import net.fabricmc.fabric.security.components.Button;
import net.fabricmc.fabric.security.components.TextField;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;

public class LoginGUI
extends class_437 {
    private class_342 usernameField;
    private Button loginButton;
    private Map<String, String> credentials = null;
    String savedUsername = this.credentials != null ? this.credentials.getOrDefault("username", "") : "";
    String savedPassword = this.credentials != null ? this.credentials.getOrDefault("password", "") : "";

    public LoginGUI() {
        super((class_2561)class_2561.method_43470((String)"login to continue"));
    }

    protected void method_25426() {
        int fieldWidth = 125;
        int fieldHeight = 20;
        int fieldX = this.field_22789 / 2 - fieldWidth / 2;
        int fieldY = 225;
        this.usernameField = new TextField(ClientMain.mc.field_1772, fieldX, fieldY, fieldWidth, fieldHeight, class_2561.method_30163((String)"Username"));
        this.usernameField.method_1880(24);
        this.method_25429(this.usernameField);
        this.usernameField.method_1852(this.savedUsername);
        this.method_48265(this.usernameField);
        this.loginButton = new Button(fieldX, fieldY + 30, fieldWidth, fieldHeight, (class_2561)class_2561.method_43471((String)"Login"), button -> this.onLoginButtonClick());
        this.method_37063(this.usernameField);
        this.method_37063(this.loginButton);
        super.method_25426();
    }

    public void method_25394(class_332 matrices, int mouseX, int mouseY, float delta) {
        int screenWidth = ClientMain.mc.method_22683().method_4486();
        int screenHeight = ClientMain.mc.method_22683().method_4502();
        int textWidth = (int)ClientMain.fontRenderer.getWidth("Voil.lol industrious");
        int x = screenWidth - textWidth - 10;
        int y = (int)((float)screenHeight - ClientMain.fontRenderer.getFont().getSize2D() - 10.0f);
        ClientMain.fontRenderer.draw(matrices.method_51448(), "Voil.lol industrious", x, y, new Color(156, 107, 173).getRGB());
        super.method_25394(matrices, mouseX, mouseY, delta);
    }

    public void method_25393() {
        String username = this.usernameField.method_1882();
    }

    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            return true;
        }
        if (keyCode == 257) {
            this.onLoginButtonClick();
            return true;
        }
        return this.usernameField.method_25404(keyCode, scanCode, modifiers) || super.method_25404(keyCode, scanCode, modifiers);
    }

    public boolean method_25400(char chr, int keyCode) {
        return this.usernameField.method_25400(chr, keyCode) || super.method_25400(chr, keyCode);
    }

    private void onLoginButtonClick() {
        String username = this.usernameField.method_1882();
        UserConstants.USERNAME.setValue(username);
        LoginHandler.getInstance().authenticate(username);
    }
}
