package net.fabricmc.fabric.command.impl;

import net.fabricmc.fabric.command.Command;
import net.fabricmc.fabric.managers.SocialManager;
import net.fabricmc.fabric.utils.player.ChatUtils;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_3966;

public class Friend
extends Command {
    public Friend() {
        super("friend", "add/remove", "fr");
    }

    @Override
    public void onCmd(String message, String[] args) {
        if (args.length < 2) {
            ChatUtils.addChatMessage("Usage: .friend add/remove");
            return;
        }
        String action = args[0].toLowerCase();
        class_1657 targetPlayer = this.getTargetedPlayer();
        if (targetPlayer == null) {
            ChatUtils.addChatMessage("No player targeted.");
            return;
        }
        String playerName = String.valueOf(targetPlayer.method_5477());
        switch (action) {
            case "add": {
                SocialManager.addFriend(targetPlayer.method_5667());
                ChatUtils.addChatMessage(playerName + " has been added to your friends list.");
                break;
            }
            case "remove": {
                SocialManager.removeFriend(targetPlayer.method_5667());
                ChatUtils.addChatMessage(playerName + " has been removed from your friends list.");
                break;
            }
            default: {
                ChatUtils.addChatMessage("Invalid. Use 'add' or 'remove'.");
            }
        }
    }

    private class_1657 getTargetedPlayer() {
        class_239 hit = Friend.mc.field_1765;
        if (hit instanceof class_3966 ehr) {
            if (ehr.method_17782() instanceof class_1657 player) {
                return player;
            }
        }
        return null;
    }
}
