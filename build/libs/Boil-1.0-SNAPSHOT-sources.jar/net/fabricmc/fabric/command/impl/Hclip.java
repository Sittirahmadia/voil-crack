package net.fabricmc.fabric.command.impl;

import net.fabricmc.fabric.command.Command;
import net.fabricmc.fabric.utils.player.ChatUtils;
import net.minecraft.class_746;

public class Hclip
extends Command {
    public Hclip() {
        super("Hclip", "clip horizontally", "hclip");
    }

    @Override
    public void onCmd(String message, String[] args) {
        if (args.length < 1) {
            ChatUtils.addChatMessage("Not enough arguments.");
            return;
        }
        int horiz = Integer.parseInt(args[1]);
        class_746 player = Hclip.mc.field_1724;
        assert (player != null);
        double yaw = Math.toRadians(player.method_36454());
        double forwardX = -Math.sin(yaw) * (double)horiz;
        double forwardZ = Math.cos(yaw) * (double)horiz;
        player.method_30634(player.method_23317() + forwardX, player.method_23318(), player.method_23321() + forwardZ);
    }
}
