package net.fabricmc.fabric.command.impl;

import net.fabricmc.fabric.command.Command;
import net.fabricmc.fabric.utils.player.ChatUtils;
import net.minecraft.class_746;

public class Vclip
extends Command {
    public Vclip() {
        super("Vclip", "clip up", "vclip");
    }

    @Override
    public void onCmd(String message, String[] args) {
        if (args.length < 1) {
            ChatUtils.addChatMessage("Not enough arguments.");
            return;
        }
        int height = Integer.parseInt(args[1]);
        class_746 player = Vclip.mc.field_1724;
        assert (player != null);
        player.method_30634(player.method_23317(), player.method_23318() + (double)height, player.method_23321());
    }
}
