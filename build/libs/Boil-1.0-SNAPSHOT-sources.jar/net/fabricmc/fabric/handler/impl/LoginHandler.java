package net.fabricmc.fabric.handler.impl;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.handler.Handler;
import net.fabricmc.fabric.managers.SessionManager;
import net.fabricmc.fabric.security.LoginGUI;
import net.fabricmc.fabric.security.checks.SecurityManager;
import net.minecraft.class_437;

public class LoginHandler
implements Handler {
    @Override
    public void handle() {
        if (!SessionManager.isSessionValid() || !SecurityManager.e) {
            net.fabricmc.fabric.managers.SessionManager.createInstance("local", "local", "local-hwid", "local-session");
            net.fabricmc.fabric.security.checks.SecurityManager.e = true;
            this.removeLoginScreen();
        }
    }

    private void registerTick() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (SessionManager.isSessionValid() && SecurityManager.e) {
                this.removeLoginScreen();
            } else if (!(ClientMain.mc.field_1755 instanceof LoginGUI)) {
                this.setLoginScreen();
            }
        });
    }

    private void setLoginScreen() {
        if (!(ClientMain.mc.field_1755 instanceof LoginGUI)) {
            ClientMain.mc.method_20493(() -> {
                if (!(ClientMain.mc.field_1755 instanceof LoginGUI)) {
                    ClientMain.mc.method_1507((class_437)new LoginGUI());
                }
            });
        }
    }

    private void removeLoginScreen() {
        if (ClientMain.mc.field_1755 instanceof LoginGUI) {
            ClientMain.mc.method_20493(() -> ClientMain.mc.method_1507(null));
        }
    }

    private boolean load() {
        return true;
    }
}
