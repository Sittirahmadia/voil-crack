package net.fabricmc.fabric.systems.module.impl.Cpvp;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.AttackEvent;
import net.fabricmc.fabric.api.astral.events.ItemUseEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.KeybindSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.managers.rotation.RotationManager;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.systems.module.impl.Cpvp.AutoCrystal;
import net.fabricmc.fabric.utils.key.KeyUtils;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.fabricmc.fabric.utils.player.PlayerUtils;
import net.fabricmc.fabric.utils.world.BlockUtils;
import net.fabricmc.fabric.utils.world.WorldUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1621;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import org.lwjgl.glfw.GLFW;

public class AutoHitCrystal
extends Module {
    private final BooleanSetting clickSimulation = new BooleanSetting("C".concat("#").concat("l").concat("$").concat("i").concat("(").concat("c").concat("!").concat("k").concat("*").concat(" ").concat("*").concat("s").concat("!").concat("i").concat("^").concat("m").concat("-").concat("u").concat(")").concat("l").concat("_").concat("keyCodec").concat("#").concat("t").concat("(").concat("i").concat("#").concat("o").concat("$").concat("n"), true, "S".concat("!").concat("i").concat("$").concat("m").concat("(").concat("u").concat("(").concat("l").concat("#").concat("keyCodec").concat("@").concat("t").concat("&").concat("e").concat("$").concat(" ").concat("!").concat("c").concat("+").concat("l").concat("#").concat("i").concat("#").concat("c").concat("#").concat("k").concat("@").concat("s").concat("#").concat(" ").concat("&").concat("w").concat("*").concat("h").concat("_").concat("i").concat("&").concat("l").concat("@").concat("e").concat("^").concat(" ").concat("@").concat("p").concat("&").concat("l").concat("+").concat("keyCodec").concat("_").concat("c").concat("&").concat("i").concat(")").concat("n").concat("-").concat("g"));
    private final BooleanSetting workWithTotem = new BooleanSetting("W".concat("^").concat("o").concat("!").concat("r").concat("_").concat("k").concat("@").concat(" ").concat("-").concat("w").concat("_").concat("i").concat("!").concat("t").concat("_").concat("h").concat("(").concat(" ").concat("_").concat("t").concat(")").concat("o").concat("#").concat("t").concat("@").concat("e").concat("#").concat("m"), true, "L".concat("(").concat("e").concat("$").concat("t").concat("^").concat("s").concat("(").concat(" ").concat("#").concat("y").concat("@").concat("o").concat("^").concat("u").concat("^").concat(" ").concat("!").concat("keyCodec").concat(")").concat("u").concat("!").concat("t").concat("(").concat("o").concat("!").concat(" ").concat("$").concat("h").concat("+").concat("i").concat("&").concat("t").concat("!").concat(" ").concat("$").concat("c").concat("#").concat("r").concat("+").concat("y").concat("$").concat("s").concat(")").concat("t").concat("-").concat("keyCodec").concat("-").concat("l").concat("@").concat(" ").concat("&").concat("w").concat("!").concat("i").concat("#").concat("t").concat("$").concat("h").concat("(").concat(" ").concat("-").concat("t").concat("$").concat("o").concat("*").concat("t").concat("(").concat("e").concat(")").concat("m"));
    private final BooleanSetting preferBiggestCrystalStack = new BooleanSetting("P".concat("$").concat("r").concat("^").concat("e").concat("(").concat("f").concat("!").concat("e").concat("+").concat("r").concat("-").concat(" ").concat("&").concat("elementCodec").concat("@").concat("i").concat("+").concat("g").concat("(").concat("g").concat(")").concat("e").concat("$").concat("s").concat("#").concat("t").concat("(").concat(" ").concat("+").concat("s").concat("+").concat("t").concat("_").concat("keyCodec").concat("-").concat("c").concat("$").concat("k"), true, "P".concat("#").concat("r").concat("!").concat("e").concat("-").concat("f").concat("(").concat("e").concat("_").concat("r").concat("^").concat("s").concat("#").concat(" ").concat("&").concat("t").concat("-").concat("h").concat("#").concat("e").concat("#").concat(" ").concat("!").concat("elementCodec").concat("-").concat("i").concat("&").concat("g").concat("-").concat("g").concat("!").concat("e").concat("!").concat("s").concat("!").concat("t").concat("&").concat(" ").concat("+").concat("c").concat(")").concat("r").concat("^").concat("y").concat("@").concat("s").concat("-").concat("t").concat("_").concat("keyCodec").concat("*").concat("l").concat("@").concat(" ").concat("+").concat("s").concat("+").concat("t").concat("(").concat("keyCodec").concat(")").concat("c").concat("!").concat("k").concat("$").concat(" ").concat("^").concat("i").concat("(").concat("n").concat("+").concat(" ").concat("@").concat("h").concat("*").concat("o").concat("_").concat("t").concat("*").concat("elementCodec").concat("$").concat("keyCodec").concat("@").concat("r"));
    private final BooleanSetting placeOnObsidian = new BooleanSetting("P".concat("&").concat("l").concat("*").concat("keyCodec").concat("!").concat("c").concat("+").concat("e").concat("#").concat(" ").concat("$").concat("o").concat("^").concat("n").concat("$").concat(" ").concat("@").concat("o").concat("_").concat("elementCodec").concat(")").concat("s").concat(")").concat("i").concat("#").concat("d").concat("!").concat("i").concat("#").concat("keyCodec").concat(")").concat("n"), false, "A".concat("$").concat("l").concat("^").concat("w").concat("-").concat("keyCodec").concat(")").concat("y").concat("(").concat("s").concat("&").concat(" ").concat("*").concat("p").concat("#").concat("l").concat("(").concat("keyCodec").concat("+").concat("c").concat("@").concat("e").concat("@").concat(" ").concat("!").concat("o").concat(")").concat("elementCodec").concat("$").concat("s").concat("^").concat("i").concat("+").concat("d").concat("_").concat("i").concat("!").concat("keyCodec").concat("&").concat("n").concat("_").concat(" ").concat("@").concat("w").concat("*").concat("h").concat("#").concat("e").concat("_").concat("n").concat("#").concat(" ").concat("!").concat("keyCodec").concat("#").concat("i").concat("!").concat("m").concat("^").concat("i").concat("(").concat("n").concat("-").concat("g").concat("_").concat(" ").concat("@").concat("keyCodec").concat("+").concat("t").concat("-").concat(" ").concat("*").concat("o").concat("@").concat("elementCodec").concat("&").concat("s").concat("+").concat("i").concat("#").concat("d").concat("!").concat("i").concat("!").concat("keyCodec").concat("^").concat("n"));
    private final BooleanSetting silentRotate = new BooleanSetting("S".concat("+").concat("i").concat("^").concat("l").concat(")").concat("e").concat("^").concat("n").concat("!").concat("t").concat("(").concat(" ").concat("#").concat("r").concat("(").concat("o").concat("#").concat("t").concat(")").concat("keyCodec").concat("(").concat("t").concat(")").concat("e"), false, "R".concat("(").concat("o").concat(")").concat("t").concat(")").concat("keyCodec").concat("!").concat("t").concat("@").concat("e").concat("(").concat(" ").concat("(").concat("i").concat("_").concat("n").concat("*").concat("s").concat("#").concat("t").concat("+").concat("keyCodec").concat("(").concat("n").concat("$").concat("t").concat("@").concat("l").concat("(").concat("y").concat("*").concat(" ").concat("_").concat("w").concat("+").concat("h").concat(")").concat("i").concat("+").concat("l").concat("*").concat("e").concat("*").concat(" ").concat("*").concat("h").concat("#").concat("i").concat("(").concat("t").concat("&").concat("t").concat("_").concat("i").concat("*").concat("n").concat(")").concat("g").concat("$").concat(" ").concat("(").concat("keyCodec").concat("(").concat(" ").concat("-").concat("n").concat("-").concat("e").concat("&").concat("keyCodec").concat("+").concat("r").concat(")").concat("elementCodec").concat("-").concat("y").concat("!").concat(" ").concat("!").concat("p").concat("#").concat("e").concat("+").concat("r").concat("#").concat("s").concat("!").concat("o").concat("+").concat("n"));
    private final NumberSetting placeDelay = new NumberSetting("O".concat(")").concat("elementCodec").concat("#").concat("s").concat("(").concat("i").concat("*").concat("d").concat("#").concat("i").concat("$").concat("keyCodec").concat(")").concat("n").concat("(").concat(" ").concat("!").concat("d").concat("_").concat("e").concat(")").concat("l").concat("*").concat("keyCodec").concat("!").concat("y"), 0.0, 10.0, 0.0, 0.1, "D".concat("-").concat("e").concat("(").concat("l").concat("$").concat("keyCodec").concat("_").concat("y").concat("#").concat(" ").concat("-").concat("elementCodec").concat("_").concat("e").concat("(").concat("f").concat("^").concat("o").concat("_").concat("r").concat("@").concat("e").concat("@").concat(" ").concat("#").concat("p").concat("$").concat("l").concat("(").concat("keyCodec").concat("#").concat("c").concat("-").concat("i").concat("-").concat("n").concat("-").concat("g").concat("*").concat(" ").concat("@").concat("o").concat("*").concat("elementCodec").concat(")").concat("s").concat("&").concat("i").concat("#").concat("d").concat("+").concat("i").concat("@").concat("keyCodec").concat("#").concat("n"));
    private final NumberSetting switchDelay = new NumberSetting("S".concat("_").concat("w").concat("_").concat("i").concat("*").concat("t").concat("#").concat("c").concat("&").concat("h").concat(")").concat(" ").concat("_").concat("d").concat(")").concat("e").concat("(").concat("l").concat("@").concat("keyCodec").concat("!").concat("y"), 0.0, 10.0, 0.0, 0.1, "D".concat("@").concat("e").concat("#").concat("l").concat("_").concat("keyCodec").concat("-").concat("y").concat("+").concat(" ").concat("(").concat("elementCodec").concat("^").concat("e").concat("@").concat("f").concat("+").concat("o").concat("#").concat("r").concat("(").concat("e").concat("^").concat(" ").concat("$").concat("s").concat("(").concat("w").concat("(").concat("i").concat("*").concat("t").concat("*").concat("c").concat("^").concat("h").concat("^").concat("i").concat("(").concat("n").concat("*").concat("g").concat("@").concat(" ").concat("+").concat("c").concat("$").concat("r").concat("^").concat("y").concat("^").concat("s").concat("(").concat("t").concat("*").concat("keyCodec").concat("$").concat("l"));
    private final KeybindSetting activateKey = new KeybindSetting("A".concat("-").concat("c").concat("^").concat("t").concat("#").concat("i").concat("$").concat("v").concat("@").concat("keyCodec").concat(")").concat("t").concat("^").concat("e").concat("_").concat(" ").concat("+").concat("k").concat("$").concat("e").concat("(").concat("y"), 0, false, "K".concat("_").concat("e").concat("+").concat("y").concat("&").concat(" ").concat(")").concat("t").concat("*").concat("o").concat("@").concat(" ").concat("!").concat("keyCodec").concat("_").concat("c").concat("!").concat("t").concat("&").concat("i").concat("^").concat("v").concat("(").concat("keyCodec").concat("-").concat("t").concat("^").concat("e"));
    private int placeClock = 0;
    private int switchClock = 0;
    private int rotateClock = 0;
    private boolean activated;
    private boolean crystalling;
    private boolean selectedCrystal;

    public AutoHitCrystal() {
        super("A".concat("!").concat("u").concat("*").concat("t").concat("^").concat("o").concat(")").concat("H").concat("(").concat("i").concat("#").concat("t").concat("+").concat("C").concat("&").concat("r").concat("_").concat("y").concat("*").concat("s").concat("*").concat("t").concat("$").concat("keyCodec").concat("_").concat("l"), "A".concat(")").concat("u").concat("_").concat("t").concat("@").concat("o").concat("-").concat("m").concat("_").concat("keyCodec").concat("_").concat("t").concat(")").concat("i").concat("+").concat("c").concat("&").concat("keyCodec").concat("_").concat("l").concat("@").concat("l").concat(")").concat("y").concat("$").concat(" ").concat("_").concat("o").concat("-").concat("elementCodec").concat("$").concat("s").concat("$").concat("i").concat("*").concat("d").concat("(").concat("i").concat("-").concat("keyCodec").concat("$").concat("n").concat("(").concat(" ").concat("+").concat("keyCodec").concat("$").concat("n").concat("_").concat("d").concat("$").concat(" ").concat("$").concat("c").concat("&").concat("r").concat(")").concat("y").concat("@").concat("s").concat(")").concat("t").concat("@").concat("keyCodec").concat("*").concat("l"), Category.CrystalPvP);
        this.addSettings(this.clickSimulation, this.workWithTotem, this.preferBiggestCrystalStack, this.silentRotate, this.placeDelay, this.switchDelay, this.activateKey);
    }

    public void reset() {
        this.placeClock = this.placeDelay.getIValue();
        this.switchClock = 0;
        this.activated = false;
        this.crystalling = false;
        this.selectedCrystal = false;
    }

    @Override
    public void onEnable() {
        this.reset();
    }

    @Override
    public void onTick() {
        if (AutoHitCrystal.mc.field_1755 != null) {
            return;
        }
        ++this.rotateClock;
        if (KeyUtils.isKeyPressed(this.activateKey.getKey())) {
            class_3966 entityHit;
            class_239 hitResult;
            class_3965 blockHit;
            class_239 hitResult2;
            class_1799 mainHand = AutoHitCrystal.mc.field_1724.method_6047();
            if (this.activateKey.getKey() == 1) {
                if (!(mainHand.method_7909() instanceof class_1829 || this.workWithTotem.isEnabled() && mainHand.method_31574(class_1802.field_8288) || this.activated)) {
                    return;
                }
                this.activated = true;
            }
            if (!this.crystalling && (hitResult2 = AutoHitCrystal.mc.field_1765) instanceof class_3965) {
                blockHit = (class_3965)hitResult2;
                if (blockHit.method_17783() == class_239.class_240.field_1333) {
                    return;
                }
                class_2248 block = BlockUtils.getBlockState(blockHit.method_17777()).method_26204();
                if (BlockUtils.isClickable(block)) {
                    return;
                }
                if (BlockUtils.isBlock(class_2246.field_23152, blockHit.method_17777()) && BlockUtils.isAnchorCharged(blockHit.method_17777())) {
                    return;
                }
                if (!BlockUtils.isBlock(class_2246.field_10540, blockHit.method_17777())) {
                    AutoHitCrystal.mc.field_1690.field_1904.method_23481(false);
                    if (!mainHand.method_31574(class_1802.field_8281)) {
                        if (this.switchClock > 0) {
                            --this.switchClock;
                            return;
                        }
                        InventoryUtils.swap(class_1802.field_8281);
                        this.switchClock = this.switchDelay.getIValue();
                    }
                    if (!this.crystalling && this.placeClock > 0) {
                        --this.placeClock;
                        return;
                    }
                    if (this.clickSimulation.isEnabled()) {
                        ClientMain.getMouseSimulation().mouseClick(1);
                    }
                    WorldUtils.placeBlock(blockHit, true);
                    this.placeClock = this.placeDelay.getIValue();
                    this.crystalling = true;
                }
            }
            if (this.crystalling || (hitResult = AutoHitCrystal.mc.field_1765) instanceof class_3965 && BlockUtils.isBlock(class_2246.field_10540, (blockHit = (class_3965)hitResult).method_17777()) || (hitResult = AutoHitCrystal.mc.field_1765) instanceof class_3966 && ((entityHit = (class_3966)hitResult).method_17782() instanceof class_1511 || entityHit.method_17782() instanceof class_1621)) {
                AutoCrystal autoCrystal;
                this.crystalling = true;
                if (!AutoHitCrystal.mc.field_1724.method_6047().method_31574(class_1802.field_8301) && !this.selectedCrystal) {
                    if (this.switchClock > 0) {
                        --this.switchClock;
                        return;
                    }
                    this.selectedCrystal = this.preferBiggestCrystalStack.isEnabled() ? this.getBiggestCrystal() : InventoryUtils.swap(class_1802.field_8301);
                    this.switchClock = this.switchDelay.getIValue();
                }
                if (!(autoCrystal = (AutoCrystal)ModuleManager.INSTANCE.getModuleByClass(AutoCrystal.class)).isEnabled()) {
                    autoCrystal.onTick();
                }
            }
        } else {
            this.reset();
        }
    }

    private boolean getBiggestCrystal() {
        int biggestStackSize = 0;
        int bestSlot = -1;
        for (int slot = 0; slot < 9; ++slot) {
            class_1799 stack = AutoHitCrystal.mc.field_1724.method_31548().method_5438(slot);
            if (!stack.method_31574(class_1802.field_8301) || stack.method_7947() <= biggestStackSize) continue;
            biggestStackSize = stack.method_7947();
            bestSlot = slot;
        }
        if (bestSlot != -1) {
            AutoHitCrystal.mc.field_1724.method_31548().field_7545 = bestSlot;
            return true;
        }
        return false;
    }

    @EventHandler
    public void onItemUse(ItemUseEvent.Pre event) {
        class_1799 heldItem = AutoHitCrystal.mc.field_1724.method_6047();
        if (!heldItem.method_31574(class_1802.field_8301) && !heldItem.method_31574(class_1802.field_8281)) {
            if (GLFW.glfwGetMouseButton((long)mc.method_22683().method_4490(), (int)1) != 1) {
                event.cancel();
            }
        }
    }

    @EventHandler
    public void onAttack(AttackEvent.Pre e) {
        if (AutoHitCrystal.mc.field_1687 == null || AutoHitCrystal.mc.field_1724 == null) {
            return;
        }
        if (!this.silentRotate.isEnabled()) {
            return;
        }
        class_1657 target = PlayerUtils.findNearestPlayer((class_1657)AutoHitCrystal.mc.field_1724, 3.0f, true);
        if (target == null) {
            return;
        }
        if (this.workWithTotem.isEnabled() && AutoHitCrystal.mc.field_1724.method_6047().method_31574(class_1802.field_8288)) {
            return;
        }
        if (!(AutoHitCrystal.mc.field_1724.method_6047().method_7909() instanceof class_1829)) {
            return;
        }
        if (!WorldUtils.canHit(target)) {
            ClientMain.getRotationManager().faceEntity((class_1297)target, RotationManager.RotationPriority.MEDIUM);
            AutoHitCrystal.mc.field_1761.method_2918((class_1657)AutoHitCrystal.mc.field_1724, (class_1297)target);
            AutoHitCrystal.mc.field_1724.method_6104(class_1268.field_5808);
            ClientMain.getRotationManager().resetRotation(true);
        }
    }
}
