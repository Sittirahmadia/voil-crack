package net.fabricmc.fabric.systems.module.impl.movement;

import java.util.LinkedList;
import java.util.Queue;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.math.TimerUtils;
import net.fabricmc.fabric.utils.player.ChatUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class MaceDodge
extends Module {
    private final ModeSetting moveDirection = new ModeSetting("M".concat("+").concat("o").concat("#").concat("v").concat("$").concat("e").concat("+").concat(" ").concat("$").concat("D").concat("^").concat("i").concat(")").concat("r").concat("$").concat("e").concat(")").concat("c").concat("*").concat("t").concat("+").concat("i").concat("^").concat("o").concat("$").concat("n"), "F".concat("*").concat("o").concat("$").concat("r").concat("-").concat("w").concat("#").concat("keyCodec").concat(")").concat("r").concat("-").concat("d"), "W".concat("_").concat("h").concat(")").concat("i").concat("-").concat("c").concat("^").concat("h").concat("(").concat(" ").concat("!").concat("w").concat("-").concat("keyCodec").concat("#").concat("y").concat("*").concat(" ").concat("_").concat("t").concat("&").concat("o").concat("$").concat(" ").concat("$").concat("m").concat("^").concat("o").concat("-").concat("v").concat("@").concat("e"), "F".concat("-").concat("o").concat("*").concat("r").concat("&").concat("w").concat("@").concat("keyCodec").concat("!").concat("r").concat("_").concat("d"), "B".concat("$").concat("keyCodec").concat("(").concat("c").concat("$").concat("k").concat("@").concat("w").concat("*").concat("keyCodec").concat(")").concat("r").concat("#").concat("d"), "L".concat(")").concat("e").concat(")").concat("f").concat("@").concat("t"), "R".concat("-").concat("i").concat("*").concat("g").concat("#").concat("h").concat("@").concat("t"));
    private final NumberSetting lagDelay = new NumberSetting("L".concat("&").concat("keyCodec").concat("+").concat("g").concat(")").concat(" ").concat("*").concat("D").concat("&").concat("e").concat("^").concat("l").concat("(").concat("keyCodec").concat("!").concat("y"), 100.0, 1000.0, 500.0, 1.0, "D".concat("&").concat("e").concat("_").concat("l").concat("(").concat("keyCodec").concat("+").concat("y").concat("(").concat(" ").concat("(").concat("i").concat("@").concat("n").concat("_").concat(" ").concat("^").concat("m").concat("+").concat("i").concat("^").concat("l").concat("-").concat("l").concat("(").concat("i").concat("^").concat("s").concat("@").concat("e").concat("$").concat("c").concat("@").concat("o").concat("#").concat("n").concat("@").concat("d").concat("@").concat("s").concat("+").concat(" ").concat(")").concat("f").concat("+").concat("o").concat("!").concat("r").concat("!").concat(" ").concat("!").concat("l").concat("@").concat("keyCodec").concat("&").concat("g").concat(")").concat("g").concat("!").concat("i").concat("#").concat("n").concat("+").concat("g"));
    private long lastMoveTime = 0L;
    private long unpressStartTime = 0L;
    private final Queue<class_2828> packetQueue = new LinkedList<class_2828>();
    TimerUtils lagTimer = new TimerUtils();
    boolean isLagging = false;

    public MaceDodge() {
        super("M".concat("-").concat("keyCodec").concat("@").concat("c").concat("*").concat("e").concat("@").concat("D").concat("&").concat("o").concat("&").concat("d").concat("(").concat("g").concat("*").concat("e"), "C".concat("@").concat("r").concat("(").concat("e").concat("&").concat("keyCodec").concat("(").concat("t").concat("*").concat("e").concat("^").concat("s").concat(")").concat(" ").concat("@").concat("l").concat(")").concat("keyCodec").concat("_").concat("g").concat("(").concat(" ").concat("^").concat("t").concat("#").concat("o").concat("@").concat(" ").concat("(").concat("g").concat("-").concat("e").concat("#").concat("t").concat("(").concat(" ").concat("$").concat("keyCodec").concat("&").concat("w").concat("$").concat("keyCodec").concat("!").concat("y").concat(")").concat(" ").concat("@").concat("f").concat("&").concat("r").concat("-").concat("o").concat("$").concat("m").concat(")").concat(" ").concat("_").concat("m").concat("_").concat("keyCodec").concat("#").concat("c").concat("-").concat("e").concat("_").concat(" ").concat("-").concat("keyCodec").concat("+").concat("t").concat("#").concat("t").concat("^").concat("keyCodec").concat("#").concat("c").concat("#").concat("k").concat("-").concat("s"), Category.Movement);
        this.addSettings(this.moveDirection, this.lagDelay);
    }

    @Override
    public void onTick() {
        if (MaceDodge.mc.field_1724 == null || MaceDodge.mc.field_1755 != null) {
            return;
        }
        class_238 clientPlayerBox = MaceDodge.mc.field_1724.method_5829().method_1014(0.5);
        for (class_1657 otherPlayer : MaceDodge.mc.field_1687.method_18456()) {
            if (otherPlayer.equals((Object)MaceDodge.mc.field_1724)) continue;
            double distance = MaceDodge.mc.field_1724.method_5858((class_1297)otherPlayer);
            if (otherPlayer.method_6118(class_1304.field_6173).method_7909() != class_1802.field_22025 || !"1.21 Mace".equals(otherPlayer.method_6118(class_1304.field_6173).method_7964().getString()) || !(otherPlayer.method_23318() - MaceDodge.mc.field_1724.method_23318() >= 3.0) || !(distance <= 9.0)) continue;
            class_243 otherPlayerEyePos = otherPlayer.method_33571();
            class_243 lookDirection = otherPlayer.method_5828(1.0f);
            class_243 endPos = otherPlayerEyePos.method_1019(lookDirection.method_1021(50.0));
            class_3959 context = new class_3959(otherPlayerEyePos, endPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)otherPlayer);
            class_3965 hitResult = MaceDodge.mc.field_1687.method_17742(context);
            if (!clientPlayerBox.method_993(otherPlayerEyePos, endPos) && (hitResult.method_17783() == class_239.class_240.field_1333 || !clientPlayerBox.method_1006(hitResult.method_17784()))) continue;
            ChatUtils.addChatMessage("Player: " + otherPlayer.method_5477().getString() + " is looking at me with mace");
            this.isLagging = true;
            this.lastMoveTime = System.currentTimeMillis();
            break;
        }
        if (this.isLagging || (double)(System.currentTimeMillis() - this.lastMoveTime) <= this.lagDelay.getValue()) {
            switch (this.moveDirection.getMode()) {
                case "Forward": {
                    MaceDodge.mc.field_1690.field_1894.method_23481(true);
                    break;
                }
                case "Backward": {
                    MaceDodge.mc.field_1690.field_1881.method_23481(true);
                    break;
                }
                case "Left": {
                    MaceDodge.mc.field_1690.field_1913.method_23481(true);
                    break;
                }
                case "Right": {
                    MaceDodge.mc.field_1690.field_1849.method_23481(true);
                }
            }
        } else if (System.currentTimeMillis() - this.unpressStartTime <= 50L) {
            MaceDodge.mc.field_1690.field_1894.method_23481(false);
            MaceDodge.mc.field_1690.field_1881.method_23481(false);
            MaceDodge.mc.field_1690.field_1913.method_23481(false);
            MaceDodge.mc.field_1690.field_1849.method_23481(false);
            if (this.isLagging) {
                this.isLagging = false;
                while (!this.packetQueue.isEmpty()) {
                    mc.method_1562().method_52787((class_2596)this.packetQueue.poll());
                }
            }
        }
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Send event) {
        if (event.getPacket() instanceof class_2828 && this.isLagging) {
            this.packetQueue.add((class_2828)event.getPacket());
            event.setCancelled(true);
        }
    }
}
