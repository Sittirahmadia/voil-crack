package net.fabricmc.fabric.systems.module.impl.combat;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.math.TimerUtils;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;

public class AutoCrossbow
extends Module {
    BooleanSetting autoswitch = new BooleanSetting("A".concat("+").concat("u").concat("&").concat("t").concat("*").concat("o").concat("&").concat(" ").concat("*").concat("S").concat("_").concat("w").concat(")").concat("i").concat("(").concat("t").concat("#").concat("c").concat("!").concat("h"), false, "A".concat("!").concat("u").concat("!").concat("t").concat("-").concat("o").concat("#").concat("m").concat("!").concat("keyCodec").concat("!").concat("t").concat("!").concat("i").concat("-").concat("c").concat("&").concat("keyCodec").concat("*").concat("l").concat(")").concat("l").concat("+").concat("y").concat("&").concat(" ").concat("&").concat("s").concat("!").concat("w").concat("&").concat("i").concat("&").concat("t").concat(")").concat("c").concat("(").concat("h").concat("-").concat("e").concat("+").concat("s").concat("&").concat(" ").concat("$").concat("t").concat("_").concat("o").concat("+").concat(" ").concat("$").concat("c").concat("!").concat("r").concat("^").concat("o").concat("_").concat("s").concat("$").concat("s").concat("!").concat("elementCodec").concat("^").concat("o").concat("&").concat("w").concat("!").concat(" ").concat("^").concat("w").concat("#").concat("h").concat("+").concat("e").concat("^").concat("n").concat("(").concat(" ").concat("&").concat("n").concat("+").concat("o").concat("+").concat("t").concat("#").concat(" ").concat("@").concat("i").concat("^").concat("n").concat("!").concat(" ").concat("_").concat("c").concat("#").concat("r").concat("@").concat("o").concat("#").concat("s").concat("^").concat("s").concat("!").concat("elementCodec").concat("!").concat("o").concat("@").concat("w"));
    BooleanSetting switchBack = new BooleanSetting("S".concat("@").concat("w").concat("+").concat("i").concat("(").concat("t").concat("!").concat("c").concat("(").concat("h").concat("&").concat(" ").concat("@").concat("B").concat("@").concat("keyCodec").concat("!").concat("c").concat("_").concat("k"), false, "S".concat("^").concat("w").concat(")").concat("i").concat("_").concat("t").concat("+").concat("c").concat("^").concat("h").concat("$").concat("e").concat("_").concat("s").concat(")").concat(" ").concat("#").concat("elementCodec").concat("(").concat("keyCodec").concat("!").concat("c").concat("&").concat("k").concat("@").concat(" ").concat("@").concat("t").concat("@").concat("o").concat("$").concat(" ").concat("*").concat("o").concat("(").concat("l").concat("_").concat("d").concat("$").concat(" ").concat("^").concat("s").concat("^").concat("l").concat("#").concat("o").concat("-").concat("t").concat("&").concat(" ").concat("*").concat("keyCodec").concat("-").concat("f").concat("+").concat("t").concat("@").concat("e").concat("$").concat("r").concat("-").concat(" ").concat("-").concat("s").concat("@").concat("h").concat("^").concat("o").concat("@").concat("o").concat("(").concat("t").concat("_").concat("i").concat("$").concat("n").concat("&").concat("g"));
    NumberSetting switchDelay = new NumberSetting("S".concat("(").concat("w").concat("$").concat("i").concat("(").concat("t").concat("_").concat("c").concat("^").concat("h").concat(")").concat(" ").concat("&").concat("D").concat("-").concat("e").concat("*").concat("l").concat("@").concat("keyCodec").concat("^").concat("y"), 0.0, 800.0, 300.0, 1.0, "D".concat("#").concat("e").concat("+").concat("l").concat("^").concat("keyCodec").concat("+").concat("y").concat("-").concat(" ").concat("@").concat("t").concat("(").concat("o").concat("_").concat(" ").concat("+").concat("s").concat("*").concat("w").concat("@").concat("i").concat("^").concat("t").concat("@").concat("c").concat("#").concat("h").concat("$").concat(" ").concat("*").concat("t").concat("!").concat("o").concat("^").concat(" ").concat("!").concat("c").concat("(").concat("r").concat("*").concat("o").concat("#").concat("s").concat("(").concat("s").concat("-").concat("elementCodec").concat("*").concat("o").concat("(").concat("w"));
    NumberSetting raycastDistance = new NumberSetting("R".concat("*").concat("keyCodec").concat("-").concat("y").concat("(").concat("c").concat("!").concat("keyCodec").concat(")").concat("s").concat("$").concat("t").concat("!").concat(" ").concat("@").concat("D").concat("*").concat("i").concat("^").concat("s").concat("-").concat("t").concat("+").concat("keyCodec").concat("^").concat("n").concat(")").concat("c").concat("-").concat("e"), 1.0, 50.0, 20.0, 1.0, "M".concat("@").concat("keyCodec").concat("^").concat("x").concat(")").concat("i").concat("^").concat("m").concat("_").concat("u").concat("$").concat("m").concat("&").concat(" ").concat("(").concat("d").concat("$").concat("i").concat("^").concat("s").concat("^").concat("t").concat("_").concat("keyCodec").concat("!").concat("n").concat("(").concat("c").concat("@").concat("e").concat("(").concat(" ").concat("$").concat("f").concat("_").concat("o").concat("_").concat("r").concat("$").concat(" ").concat("^").concat("r").concat("+").concat("keyCodec").concat("*").concat("y").concat("-").concat("c").concat("!").concat("keyCodec").concat(")").concat("s").concat("@").concat("t"));
    TimerUtils timer = new TimerUtils();
    public int slot = -1;

    public AutoCrossbow() {
        super("A".concat("(").concat("u").concat("!").concat("t").concat(")").concat("o").concat("@").concat("C").concat("@").concat("r").concat("+").concat("o").concat("$").concat("s").concat("_").concat("s").concat("(").concat("elementCodec").concat("(").concat("o").concat("$").concat("w"), "A".concat("*").concat("u").concat("!").concat("t").concat("-").concat("o").concat("-").concat("m").concat("&").concat("keyCodec").concat("_").concat("t").concat("*").concat("i").concat(")").concat("c").concat(")").concat("keyCodec").concat("$").concat("l").concat("+").concat("l").concat(")").concat("y").concat("#").concat(" ").concat("*").concat("s").concat("#").concat("h").concat("&").concat("o").concat("@").concat("o").concat("+").concat("t").concat("+").concat("s").concat("&").concat(" ").concat("$").concat("c").concat("@").concat("r").concat("@").concat("o").concat("&").concat("s").concat("_").concat("s").concat(")").concat("elementCodec").concat("&").concat("o").concat("$").concat("w"), Category.Combat);
        this.addSettings(this.autoswitch, this.switchBack, this.switchDelay, this.raycastDistance);
    }

    @Override
    public void onTick() {
        boolean hasCrossbow;
        if (AutoCrossbow.mc.field_1724 == null || AutoCrossbow.mc.field_1687 == null) {
            return;
        }
        boolean bl = hasCrossbow = AutoCrossbow.mc.field_1724.method_6047().method_7909() instanceof class_1764 || AutoCrossbow.mc.field_1724.method_6079().method_7909() instanceof class_1764;
        if (!hasCrossbow && this.autoswitch.isEnabled()) {
            this.switchToCrossbow();
            return;
        }
        class_1657 targetPlayer = this.findPlayerInRaycast(180, this.raycastDistance.getValue());
        if (targetPlayer != null) {
            this.lookAtEntity((class_1297)targetPlayer);
            if (this.timer.hasReached(this.switchDelay.getValue())) {
                this.shootCrossbow();
                if (this.switchBack.isEnabled() && this.slot != -1) {
                    InventoryUtils.swap(AutoCrossbow.mc.field_1724.method_31548().method_5438(this.slot).method_7909());
                    this.slot = -1;
                }
                this.timer.reset();
            }
        }
    }

    private class_1657 findPlayerInRaycast(int degrees, double distance) {
        List<class_239> results = AutoCrossbow.raycast(degrees, distance);
        for (class_239 result : results) {
            class_1297 entity;
            if (result.method_17783() != class_239.class_240.field_1331 || !((entity = ((class_3966)result).method_17782()) instanceof class_1657) || entity == AutoCrossbow.mc.field_1724) continue;
            return (class_1657)entity;
        }
        return null;
    }

    private void lookAtEntity(class_1297 entity) {
        class_243 eyes = AutoCrossbow.mc.field_1724.method_33571();
        class_243 targetPos = entity.method_33571();
        double dx = targetPos.field_1352 - eyes.field_1352;
        double dy = targetPos.field_1351 - eyes.field_1351;
        double dz = targetPos.field_1350 - eyes.field_1350;
        double distanceXZ = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, distanceXZ)));
        AutoCrossbow.mc.field_1724.method_36456(yaw);
        AutoCrossbow.mc.field_1724.method_36457(pitch);
    }

    public static List<class_239> raycast(int degrees, double distance) {
        ArrayList<class_239> results = new ArrayList<class_239>();
        if (AutoCrossbow.mc.field_1724 == null || AutoCrossbow.mc.field_1687 == null) {
            return results;
        }
        class_243 eyePos = AutoCrossbow.mc.field_1724.method_5836(1.0f);
        double step = 360.0 / (double)degrees;
        for (double angle = 0.0; angle < (double)degrees; angle += step) {
            double radian = Math.toRadians(angle + (double)AutoCrossbow.mc.field_1724.method_36454());
            class_243 direction = new class_243(Math.cos(radian), 0.0, Math.sin(radian)).method_1029();
            class_243 targetPos = eyePos.method_1019(direction.method_1021(distance));
            class_3965 result = AutoCrossbow.mc.field_1687.method_17742(new class_3959(eyePos, targetPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)AutoCrossbow.mc.field_1724));
            results.add((class_239)result);
        }
        return results;
    }

    private void switchToCrossbow() {
        for (int i = 0; i < 9; ++i) {
            class_1799 itemStack = AutoCrossbow.mc.field_1724.method_31548().method_5438(i);
            if (!(itemStack.method_7909() instanceof class_1764)) continue;
            this.slot = AutoCrossbow.mc.field_1724.method_31548().field_7545;
            AutoCrossbow.mc.field_1724.method_31548().field_7545 = i;
            break;
        }
    }

    private void shootCrossbow() {
        if (AutoCrossbow.mc.field_1724.method_6047().method_7909() instanceof class_1764) {
            AutoCrossbow.mc.field_1761.method_2919((class_1657)AutoCrossbow.mc.field_1724, class_1268.field_5808);
        } else if (AutoCrossbow.mc.field_1724.method_6079().method_7909() instanceof class_1764) {
            AutoCrossbow.mc.field_1761.method_2919((class_1657)AutoCrossbow.mc.field_1724, class_1268.field_5810);
        }
    }
}
