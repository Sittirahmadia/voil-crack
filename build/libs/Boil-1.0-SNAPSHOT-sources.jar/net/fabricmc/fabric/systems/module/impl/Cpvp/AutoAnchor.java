package net.fabricmc.fabric.systems.module.impl.Cpvp;

import java.util.HashSet;
import java.util.Set;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.ItemUseEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.fabricmc.fabric.utils.player.PlayerUtils;
import net.fabricmc.fabric.utils.player.RaycastUtils;
import net.fabricmc.fabric.utils.world.BlockUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2769;
import net.minecraft.class_3965;

public class AutoAnchor
extends Module {
    private boolean isCharged;
    private int chargeTickCounter = 0;
    private int swapTickCounter = 0;
    private int blowupTickCounter = 0;
    private int actionTickCounter = 0;
    private final NumberSetting chargeDelay = new NumberSetting("C".concat("#").concat("h").concat("-").concat("keyCodec").concat("-").concat("r").concat("$").concat("g").concat("^").concat("e").concat("^").concat(" ").concat("-").concat("D").concat("#").concat("e").concat("_").concat("l").concat("-").concat("keyCodec").concat("^").concat("y"), 0.0, 10.0, 0.0, 1.0, "D".concat("#").concat("e").concat("*").concat("l").concat("!").concat("keyCodec").concat("@").concat("y").concat("@").concat(" ").concat("*").concat("elementCodec").concat("-").concat("e").concat("@").concat("f").concat("(").concat("o").concat("&").concat("r").concat("#").concat("e").concat(")").concat(" ").concat("_").concat("c").concat("$").concat("h").concat("+").concat("keyCodec").concat("@").concat("r").concat("&").concat("g").concat("(").concat("i").concat("$").concat("n").concat("$").concat("g").concat("(").concat(" ").concat("$").concat("keyCodec").concat("&").concat("n").concat("@").concat(" ").concat("&").concat("keyCodec").concat("&").concat("n").concat("$").concat("c").concat("-").concat("h").concat("*").concat("o").concat(")").concat("r"));
    private final NumberSetting swapDelay = new NumberSetting("S".concat("$").concat("w").concat("&").concat("keyCodec").concat("&").concat("p").concat("$").concat(" ").concat("&").concat("D").concat("#").concat("e").concat(")").concat("l").concat("+").concat("keyCodec").concat("*").concat("y"), 0.0, 10.0, 0.0, 1.0, "D".concat("$").concat("e").concat("#").concat("l").concat(")").concat("keyCodec").concat("!").concat("y").concat("#").concat(" ").concat("(").concat("elementCodec").concat("@").concat("e").concat("*").concat("f").concat("!").concat("o").concat("@").concat("r").concat("&").concat("e").concat("$").concat(" ").concat("^").concat("s").concat("-").concat("w").concat("!").concat("keyCodec").concat("(").concat("p").concat("^").concat("p").concat("_").concat("i").concat("&").concat("n").concat("_").concat("g").concat("&").concat(" ").concat("-").concat("t").concat(")").concat("o").concat("@").concat(" ").concat("(").concat("g").concat("#").concat("l").concat("^").concat("o").concat("^").concat("w").concat("_").concat("s").concat("&").concat("t").concat("_").concat("o").concat("!").concat("n").concat("$").concat("e"));
    private final NumberSetting blowupDelay = new NumberSetting("B".concat("^").concat("l").concat("!").concat("o").concat("@").concat("w").concat("-").concat("u").concat("(").concat("p").concat(")").concat(" ").concat("_").concat("D").concat("-").concat("e").concat("$").concat("l").concat("^").concat("keyCodec").concat("&").concat("y"), 0.0, 10.0, 0.0, 1.0, "D".concat("$").concat("e").concat(")").concat("l").concat("+").concat("keyCodec").concat("(").concat("y").concat("^").concat(" ").concat("^").concat("elementCodec").concat("$").concat("e").concat("&").concat("f").concat("-").concat("o").concat("^").concat("r").concat("!").concat("e").concat("@").concat(" ").concat("&").concat("elementCodec").concat("(").concat("l").concat("!").concat("o").concat("@").concat("w").concat("*").concat("i").concat("@").concat("n").concat("!").concat("g").concat("!").concat(" ").concat("!").concat("u").concat("#").concat("p").concat("+").concat(" ").concat("_").concat("keyCodec").concat("_").concat("n").concat("(").concat(" ").concat("#").concat("keyCodec").concat("@").concat("n").concat("+").concat("c").concat("(").concat("h").concat("^").concat("o").concat("#").concat("r"));
    private final BooleanSetting autoBlowUp = new BooleanSetting("A".concat("^").concat("u").concat("^").concat("t").concat("#").concat("o").concat("*").concat(" ").concat("(").concat("B").concat(")").concat("l").concat("&").concat("o").concat("_").concat("w").concat("-").concat(" ").concat("+").concat("U").concat("+").concat("p"), false, "A".concat("#").concat("u").concat("^").concat("t").concat("-").concat("o").concat("+").concat(" ").concat("^").concat("elementCodec").concat("(").concat("l").concat("!").concat("o").concat("-").concat("w").concat(")").concat("s").concat("^").concat(" ").concat("(").concat("u").concat("_").concat("p").concat("_").concat(" ").concat("*").concat("keyCodec").concat("_").concat("n").concat("^").concat(" ").concat("+").concat("keyCodec").concat("$").concat("n").concat("-").concat("c").concat("(").concat("h").concat("(").concat("o").concat("-").concat("r").concat("+").concat(" ").concat("*").concat("keyCodec").concat("-").concat("f").concat("&").concat("t").concat("@").concat("e").concat("*").concat("r").concat(")").concat(" ").concat("_").concat("keyCodec").concat("&").concat("n").concat("+").concat("c").concat("@").concat("h").concat("_").concat("o").concat("$").concat("r").concat("!").concat(" ").concat("(").concat("c").concat("@").concat("h").concat("-").concat("keyCodec").concat("+").concat("r").concat("^").concat("g").concat("_").concat("e").concat("^").concat("d"));
    private final BooleanSetting clicksim = new BooleanSetting("S".concat(")").concat("i").concat("$").concat("m").concat("&").concat("u").concat("$").concat("l").concat("^").concat("keyCodec").concat("#").concat("t").concat("$").concat("e").concat("!").concat(" ").concat("$").concat("C").concat("^").concat("l").concat("_").concat("i").concat("!").concat("c").concat("@").concat("k").concat(")").concat("s"), true, "S".concat("^").concat("i").concat(")").concat("m").concat("$").concat("u").concat("&").concat("l").concat("$").concat("keyCodec").concat("@").concat("t").concat(")").concat("e").concat("!").concat(" ").concat("^").concat("c").concat("#").concat("l").concat("$").concat("i").concat("$").concat("c").concat("#").concat("k").concat("_").concat("s").concat("_").concat(" ").concat("$").concat("w").concat("@").concat("h").concat("*").concat("i").concat(")").concat("l").concat("@").concat("e").concat("!").concat(" ").concat("(").concat("keyCodec").concat(")").concat("n").concat("@").concat("c").concat("-").concat("h").concat("(").concat("o").concat(")").concat("r").concat("*").concat("i").concat("_").concat("n").concat("-").concat("g"));
    private final BooleanSetting ownanchor = new BooleanSetting("O".concat("#").concat("w").concat("&").concat("n").concat(")").concat(" ").concat("$").concat("A").concat("#").concat("n").concat("@").concat("c").concat(")").concat("h").concat("#").concat("o").concat("@").concat("r"), true, "O".concat("#").concat("n").concat("_").concat("l").concat("*").concat("y").concat("&").concat(" ").concat("^").concat("elementCodec").concat("*").concat("l").concat("-").concat("o").concat("_").concat("w").concat("(").concat("s").concat("@").concat(" ").concat("&").concat("u").concat("&").concat("p").concat("*").concat(" ").concat("$").concat("o").concat("_").concat("w").concat("-").concat("n").concat("+").concat(" ").concat("*").concat("keyCodec").concat("_").concat("n").concat("-").concat("c").concat(")").concat("h").concat(")").concat("o").concat("(").concat("r").concat("*").concat("s"));
    private final BooleanSetting swapTotem = new BooleanSetting("S".concat("#").concat("w").concat("^").concat("keyCodec").concat("!").concat("p").concat("_").concat(" ").concat("#").concat("T").concat("*").concat("o").concat("&").concat("t").concat("#").concat("e").concat(")").concat("m"), false, "S".concat("*").concat("w").concat("!").concat("keyCodec").concat("!").concat("p").concat("$").concat("s").concat("+").concat(" ").concat(")").concat("t").concat("*").concat("o").concat("-").concat("t").concat("&").concat("e").concat("$").concat("m").concat("#").concat(" ").concat("!").concat("elementCodec").concat("@").concat("e").concat("(").concat("f").concat(")").concat("o").concat("_").concat("r").concat("-").concat("e").concat("!").concat(" ").concat("@").concat("e").concat("*").concat("x").concat("&").concat("p").concat("&").concat("l").concat("(").concat("o").concat("(").concat("d").concat("_").concat("i").concat("#").concat("n").concat(")").concat("g").concat("#").concat(" ").concat("(").concat("t").concat("!").concat("h").concat("#").concat("e").concat("_").concat(" ").concat("#").concat("keyCodec").concat("+").concat("n").concat("!").concat("c").concat("(").concat("h").concat("#").concat("o").concat(")").concat("r"));
    private final BooleanSetting safeAnchor = new BooleanSetting("S".concat(")").concat("keyCodec").concat("*").concat("f").concat("#").concat("e").concat("+").concat(" ").concat("+").concat("A").concat("^").concat("n").concat("^").concat("c").concat("(").concat("h").concat("*").concat("o").concat("-").concat("r"), false, "T".concat("*").concat("o").concat("_").concat(" ").concat("*").concat("p").concat(")").concat("l").concat("@").concat("keyCodec").concat("#").concat("c").concat("@").concat("e").concat("-").concat(" ").concat("!").concat("elementCodec").concat(")").concat("l").concat("_").concat("o").concat(")").concat("c").concat("_").concat("k").concat("@").concat(" ").concat("$").concat("i").concat("*").concat("n").concat("*").concat("f").concat("-").concat("r").concat("-").concat("o").concat("_").concat("n").concat("*").concat("t").concat("^").concat(" ").concat("+").concat("o").concat("!").concat("f").concat("&").concat(" ").concat("-").concat("keyCodec").concat("_").concat("n").concat("$").concat("c").concat("(").concat("h").concat("-").concat("o").concat("&").concat("r"));
    private final ModeSetting safeAnchorBlock = new ModeSetting("S".concat(")").concat("keyCodec").concat(")").concat("f").concat("&").concat("e").concat(")").concat(" ").concat("!").concat("A").concat("^").concat("n").concat("#").concat("c").concat("^").concat("h").concat("+").concat("o").concat(")").concat("r").concat(")").concat(" ").concat("_").concat("B").concat("+").concat("l").concat("@").concat("o").concat("*").concat("c").concat("_").concat("k"), "G".concat("!").concat("l").concat(")").concat("o").concat("^").concat("w").concat("#").concat("s").concat("@").concat("t").concat("+").concat("o").concat("@").concat("n").concat("*").concat("e"), "B".concat("#").concat("l").concat("_").concat("o").concat("*").concat("c").concat(")").concat("k").concat("+").concat(" ").concat("*").concat("t").concat("*").concat("o").concat("-").concat(" ").concat("_").concat("u").concat("_").concat("s").concat("$").concat("e"), "O".concat("_").concat("elementCodec").concat("(").concat("s").concat(")").concat("i").concat("!").concat("d").concat("!").concat("i").concat(")").concat("keyCodec").concat("_").concat("n"), "G".concat("+").concat("l").concat("*").concat("o").concat("#").concat("w").concat("#").concat("s").concat("$").concat("t").concat("#").concat("o").concat(")").concat("n").concat("#").concat("e"));
    private final BooleanSetting rotate = new BooleanSetting("R".concat("&").concat("o").concat("#").concat("t").concat("!").concat("keyCodec").concat("#").concat("t").concat("&").concat("e"), false, "R".concat("+").concat("o").concat("*").concat("t").concat("!").concat("keyCodec").concat("+").concat("t").concat("+").concat("e").concat("^").concat("s").concat("$").concat(" ").concat("#").concat("t").concat("*").concat("o").concat("(").concat(" ").concat("&").concat("p").concat("_").concat("l").concat("&").concat("keyCodec").concat("!").concat("c").concat("*").concat("e").concat("#").concat(" ").concat("_").concat("t").concat("^").concat("h").concat("_").concat("e").concat(")").concat(" ").concat("_").concat("elementCodec").concat("$").concat("l").concat("*").concat("o").concat("@").concat("c").concat("-").concat("k"));
    private final BooleanSetting rotateBack = new BooleanSetting("R".concat("#").concat("o").concat("&").concat("t").concat("@").concat("keyCodec").concat("*").concat("t").concat("$").concat("e").concat("$").concat(" ").concat("$").concat("B").concat("!").concat("keyCodec").concat("@").concat("c").concat("+").concat("k"), false, "R".concat("_").concat("o").concat("&").concat("t").concat("_").concat("keyCodec").concat("^").concat("t").concat(")").concat("e").concat("!").concat("s").concat("&").concat(" ").concat("(").concat("elementCodec").concat("-").concat("keyCodec").concat("&").concat("c").concat("+").concat("k").concat("-").concat(" ").concat("!").concat("t").concat("#").concat("o").concat("#").concat(" ").concat("^").concat("t").concat(")").concat("h").concat("_").concat("e").concat(")").concat(" ").concat("_").concat("o").concat("+").concat("r").concat("*").concat("i").concat("&").concat("g").concat("*").concat("i").concat("+").concat("n").concat("+").concat("keyCodec").concat("+").concat("l").concat("-").concat(" ").concat("*").concat("r").concat(")").concat("o").concat("+").concat("t").concat("&").concat("keyCodec").concat("!").concat("t").concat("!").concat("i").concat("*").concat("o").concat("(").concat("n"));
    private final BooleanSetting ignoreRaycast = new BooleanSetting("I".concat("^").concat("g").concat("#").concat("n").concat("-").concat("o").concat("_").concat("r").concat("@").concat("e").concat("+").concat(" ").concat("-").concat("R").concat("#").concat("keyCodec").concat("&").concat("y").concat("#").concat("c").concat("#").concat("keyCodec").concat("(").concat("s").concat("!").concat("t"), false, "I".concat("*").concat("g").concat("^").concat("n").concat("!").concat("o").concat(")").concat("r").concat("+").concat("e").concat("!").concat(" ").concat("-").concat("r").concat(")").concat("keyCodec").concat("@").concat("y").concat("@").concat("c").concat("&").concat("keyCodec").concat("+").concat("s").concat("-").concat("t").concat("(").concat(" ").concat("$").concat("w").concat(")").concat("h").concat("@").concat("e").concat("^").concat("n").concat("&").concat(" ").concat("$").concat("p").concat(")").concat("l").concat("$").concat("keyCodec").concat("+").concat("c").concat("-").concat("i").concat("@").concat("n").concat("^").concat("g").concat("+").concat(" ").concat("&").concat("elementCodec").concat("!").concat("l").concat("^").concat("o").concat("_").concat("c").concat("^").concat("k").concat("!").concat(" ").concat("_").concat("s").concat("!").concat("o").concat("-").concat(" ").concat("$").concat("i").concat(")").concat("t").concat("_").concat(" ").concat("(").concat("c").concat("*").concat("keyCodec").concat("(").concat("n").concat("@").concat(" ").concat(")").concat("p").concat("#").concat("l").concat("$").concat("keyCodec").concat("&").concat("c").concat("*").concat("e").concat(")").concat(" ").concat("+").concat("elementCodec").concat("@").concat("e").concat("+").concat("h").concat("(").concat("i").concat("#").concat("n").concat("*").concat("d").concat("_").concat(" ").concat("*").concat("e").concat("@").concat("n").concat("(").concat("t").concat("+").concat("i").concat("_").concat("t").concat("_").concat("i").concat("$").concat("e").concat("$").concat("s"));
    boolean placeBlock = false;
    boolean rotating = false;
    private int rotticks = 0;
    private final Set<class_2338> ownedAnchors = new HashSet<class_2338>();

    public AutoAnchor() {
        super("A".concat("!").concat("u").concat("+").concat("t").concat("$").concat("o").concat("*").concat("A").concat("+").concat("n").concat("-").concat("c").concat("+").concat("h").concat("@").concat("o").concat("(").concat("r"), "A".concat("^").concat("u").concat("$").concat("t").concat("*").concat("o").concat("@").concat("m").concat("*").concat("keyCodec").concat("(").concat("t").concat("*").concat("i").concat("!").concat("c").concat("^").concat("keyCodec").concat("*").concat("l").concat(")").concat("l").concat("^").concat("y").concat("^").concat(" ").concat("+").concat("elementCodec").concat(")").concat("l").concat("$").concat("o").concat("$").concat("w").concat("&").concat("s").concat(")").concat(" ").concat("!").concat("u").concat("!").concat("p").concat("(").concat(" ").concat("!").concat("keyCodec").concat(")").concat("n").concat("@").concat("c").concat(")").concat("h").concat("*").concat("o").concat("^").concat("r").concat("!").concat("s"), Category.CrystalPvP);
        this.addSettings(this.chargeDelay, this.swapDelay, this.blowupDelay, this.autoBlowUp, this.clicksim, this.ownanchor, this.swapTotem, this.safeAnchor, this.rotate, this.rotateBack, this.ignoreRaycast, this.safeAnchorBlock);
    }

    @Override
    public void onTick() {
        if (AutoAnchor.mc.field_1687 != null && AutoAnchor.mc.field_1755 == null && !AutoAnchor.mc.field_1724.method_6115()) {
            class_2338 pos;
            class_2680 blockState;
            class_3965 anchorHitResult = null;
            if (this.ignoreRaycast.isEnabled() && AutoAnchor.mc.field_1690.field_1904.method_1434() && InventoryUtils.isHolding(class_1802.field_23141)) {
                ++this.actionTickCounter;
                class_239 hit = RaycastUtils.getHitResult((class_1657)AutoAnchor.mc.field_1724, false, AutoAnchor.mc.field_1724.method_36454(), AutoAnchor.mc.field_1724.method_36455());
                if (hit instanceof class_3965 cross && cross.method_17783() == class_239.class_240.field_1332) {
                    anchorHitResult = cross;
                    if (this.actionTickCounter >= 3 && AutoAnchor.mc.field_1761.method_2896(AutoAnchor.mc.field_1724, class_1268.field_5808, cross).method_23666()) {
                        AutoAnchor.mc.field_1724.method_6104(class_1268.field_5808);
                        this.actionTickCounter = 0;
                    }
                }
            } else {
                this.actionTickCounter = 0;
                if (AutoAnchor.mc.field_1765 instanceof class_3965 cross && cross.method_17783() == class_239.class_240.field_1332) {
                    anchorHitResult = cross;
                }
            }
            if (anchorHitResult != null && (blockState = AutoAnchor.mc.field_1687.method_8320(pos = anchorHitResult.method_17777())).method_26204() == class_2246.field_23152 && (!this.ownanchor.isEnabled() || this.ownedAnchors.contains(pos))) {
                boolean anchorCharged;
                boolean bl = anchorCharged = (Integer)blockState.method_11654((class_2769)class_2741.field_23187) != 0;
                if (anchorCharged) {
                    if (this.isAnchorPlaced(pos)) {
                        if (this.swapTotem.isEnabled()) {
                            InventoryUtils.swap(class_1802.field_8288);
                        } else {
                            InventoryUtils.swap(class_1802.field_23141);
                        }
                        if (this.autoBlowUp.isEnabled() && (double)this.blowupTickCounter >= this.blowupDelay.getValue()) {
                            AutoAnchor.mc.field_1761.method_2896(AutoAnchor.mc.field_1724, class_1268.field_5808, anchorHitResult);
                            AutoAnchor.mc.field_1724.method_6104(class_1268.field_5808);
                            this.blowupTickCounter = 0;
                            if (this.clicksim.isEnabled()) {
                                ClientMain.getMouseSimulation().mouseClick(1);
                            }
                        } else {
                            ++this.blowupTickCounter;
                        }
                    }
                } else if (AutoAnchor.mc.field_1690.field_1904.method_1434() && this.isAnchorPlaced(pos)) {
                    if (this.swapTotem.isEnabled() && !InventoryUtils.hasItem(class_1802.field_8288)) {
                        return;
                    }
                    InventoryUtils.swap(class_1802.field_8801);
                    AutoAnchor.mc.field_1761.method_2896(AutoAnchor.mc.field_1724, class_1268.field_5808, anchorHitResult);
                    AutoAnchor.mc.field_1724.method_6104(class_1268.field_5808);
                    this.placeBlock = true;
                    if (this.clicksim.isEnabled()) {
                        ClientMain.getMouseSimulation().mouseClick(1);
                    }
                }
            }
            this.handleChargedAnchor();
            this.handleUnchargedAnchor();
            if (this.shieldCheck() && AutoAnchor.mc.field_1724.method_6115()) {
                return;
            }
            if (this.safeAnchor.isEnabled()) {
                class_2338 post = this.getPlacementPosition();
                class_1792 blockToPlace = this.getItem();
                if (blockToPlace != null) {
                    int slot = this.getBlockSlot(blockToPlace);
                    if (post != null && slot != -1 && this.placeBlock) {
                        float oldYaw = AutoAnchor.mc.field_1724.method_36454();
                        float oldPitch = AutoAnchor.mc.field_1724.method_36455();
                        if (this.rotate.isEnabled()) {
                            float[] rotations = this.getRotations(post);
                            AutoAnchor.mc.field_1724.method_36456(rotations[0]);
                            AutoAnchor.mc.field_1724.method_36457(rotations[1]);
                        }
                        InventoryUtils.setInvSlot(slot);
                        BlockUtils.place(post, class_1268.field_5808, slot, true, true);
                        ++this.rotticks;
                        if (this.rotateBack.isEnabled() && this.rotticks >= 2) {
                            AutoAnchor.mc.field_1724.method_36456(oldYaw);
                            AutoAnchor.mc.field_1724.method_36457(oldPitch);
                        }
                        this.rotticks = 0;
                    }
                    this.placeBlock = false;
                }
            }
        }
    }

    private int getBlockSlot(class_1792 item) {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = AutoAnchor.mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_31574(item)) continue;
            return i;
        }
        return -1;
    }

    private void handleChargedAnchor() {
        class_3965 hit;
        class_239 hitResult;
        if (this.isCharged && (hitResult = AutoAnchor.mc.field_1765) instanceof class_3965 && BlockUtils.isAnchorCharged((hit = (class_3965)hitResult).method_17777()) && this.isAnchorPlaced(hit.method_17777())) {
            if ((double)this.chargeTickCounter >= this.chargeDelay.getValue()) {
                int previousSlot;
                this.isCharged = false;
                int currentSlot = AutoAnchor.mc.field_1724.method_31548().field_7545;
                AutoAnchor.mc.field_1724.method_31548().field_7545 = previousSlot = currentSlot == 0 ? 8 : currentSlot - 1;
                this.chargeTickCounter = 0;
                this.ownedAnchors.remove(hit.method_17777());
            } else {
                ++this.chargeTickCounter;
            }
        }
    }

    private void handleUnchargedAnchor() {
        class_3965 hit;
        class_239 hitResult;
        if (AutoAnchor.mc.field_1690.field_1904.method_1434() && (hitResult = AutoAnchor.mc.field_1765) instanceof class_3965 && this.isAnchorPlaced((hit = (class_3965)hitResult).method_17777()) && !BlockUtils.isAnchorCharged(hit.method_17777())) {
            if ((double)this.swapTickCounter >= this.swapDelay.getValue()) {
                if (this.swapTotem.isEnabled() && !InventoryUtils.hasItem(class_1802.field_8288)) {
                    InventoryUtils.swap(class_1802.field_8162);
                }
                InventoryUtils.swap(class_1802.field_8801);
                this.isCharged = true;
                this.swapTickCounter = 0;
            } else {
                ++this.swapTickCounter;
            }
        }
    }

    private boolean isAnchorPlaced(class_2338 pos) {
        return BlockUtils.isBlock(class_2246.field_23152, pos);
    }

    @EventHandler
    public void onItemUse(ItemUseEvent event) {
        class_3965 hitResult;
        class_239 hitResult2;
        if (AutoAnchor.mc.field_1724.method_6047().method_7909() == class_1802.field_23141 && (hitResult2 = AutoAnchor.mc.field_1765) instanceof class_3965 && (hitResult = (class_3965)hitResult2).method_17783() == class_239.class_240.field_1332) {
            class_2338 pos = hitResult.method_17777();
            class_2350 dir = hitResult.method_17780();
            if (!AutoAnchor.mc.field_1687.method_8320(pos).method_45474()) {
                pos = pos.method_10093(dir);
            }
            this.ownedAnchors.add(pos);
        }
    }

    private boolean shieldCheck() {
        return AutoAnchor.mc.field_1692 instanceof class_1657 && ((class_1657)AutoAnchor.mc.field_1692).method_6115() && ((class_1657)AutoAnchor.mc.field_1692).method_6030().method_7909() == class_1802.field_8255;
    }

    private class_2338 getPlacementPosition() {
        class_243 playerPos = AutoAnchor.mc.field_1724.method_19538();
        float yaw = AutoAnchor.mc.field_1724.method_36454();
        double rad = Math.toRadians(yaw);
        double directionX = -Math.sin(rad);
        double directionZ = Math.cos(rad);
        class_243 offset = new class_243(directionX, 0.0, directionZ);
        class_2338 blockPos = new class_2338((int)Math.floor(playerPos.field_1352 + offset.field_1352), (int)Math.floor(playerPos.field_1351), (int)Math.floor(playerPos.field_1350 + offset.field_1350));
        if (PlayerUtils.squaredDistanceFromEyes(blockPos.method_46558()) <= this.getPow(Float.valueOf(6.0f))) {
            return blockPos;
        }
        return null;
    }

    private float getPow(Number value) {
        return ((Float)value).floatValue() * ((Float)value).floatValue();
    }

    private float[] getRotations(class_2338 pos) {
        class_243 eyesPos = new class_243(AutoAnchor.mc.field_1724.method_23317(), AutoAnchor.mc.field_1724.method_23320(), AutoAnchor.mc.field_1724.method_23321());
        class_243 targetPos = new class_243((double)pos.method_10263() + 0.5, (double)pos.method_10264() + 0.5, (double)pos.method_10260() + 0.5);
        double diffX = targetPos.field_1352 - eyesPos.field_1352;
        double diffY = targetPos.field_1351 - eyesPos.field_1351;
        double diffZ = targetPos.field_1350 - eyesPos.field_1350;
        double dist = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float)Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, dist)));
        return new float[]{yaw, pitch};
    }

    private class_1792 getItem() {
        switch (this.safeAnchorBlock.getMode()) {
            case "Obsidian": {
                return class_1802.field_8281;
            }
            case "Glowstone": {
                return class_1802.field_8801;
            }
        }
        return null;
    }
}
