package net.fabricmc.fabric.systems.module.impl.misc;

import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.mixin.IHandledScreenAccessor;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_1657;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_437;
import net.minecraft.class_476;

public class ChestStealer
extends Module {
    private final ModeSetting mode = new ModeSetting("M".concat(")").concat("o").concat(")").concat("d").concat(")").concat("e"), "P".concat("-").concat("keyCodec").concat("&").concat("c").concat("_").concat("k").concat(")").concat("e").concat("+").concat("t"), "M".concat("&").concat("o").concat(")").concat("d").concat("#").concat("e").concat("+").concat(" ").concat(")").concat("f").concat("!").concat("o").concat(")").concat("r").concat("@").concat(" ").concat("!").concat("s").concat(")").concat("t").concat("!").concat("e").concat("@").concat("keyCodec").concat("*").concat("l").concat("(").concat("i").concat("@").concat("n").concat("#").concat("g"), "M".concat("_").concat("keyCodec").concat("@").concat("n").concat("!").concat("u").concat("(").concat("keyCodec").concat("$").concat("l"), "P".concat(")").concat("keyCodec").concat("@").concat("c").concat(")").concat("k").concat("*").concat("e").concat("-").concat("t"));
    private final NumberSetting delay = new NumberSetting("D".concat("!").concat("e").concat("&").concat("l").concat("@").concat("keyCodec").concat("-").concat("y"), 0.0, 5.0, 2.0, 1.0, "D".concat("!").concat("e").concat("*").concat("l").concat(")").concat("keyCodec").concat("^").concat("y").concat("^").concat(" ").concat("+").concat("elementCodec").concat("&").concat("e").concat("#").concat("f").concat("*").concat("o").concat("$").concat("r").concat("(").concat("e").concat("+").concat(" ").concat("!").concat("g").concat("_").concat("e").concat("*").concat("t").concat(")").concat("t").concat(")").concat("i").concat("$").concat("n").concat("_").concat("g").concat("^").concat(" ").concat("&").concat("s").concat("$").concat("t").concat("$").concat("u").concat(")").concat("f").concat("#").concat("f").concat("-").concat(" ").concat("*").concat("f").concat("(").concat("r").concat("_").concat("o").concat("&").concat("m").concat(")").concat(" ").concat("_").concat("c").concat("&").concat("h").concat("&").concat("e").concat("-").concat("s").concat("#").concat("t"));
    private final BooleanSetting autoClose = new BooleanSetting("A".concat("-").concat("u").concat(")").concat("t").concat("_").concat("o").concat("-").concat(" ").concat("+").concat("C").concat("-").concat("l").concat("+").concat("o").concat("&").concat("s").concat("!").concat("e"), true, "A".concat("+").concat("u").concat("!").concat("t").concat("_").concat("o").concat("#").concat("m").concat("_").concat("keyCodec").concat("_").concat("t").concat("#").concat("i").concat(")").concat("c").concat("*").concat("keyCodec").concat("_").concat("l").concat("&").concat("l").concat("*").concat("y").concat("!").concat(" ").concat("_").concat("c").concat("_").concat("l").concat("*").concat("o").concat("!").concat("s").concat("!").concat("e").concat("&").concat("s").concat("*").concat(" ").concat("@").concat("c").concat(")").concat("h").concat("@").concat("e").concat("^").concat("s").concat("#").concat("t").concat("#").concat(" ").concat("#").concat("keyCodec").concat("+").concat("f").concat("!").concat("t").concat("_").concat("e").concat("+").concat("r").concat("(").concat(" ").concat("!").concat("s").concat("-").concat("t").concat("*").concat("e").concat("#").concat("keyCodec").concat("(").concat("l").concat("*").concat("i").concat(")").concat("n").concat("_").concat("g"));
    private long lastActionTime = 0L;
    private int swapClock;

    public ChestStealer() {
        super("C".concat("^").concat("h").concat("_").concat("e").concat("+").concat("s").concat("(").concat("t").concat("&").concat("S").concat("&").concat("t").concat(")").concat("e").concat("&").concat("keyCodec").concat("-").concat("l").concat("(").concat("e").concat("^").concat("r"), "A".concat("&").concat("u").concat("&").concat("t").concat("*").concat("o").concat("!").concat("m").concat("*").concat("keyCodec").concat("#").concat("t").concat("$").concat("i").concat("^").concat("c").concat("!").concat("keyCodec").concat("*").concat("l").concat("&").concat("l").concat("+").concat("y").concat("$").concat(" ").concat("_").concat("s").concat("$").concat("t").concat("(").concat("e").concat("@").concat("keyCodec").concat("$").concat("l").concat("*").concat("s").concat("@").concat(" ").concat(")").concat("s").concat("@").concat("t").concat("+").concat("u").concat("#").concat("f").concat("+").concat("f").concat("@").concat(" ").concat("&").concat("f").concat("+").concat("r").concat("+").concat("o").concat(")").concat("m").concat("!").concat(" ").concat("#").concat("c").concat("(").concat("h").concat("#").concat("e").concat("&").concat("s").concat(")").concat("t").concat("$").concat("s"), Category.Miscellaneous);
        this.addSettings(this.mode, this.delay, this.autoClose);
    }

    @Override
    public void onEnable() {
        this.swapClock = 0;
    }

    @Override
    public void onTick() {
        if (ChestStealer.mc.field_1724 == null || ChestStealer.mc.field_1687 == null) {
            return;
        }
        class_437 screen = ChestStealer.mc.field_1755;
        if (screen instanceof class_476) {
            class_476 containerScreen = (class_476)screen;
            class_1735 focusedSlot = ((IHandledScreenAccessor)containerScreen).getFocusedSlot();
            if (this.mode.getMode().equalsIgnoreCase("Packet")) {
                this.autoSteal(containerScreen);
                if (this.autoClose.isEnabled() && this.allSlotsEmpty(containerScreen)) {
                    ChestStealer.mc.field_1724.method_7346();
                }
            } else if (this.mode.getMode().equalsIgnoreCase("Manual") && focusedSlot != null) {
                this.manualSteal(containerScreen, focusedSlot);
            }
        }
    }

    private void autoSteal(class_476 containerScreen) {
        for (class_1735 slot : ((class_1707)containerScreen.method_17577()).field_7761) {
            if (slot.method_7677().method_7960() || !this.hasEmptySlots()) continue;
            if (this.swapClock < this.delay.getIValue()) {
                ++this.swapClock;
                return;
            }
            ChestStealer.mc.field_1761.method_2906(((class_1707)containerScreen.method_17577()).field_7763, slot.method_34266(), 0, class_1713.field_7794, (class_1657)ChestStealer.mc.field_1724);
            this.swapClock = 0;
        }
    }

    private void manualSteal(class_476 containerScreen, class_1735 focusedSlot) {
        if (!focusedSlot.method_7677().method_7960() && this.hasEmptySlots() && focusedSlot.method_7681()) {
            if (this.swapClock < this.delay.getIValue()) {
                ++this.swapClock;
                return;
            }
            ChestStealer.mc.field_1761.method_2906(((class_1707)containerScreen.method_17577()).field_7763, focusedSlot.method_34266(), 0, class_1713.field_7794, (class_1657)ChestStealer.mc.field_1724);
            this.swapClock = 0;
        }
    }

    private boolean allSlotsEmpty(class_476 containerScreen) {
        for (class_1735 slot : ((class_1707)containerScreen.method_17577()).field_7761) {
            if (slot.method_7677().method_7960()) continue;
            return false;
        }
        return true;
    }

    public boolean hasEmptySlots() {
        return ChestStealer.mc.field_1724.method_31548().method_7376() != -1;
    }
}
