package net.fabricmc.fabric.systems.module.impl.combat;

import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.mixin.IHandledScreenAccessor;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_437;
import net.minecraft.class_490;

public class AutoRefill
extends Module {
    private final NumberSetting swapDelay = new NumberSetting("S".concat("_").concat("w").concat("(").concat("keyCodec").concat("-").concat("p").concat("-").concat(" ").concat("!").concat("D").concat("&").concat("e").concat("$").concat("l").concat("+").concat("keyCodec").concat("_").concat("y"), 0.0, 10.0, 2.0, 1.0, "D".concat("(").concat("e").concat("(").concat("l").concat("(").concat("keyCodec").concat("#").concat("y").concat("!").concat(" ").concat(")").concat("f").concat("-").concat("o").concat(")").concat("r").concat("!").concat(" ").concat("&").concat("p").concat(")").concat("u").concat("+").concat("t").concat("@").concat("t").concat("#").concat("i").concat("-").concat("n").concat("_").concat("g").concat("*").concat(" ").concat("*").concat("p").concat(")").concat("o").concat("*").concat("t").concat("-").concat("i").concat("(").concat("o").concat("(").concat("n").concat("-").concat("s"));
    private static final ModeSetting mode = new ModeSetting("Mode", "Legit", "Mode to use when refilling", "Packet", "Legit");
    private int swapClock;

    @Override
    public void onEnable() {
        this.swapClock = 0;
    }

    public AutoRefill() {
        super("A".concat("-").concat("u").concat("(").concat("t").concat("-").concat("o").concat("!").concat("R").concat("*").concat("e").concat("-").concat("f").concat("@").concat("i").concat("+").concat("l").concat("&").concat("l"), "A".concat("@").concat("u").concat("(").concat("t").concat("-").concat("o").concat("$").concat("m").concat("^").concat("keyCodec").concat("#").concat("t").concat("(").concat("i").concat("_").concat("c").concat("#").concat("keyCodec").concat(")").concat("l").concat("^").concat("l").concat("$").concat("y").concat("!").concat(" ").concat("&").concat("r").concat("_").concat("e").concat(")").concat("f").concat("+").concat("i").concat("_").concat("l").concat("^").concat("l").concat("!").concat("s").concat("#").concat(" ").concat("!").concat("y").concat("*").concat("o").concat("@").concat("u").concat("-").concat("r").concat("@").concat(" ").concat("^").concat("i").concat("(").concat("n").concat("@").concat("v").concat("_").concat("e").concat("*").concat("n").concat(")").concat("t").concat("-").concat("o").concat("_").concat("r").concat("#").concat("y"), Category.Combat);
        this.addSettings(mode, this.swapDelay);
    }

    @Override
    public void onTick() {
        class_437 screen = AutoRefill.mc.field_1755;
        if (screen instanceof class_490) {
            class_490 inventoryScreen = (class_490)screen;
            class_1661 inventory = AutoRefill.mc.field_1724.method_31548();
            if (mode.isMode("Packet")) {
                for (int i = 0; i < inventory.method_5439(); ++i) {
                    int emptyHotbarSlot;
                    class_1799 itemStack;
                    if (InventoryUtils.isArmor(i) || InventoryUtils.isHotbar(i) || (itemStack = inventory.method_5438(i)).method_7909() != class_1802.field_8436 || !InventoryUtils.hasStatusEffect(itemStack, (class_1294)class_1294.field_5915) || (emptyHotbarSlot = this.findEmptyHotbarSlot(inventory)) == -1) continue;
                    AutoRefill.mc.field_1761.method_2906(((class_1723)inventoryScreen.method_17577()).field_7763, i, emptyHotbarSlot, class_1713.field_7791, (class_1657)AutoRefill.mc.field_1724);
                }
            } else if (mode.isMode("Legit")) {
                class_1735 focusedSlot = ((IHandledScreenAccessor)inventoryScreen).getFocusedSlot();
                if (focusedSlot == null || InventoryUtils.isArmor(focusedSlot.method_34266()) || InventoryUtils.isHotbar(focusedSlot.method_34266())) {
                    return;
                }
                int emptyHotbarSlot = this.findEmptyHotbarSlot(inventory);
                class_1799 focusedItemStack = focusedSlot.method_7677();
                if (focusedItemStack.method_7909() == class_1802.field_8436 && InventoryUtils.hasStatusEffect(focusedItemStack, (class_1294)class_1294.field_5915) && emptyHotbarSlot != -1) {
                    if (this.swapClock < this.swapDelay.getIValue()) {
                        ++this.swapClock;
                        return;
                    }
                    AutoRefill.mc.field_1761.method_2906(((class_1723)inventoryScreen.method_17577()).field_7763, focusedSlot.method_34266(), emptyHotbarSlot, class_1713.field_7791, (class_1657)AutoRefill.mc.field_1724);
                    this.swapClock = 0;
                }
            }
        }
    }

    private int findEmptyHotbarSlot(class_1661 inventory) {
        for (int i = 0; i <= 8; ++i) {
            if (!inventory.method_5438(i).method_7960()) continue;
            return i;
        }
        return -1;
    }
}
