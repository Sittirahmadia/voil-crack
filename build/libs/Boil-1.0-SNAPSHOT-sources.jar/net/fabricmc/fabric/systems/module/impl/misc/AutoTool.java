package net.fabricmc.fabric.systems.module.impl.misc;

import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.BlockBreakEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;

public class AutoTool
extends Module {
    private int originalSlot = -1;
    private final BooleanSetting switchBack = new BooleanSetting("S".concat("+").concat("w").concat("*").concat("i").concat("!").concat("t").concat("@").concat("c").concat("$").concat("h").concat("_").concat(" ").concat("(").concat("elementCodec").concat("+").concat("keyCodec").concat(")").concat("c").concat(")").concat("k"), true, "S".concat("@").concat("w").concat("&").concat("i").concat(")").concat("t").concat("-").concat("c").concat("#").concat("h").concat("_").concat(" ").concat("(").concat("elementCodec").concat("-").concat("keyCodec").concat("@").concat("c").concat("_").concat("k").concat("@").concat(" ").concat("_").concat("t").concat("(").concat("o").concat("&").concat(" ").concat("+").concat("o").concat("^").concat("l").concat("^").concat("d").concat("#").concat(" ").concat("(").concat("s").concat("*").concat("l").concat("_").concat("o").concat(")").concat("t").concat("^").concat(" ").concat("_").concat("keyCodec").concat(")").concat("f").concat("&").concat("t").concat("+").concat("e").concat("&").concat("r").concat("-").concat(" ").concat("_").concat("elementCodec").concat(")").concat("r").concat("(").concat("e").concat("@").concat("keyCodec").concat("&").concat("k").concat("_").concat("i").concat(")").concat("n").concat("#").concat("g"));

    public AutoTool() {
        super("A".concat("_").concat("u").concat("(").concat("t").concat("!").concat("o").concat("!").concat("T").concat("@").concat("o").concat("@").concat("o").concat("$").concat("l"), "A".concat("_").concat("u").concat("@").concat("t").concat("(").concat("o").concat("*").concat("m").concat("!").concat("keyCodec").concat("-").concat("t").concat("-").concat("i").concat("-").concat("c").concat("&").concat("keyCodec").concat("-").concat("l").concat("-").concat("l").concat(")").concat("y").concat("^").concat(" ").concat("(").concat("s").concat("-").concat("w").concat("^").concat("i").concat("^").concat("t").concat("#").concat("c").concat("!").concat("h").concat("@").concat("e").concat("&").concat("s").concat("!").concat(" ").concat("&").concat("t").concat("!").concat("o").concat("_").concat(" ").concat("(").concat("elementCodec").concat("^").concat("e").concat("+").concat("s").concat("+").concat("t").concat("_").concat(" ").concat("*").concat("t").concat(")").concat("o").concat("-").concat("o").concat("!").concat("l"), Category.Miscellaneous);
        this.addSettings(this.switchBack);
    }

    @Override
    public void onTick() {
        class_239 hitResult = AutoTool.mc.field_1765;
        if (!(hitResult instanceof class_3965)) {
            return;
        }
        class_3965 blockHitResult = (class_3965)hitResult;
        class_2338 blockPos = blockHitResult.method_17777();
        if (AutoTool.mc.field_1687.method_8320(blockPos).method_26215()) {
            return;
        }
        int bestToolSlot = InventoryUtils.findFastestTool(AutoTool.mc.field_1687.method_8320(blockPos)).getSlot();
        if (bestToolSlot == -1) {
            return;
        }
        if (AutoTool.mc.field_1690.field_1886.method_1434()) {
            if (this.originalSlot == -1) {
                this.originalSlot = AutoTool.mc.field_1724.method_31548().field_7545;
            }
            AutoTool.mc.field_1724.method_31548().field_7545 = bestToolSlot;
        }
    }

    @EventHandler
    public void onBreakBlock(BlockBreakEvent.Post e) {
        if (this.switchBack.isEnabled() && this.originalSlot != -1 && AutoTool.mc.field_1724.method_31548().field_7545 != this.originalSlot) {
            AutoTool.mc.field_1724.method_31548().field_7545 = this.originalSlot;
            this.originalSlot = -1;
        }
    }
}
