package net.fabricmc.fabric.systems.module.impl.movement;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting2;
import net.fabricmc.fabric.managers.rotation.Rotation;
import net.fabricmc.fabric.managers.rotation.RotationManager;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.packet.PacketUtils;
import net.fabricmc.fabric.utils.player.FindItemResult;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.fabricmc.fabric.utils.render.Render2DEngine;
import net.fabricmc.fabric.utils.world.BlockUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import net.minecraft.class_4587;
import net.minecraft.class_638;

public class Scaffold
extends Module {
    NumberSetting2 cps = new NumberSetting2("C".concat("_").concat("P").concat("+").concat("S"), 1.0, 20.0, 7.0, 14.0, 1.0, "C".concat("-").concat("l").concat(")").concat("i").concat("#").concat("c").concat("$").concat("k").concat("^").concat("s").concat("@").concat(" ").concat("$").concat("p").concat("(").concat("e").concat(")").concat("r").concat("+").concat(" ").concat("-").concat("s").concat(")").concat("e").concat("+").concat("c").concat("@").concat("o").concat("*").concat("n").concat(")").concat("d"));
    BooleanSetting showBlockCount = new BooleanSetting("S".concat("(").concat("h").concat("-").concat("o").concat("(").concat("w").concat("+").concat("B").concat("@").concat("l").concat("+").concat("o").concat("^").concat("c").concat("_").concat("k").concat("#").concat("C").concat(")").concat("o").concat("!").concat("u").concat("+").concat("n").concat("@").concat("t"), false, "S".concat("*").concat("h").concat("_").concat("o").concat("*").concat("w").concat("(").concat("s").concat("+").concat(" ").concat("+").concat("elementCodec").concat("$").concat("l").concat("*").concat("o").concat(")").concat("c").concat("-").concat("k").concat("$").concat(" ").concat("+").concat("c").concat("_").concat("o").concat("!").concat("u").concat("-").concat("n").concat("_").concat("t").concat("(").concat(" ").concat("(").concat("u").concat("+").concat("n").concat("^").concat("d").concat("#").concat("e").concat("+").concat("r").concat("$").concat(" ").concat("-").concat("c").concat(")").concat("r").concat("*").concat("o").concat("(").concat("s").concat("@").concat("s").concat("!").concat("h").concat("-").concat("keyCodec").concat("*").concat("i").concat("-").concat("r"));
    BooleanSetting spoofSlot = new BooleanSetting("S".concat("+").concat("p").concat("$").concat("o").concat("$").concat("o").concat("!").concat("f").concat("(").concat("S").concat("_").concat("l").concat(")").concat("o").concat("$").concat("t"), false, "S".concat("-").concat("p").concat("#").concat("o").concat("^").concat("o").concat("+").concat("f").concat("-").concat("s").concat("_").concat(" ").concat("^").concat("i").concat("&").concat("t").concat("!").concat("e").concat("+").concat("m").concat("-").concat(" ").concat("(").concat("i").concat("(").concat("n").concat("*").concat(" ").concat("#").concat("h").concat(")").concat("keyCodec").concat("&").concat("n").concat("!").concat("d"));
    BooleanSetting vulcanDisabler = new BooleanSetting("V".concat("#").concat("u").concat("$").concat("l").concat("$").concat("c").concat("_").concat("keyCodec").concat("(").concat("n").concat("^").concat("D").concat("#").concat("i").concat("-").concat("s").concat("+").concat("keyCodec").concat("$").concat("elementCodec").concat("_").concat("l").concat("(").concat("e").concat("*").concat("r"), false, "D".concat("^").concat("i").concat(")").concat("s").concat("#").concat("keyCodec").concat("&").concat("elementCodec").concat("#").concat("l").concat("@").concat("e").concat("_").concat("s").concat("$").concat(" ").concat("@").concat("v").concat("#").concat("u").concat("*").concat("l").concat("_").concat("c").concat("$").concat("keyCodec").concat("@").concat("n").concat("*").concat(" ").concat("#").concat("s").concat("^").concat("c").concat("_").concat("keyCodec").concat("&").concat("f").concat("+").concat("f").concat("(").concat("o").concat("#").concat("l").concat("*").concat("d"));
    BooleanSetting keepY = new BooleanSetting("K".concat("@").concat("e").concat("^").concat("e").concat("(").concat("p").concat("(").concat("Y"), false, "P".concat("#").concat("r").concat("_").concat("e").concat("#").concat("v").concat("&").concat("e").concat("_").concat("n").concat("$").concat("t").concat("(").concat("s").concat("&").concat(" ").concat("_").concat("p").concat("#").concat("l").concat("*").concat("keyCodec").concat("-").concat("c").concat("#").concat("i").concat("@").concat("n").concat("@").concat("g").concat("$").concat(" ").concat("(").concat("e").concat("-").concat("x").concat("&").concat("t").concat("!").concat("r").concat("+").concat("keyCodec").concat("(").concat(" ").concat("^").concat("elementCodec").concat("-").concat("l").concat("$").concat("o").concat("(").concat("c").concat("!").concat("k").concat("_").concat("s").concat("*").concat(" ").concat("^").concat("w").concat("*").concat("h").concat("&").concat("i").concat("!").concat("l").concat("_").concat("e").concat("(").concat(" ").concat("-").concat("j").concat("^").concat("u").concat("_").concat("m").concat("^").concat("p").concat("_").concat("i").concat("&").concat("n").concat("^").concat("g"));
    BooleanSetting tower = new BooleanSetting("T".concat("-").concat("o").concat("*").concat("w").concat("*").concat("e").concat("$").concat("r"), false, "T".concat(")").concat("o").concat("@").concat("w").concat("_").concat("e").concat("(").concat("r").concat("$").concat("s").concat("$").concat(" ").concat("&").concat("u").concat("$").concat("p").concat("_").concat(" ").concat("_").concat("f").concat("$").concat("keyCodec").concat("^").concat("s").concat("!").concat("t").concat("_").concat("e").concat("^").concat("r"));
    ModeSetting rotation = new ModeSetting("R".concat("-").concat("o").concat(")").concat("t").concat("*").concat("keyCodec").concat("@").concat("t").concat(")").concat("i").concat("+").concat("o").concat("$").concat("n"), "B".concat("+").concat("keyCodec").concat("&").concat("c").concat("#").concat("k").concat("_").concat("w").concat("-").concat("keyCodec").concat("&").concat("r").concat("-").concat("d").concat("+").concat("s"), "R".concat(")").concat("o").concat("+").concat("t").concat("$").concat("keyCodec").concat("*").concat("t").concat("+").concat("i").concat("^").concat("o").concat("!").concat("n").concat("*").concat(" ").concat("(").concat("f").concat("!").concat("o").concat("^").concat("r").concat("*").concat(" ").concat("+").concat("p").concat("_").concat("l").concat("(").concat("keyCodec").concat("$").concat("c").concat("@").concat("i").concat("-").concat("n").concat("*").concat("g").concat("+").concat(" ").concat("_").concat("elementCodec").concat("#").concat("l").concat("*").concat("o").concat("&").concat("c").concat("#").concat("k").concat("&").concat("s"), "T".concat("_").concat("e").concat("-").concat("l").concat("@").concat("l").concat(")").concat("y"), "B".concat("#").concat("keyCodec").concat("^").concat("c").concat("@").concat("k").concat("!").concat("w").concat("!").concat("keyCodec").concat("-").concat("r").concat("*").concat("d").concat("&").concat("s"), "T".concat("+").concat("e").concat("@").concat("l").concat(")").concat("l").concat("(").concat("y"));
    private float scaffoldY = 0.0f;

    public Scaffold() {
        super("S".concat("*").concat("c").concat("-").concat("keyCodec").concat("-").concat("f").concat("@").concat("f").concat("!").concat("o").concat("*").concat("l").concat("#").concat("d"), "P".concat("+").concat("l").concat("*").concat("keyCodec").concat("&").concat("c").concat("-").concat("e").concat("*").concat("s").concat("$").concat(" ").concat("(").concat("elementCodec").concat("*").concat("l").concat("(").concat("o").concat("+").concat("c").concat("-").concat("k").concat("#").concat("s").concat("!").concat(" ").concat("*").concat("u").concat("#").concat("n").concat("#").concat("d").concat("&").concat("e").concat("*").concat("r").concat("$").concat(" ").concat("^").concat("y").concat("@").concat("o").concat(")").concat("u"), Category.Movement);
        this.addSettings(this.rotation, this.cps, this.showBlockCount, this.spoofSlot, this.vulcanDisabler, this.keepY, this.tower);
    }

    @Override
    public void onEnable() {
        ClientMain.getRotationManager().resetRotation(true);
    }

    @Override
    public void onDisable() {
        ClientMain.getRotationManager().resetRotation(true);
    }

    @Override
    public void onTick() {
        super.onTick();
        if (Scaffold.mc.field_1724 != null) {
            int blockSlot;
            class_638 world = Scaffold.mc.field_1687;
            class_243 playerPos = Scaffold.mc.field_1724.method_19538();
            if (this.keepY.isEnabled()) {
                if (this.scaffoldY == 0.0f) {
                    this.scaffoldY = (float)Math.floor(playerPos.field_1351);
                }
            } else {
                this.scaffoldY = (float)Math.floor(playerPos.field_1351);
            }
            class_2338 blockPos = new class_2338((int)Math.floor(playerPos.field_1352), (int)this.scaffoldY - 1, (int)Math.floor(playerPos.field_1350));
            float[] rots = new float[]{Scaffold.mc.field_1724.method_36454() + 180.0f, 83.8f};
            Rotation rot = new Rotation(rots[0], rots[1]);
            ClientMain.getRotationManager().setRotation(rot, RotationManager.RotationPriority.HIGHEST);
            if (world.method_8320(blockPos).method_26215() && (blockSlot = this.getBestBlockSlot()) != -1) {
                int prevSlot = Scaffold.mc.field_1724.method_31548().field_7545;
                if (this.vulcanDisabler.isEnabled()) {
                    PacketUtils.sendPacketSilently((class_2596)new class_2848((class_1297)Scaffold.mc.field_1724, class_2848.class_2849.field_12985));
                }
                InventoryUtils.setInvSlot(blockSlot);
                this.place(blockPos);
                if (this.spoofSlot.isEnabled()) {
                    Scaffold.mc.field_1724.method_31548().field_7545 = prevSlot;
                }
            }
        }
    }

    private int getBestBlockSlot() {
        int blockSlot = -1;
        int highest = 0;
        for (int i = 0; i < 9; ++i) {
            class_1799 item = Scaffold.mc.field_1724.method_31548().method_5438(i);
            if (!(item.method_7909() instanceof class_1747) || item.method_7947() <= highest) continue;
            blockSlot = i;
            highest = item.method_7947();
        }
        return blockSlot;
    }

    @EventHandler
    public void onPacketSend(PacketEvent.Send event) {
        if (this.isNull() || !(Scaffold.mc.field_1724.method_31548().method_7391().method_7909() instanceof class_1747)) {
            return;
        }
        if (event.getPacket() instanceof class_2848 && ((class_2848)event.getPacket()).method_36173() == Scaffold.mc.field_1724.method_5628() && ((class_2848)event.getPacket()).method_12365() == class_2848.class_2849.field_12981) {
            event.cancel();
        }
    }

    @Override
    public void draw(class_4587 matrices) {
        if (this.showBlockCount.isEnabled() && Scaffold.mc.field_1724 != null) {
            for (int i = 0; i < 9; ++i) {
                class_1799 item = Scaffold.mc.field_1724.method_31548().method_5438(i);
                if (!(item.method_7909() instanceof class_1747)) continue;
                int totalCount = 0;
                for (int j = 0; j < 9; ++j) {
                    class_1799 totalItem = Scaffold.mc.field_1724.method_31548().method_5438(j);
                    if (!(totalItem.method_7909() instanceof class_1747)) continue;
                    totalCount += totalItem.method_7947();
                }
                String totalCountText = String.valueOf(totalCount);
                int width = (int)ClientMain.fontRenderer.getWidth(totalCountText);
                Render2DEngine.renderItem(matrices, item, (float)(mc.method_22683().method_4486() - width) / 2.0f - 20.0f, (float)mc.method_22683().method_4502() / 2.0f, 1.0f, false);
                ClientMain.fontRenderer.draw(matrices, totalCountText, (float)(mc.method_22683().method_4486() - width) / 2.0f, (float)mc.method_22683().method_4502() / 2.0f, 0xFFFFFF);
            }
        }
    }

    private boolean hasSupportingBlock(class_1937 world, class_2338 pos) {
        return !world.method_8320(pos.method_10074()).method_26215() || !world.method_8320(pos.method_10095()).method_26215() || !world.method_8320(pos.method_10072()).method_26215() || !world.method_8320(pos.method_10078()).method_26215() || !world.method_8320(pos.method_10067()).method_26215();
    }

    private boolean place(class_2338 bp) {
        FindItemResult itemResult = InventoryUtils.findItemSlot(itemStack -> itemStack.method_7909() instanceof class_1747);
        if (!itemResult.found() || !this.hasSupportingBlock((class_1937)Scaffold.mc.field_1687, bp)) {
            return false;
        }
        return BlockUtils.place(bp, itemResult, true, true);
    }
}
