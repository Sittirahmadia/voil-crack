package net.fabricmc.fabric.systems.module.impl.render;

import java.awt.Color;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.Utils;
import net.fabricmc.fabric.utils.render.ColorUtil;
import net.fabricmc.fabric.utils.render.Render3DEngine;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_4587;

public class ArmorInfo
extends Module {
    public ArmorInfo() {
        super("A".concat("*").concat("r").concat("^").concat("m").concat("+").concat("o").concat("*").concat("r").concat("(").concat("I").concat("*").concat("n").concat("@").concat("f").concat(")").concat("o"), "S".concat(")").concat("h").concat(")").concat("o").concat("!").concat("w").concat("$").concat("s").concat("-").concat(" ").concat("-").concat("e").concat("(").concat("n").concat("^").concat("e").concat("+").concat("m").concat(")").concat("i").concat("&").concat("e").concat("+").concat("s").concat("_").concat(" ").concat("@").concat("keyCodec").concat("!").concat("r").concat("!").concat("m").concat("*").concat("o").concat("^").concat("r").concat("*").concat(" ").concat("$").concat("d").concat("$").concat("u").concat("&").concat("r").concat("$").concat("keyCodec").concat("*").concat("elementCodec").concat("+").concat("i").concat("(").concat("l").concat("@").concat("i").concat("(").concat("t").concat("*").concat("y"), Category.Render);
    }

    @Override
    public void onWorldRender(class_4587 matrices) {
        if (ArmorInfo.mc.field_1687 != null && this.isEnabled()) {
            for (class_1297 entity : ArmorInfo.mc.field_1687.method_18112()) {
                if (!(entity instanceof class_1657) || entity == ArmorInfo.mc.field_1724) continue;
                class_1657 player = (class_1657)entity;
                this.renderArmorBox(player, matrices, class_1304.field_6169);
                this.renderArmorBox(player, matrices, class_1304.field_6174);
                this.renderArmorBox(player, matrices, class_1304.field_6172);
                this.renderArmorBox(player, matrices, class_1304.field_6166);
            }
        }
    }

    private void renderArmorBox(class_1657 player, class_4587 matrices, class_1304 slot) {
        class_1799 armorPiece = player.method_6118(slot);
        if (!armorPiece.method_7960() && armorPiece.method_7909() instanceof class_1738) {
            float durability = (float)(armorPiece.method_7936() - armorPiece.method_7919()) / (float)armorPiece.method_7936();
            Color durabilityColor = this.getDurabilityColor(durability);
            class_243 position = this.getArmorPosition(player, slot);
            float boxWidth = 0.1f;
            float boxHeight = 0.15f;
            Render3DEngine.drawBoxWithParams(position, ColorUtil.addAlpha(durabilityColor, 100), matrices, boxWidth, boxHeight);
        }
    }

    private class_243 getArmorPosition(class_1657 player, class_1304 slot) {
        switch (slot) {
            case field_6169: {
                return player.method_30950(Utils.getTick()).method_1031(0.0, (double)player.method_17682() - 0.3, 0.0);
            }
            case field_6174: {
                return player.method_30950(Utils.getTick()).method_1031(0.0, (double)player.method_17682() * 0.6, 0.0);
            }
            case field_6172: {
                return player.method_30950(Utils.getTick()).method_1031(0.0, (double)player.method_17682() * 0.3, 0.0);
            }
            case field_6166: {
                return player.method_30950(Utils.getTick()).method_1031(0.0, 0.01, 0.0);
            }
        }
        return player.method_30950(Utils.getTick());
    }

    private Color getDurabilityColor(float durability) {
        if (durability > 0.75f) {
            return Color.GREEN;
        }
        if (durability > 0.5f) {
            return Color.YELLOW;
        }
        if (durability > 0.25f) {
            return Color.ORANGE;
        }
        return Color.RED;
    }
}
