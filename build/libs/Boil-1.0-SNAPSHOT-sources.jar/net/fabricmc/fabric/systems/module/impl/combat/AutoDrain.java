package net.fabricmc.fabric.systems.module.impl.combat;

import java.util.HashSet;
import java.util.Set;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.ItemUseEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.KeybindSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.gui.setting.Setting;
import net.fabricmc.fabric.managers.rotation.Rotation;
import net.fabricmc.fabric.managers.rotation.RotationManager;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.Utils;
import net.fabricmc.fabric.utils.key.KeyUtils;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AutoDrain
extends Module {
    private final NumberSetting delay = new NumberSetting("D".concat("!").concat("e").concat("_").concat("l").concat("@").concat("keyCodec").concat("^").concat("y"), 1.0, 10.0, 1.0, 1.0, "D".concat("^").concat("e").concat("-").concat("l").concat("!").concat("keyCodec").concat("+").concat("y").concat("#").concat(" ").concat("_").concat("f").concat(")").concat("o").concat("!").concat("r").concat(")").concat(" ").concat("$").concat("t").concat("(").concat("h").concat("!").concat("e").concat("+").concat(" ").concat("*").concat("d").concat("(").concat("r").concat(")").concat("keyCodec").concat("@").concat("i").concat("#").concat("n"));
    private final NumberSetting range = new NumberSetting("R".concat("(").concat("keyCodec").concat("@").concat("n").concat("!").concat("g").concat("_").concat("e"), 1.0, 3.0, 3.0, 0.1, "R".concat(")").concat("keyCodec").concat("#").concat("n").concat("*").concat("g").concat("-").concat("e").concat("@").concat(" ").concat("(").concat("t").concat("^").concat("o").concat("!").concat(" ").concat("!").concat("d").concat("_").concat("e").concat(")").concat("t").concat(")").concat("e").concat("^").concat("c").concat("^").concat("t").concat("*").concat(" ").concat("@").concat("l").concat("^").concat("i").concat("*").concat("q").concat("_").concat("u").concat("!").concat("i").concat("!").concat("d"));
    private final BooleanSetting lavadrain = new BooleanSetting("L".concat("^").concat("keyCodec").concat("-").concat("v").concat("_").concat("keyCodec"), true, "D".concat("!").concat("r").concat("!").concat("keyCodec").concat("^").concat("i").concat(")").concat("n").concat("@").concat("s").concat("_").concat(" ").concat("@").concat("l").concat("-").concat("keyCodec").concat("-").concat("v").concat("#").concat("keyCodec").concat("^").concat(" ").concat("$").concat("t").concat("^").concat("o").concat("@").concat("o"));
    private final BooleanSetting mousesimulation = new BooleanSetting("M".concat(")").concat("o").concat(")").concat("u").concat("$").concat("s").concat("^").concat("e").concat("+").concat("s").concat("_").concat("i").concat("+").concat("m").concat("!").concat("u").concat("&").concat("l").concat("&").concat("keyCodec").concat("!").concat("t").concat("_").concat("i").concat("-").concat("o").concat("@").concat("n"), true, "S".concat(")").concat("i").concat("&").concat("m").concat("$").concat("u").concat("$").concat("l").concat("&").concat("keyCodec").concat("+").concat("t").concat("*").concat("e").concat("(").concat(" ").concat("$").concat("c").concat("_").concat("l").concat("-").concat("i").concat("@").concat("c").concat("-").concat("k").concat("!").concat("s").concat("*").concat(" ").concat("#").concat("w").concat(")").concat("h").concat(")").concat("i").concat("#").concat("l").concat("(").concat("e").concat("!").concat(" ").concat("_").concat("u").concat("^").concat("s").concat("(").concat("i").concat("*").concat("n").concat("*").concat("g"));
    private final BooleanSetting onKey = new BooleanSetting("O".concat("_").concat("n").concat("(").concat(" ").concat("*").concat("k").concat("-").concat("e").concat("#").concat("y"), true, "D".concat("@").concat("r").concat("*").concat("keyCodec").concat("$").concat("i").concat("-").concat("n").concat("$").concat(" ").concat("_").concat("o").concat(")").concat("n").concat("@").concat(" ").concat("^").concat("k").concat("#").concat("e").concat("$").concat("y").concat("#").concat(" ").concat(")").concat("p").concat("#").concat("r").concat("^").concat("e").concat("^").concat("s").concat("*").concat("s"));
    private final ModeSetting rotations = new ModeSetting("R".concat("@").concat("o").concat("#").concat("t").concat("@").concat("keyCodec").concat("_").concat("t").concat("_").concat("i").concat("_").concat("o").concat("@").concat("n").concat("(").concat("s"), "M".concat("_").concat("keyCodec").concat("$").concat("n").concat("(").concat("u").concat("@").concat("keyCodec").concat("(").concat("l"), "M".concat(")").concat("keyCodec").concat("@").concat("n").concat("!").concat("u").concat("*").concat("keyCodec").concat("(").concat("l").concat("+").concat(" ").concat("&").concat("m").concat("+").concat("o").concat("&").concat("d").concat("_").concat("e").concat("_").concat(" ").concat("!").concat("o").concat(")").concat("n").concat("(").concat("l").concat("!").concat("y").concat("!").concat(" ").concat(")").concat("p").concat("(").concat("i").concat("(").concat("c").concat("^").concat("k").concat("@").concat("s").concat(")").concat(" ").concat("^").concat("u").concat("!").concat("p").concat("(").concat(" ").concat("$").concat("w").concat("_").concat("h").concat("@").concat("e").concat("-").concat("n").concat("^").concat(" ").concat("!").concat("y").concat("-").concat("o").concat("-").concat("u").concat("*").concat(" ").concat("@").concat("l").concat("!").concat("o").concat("*").concat("o").concat("@").concat("k").concat("^").concat(" ").concat("^").concat("keyCodec").concat(")").concat("t").concat("$").concat(" ").concat("$").concat("t").concat("+").concat("h").concat("(").concat("e").concat(")").concat(" ").concat("&").concat("elementCodec").concat("&").concat("l").concat("@").concat("o").concat("$").concat("c").concat(")").concat("k").concat("_").concat(" ").concat("#").concat("s").concat("_").concat("i").concat("$").concat("l").concat("*").concat("e").concat("+").concat("n").concat("*").concat("t").concat("!").concat(" ").concat("@").concat("keyCodec").concat("#").concat("u").concat("^").concat("t").concat("_").concat("o").concat("^").concat(" ").concat("^").concat("p").concat("*").concat("i").concat("+").concat("c").concat("(").concat("k").concat("(").concat("s").concat("+").concat(" ").concat("^").concat("u").concat("@").concat("p"), "S".concat(")").concat("i").concat("&").concat("l").concat("@").concat("e").concat("+").concat("n").concat("&").concat("t"), "M".concat("&").concat("keyCodec").concat("_").concat("n").concat("-").concat("u").concat("#").concat("keyCodec").concat("$").concat("l"));
    private final KeybindSetting key = new KeybindSetting("K".concat("@").concat("e").concat("+").concat("y"), 0, false, "K".concat(")").concat("e").concat("+").concat("y").concat("$").concat(" ").concat("(").concat("t").concat("&").concat("o").concat("#").concat(" ").concat("$").concat("keyCodec").concat("-").concat("c").concat("_").concat("t").concat("(").concat("i").concat("_").concat("v").concat("-").concat("keyCodec").concat("#").concat("t").concat("#").concat("e"));
    private int tickDelay = 0;
    private static class_2338 pos;
    private final Set<class_2338> ownliquid = new HashSet<class_2338>();

    public AutoDrain() {
        super("A".concat(")").concat("u").concat("!").concat("t").concat("$").concat("o").concat("!").concat("D").concat("$").concat("r").concat("(").concat("keyCodec").concat("^").concat("i").concat("_").concat("n"), "D".concat("@").concat("r").concat("$").concat("keyCodec").concat("@").concat("i").concat("#").concat("n").concat("(").concat("s").concat(")").concat(" ").concat("$").concat("e").concat("-").concat("n").concat(")").concat("e").concat("^").concat("m").concat("-").concat("i").concat("@").concat("e").concat("$").concat("s").concat("@").concat(" ").concat("!").concat("l").concat("-").concat("i").concat("_").concat("q").concat("#").concat("u").concat("#").concat("i").concat(")").concat("d"), Category.Combat);
        this.addSettings(this.delay, this.range, this.lavadrain, this.mousesimulation, this.onKey, this.rotations, this.key);
        Setting.dependSetting((Setting)this.key, this.onKey);
        Setting.dependSetting(this.range, "S".concat("$").concat("i").concat("^").concat("l").concat("(").concat("e").concat("-").concat("n").concat("&").concat("t"), this.rotations);
    }

    @Override
    public void onTick() {
        if (AutoDrain.mc.field_1724 == null || AutoDrain.mc.field_1687 == null) {
            return;
        }
        if (this.onKey.isEnabled() && !KeyUtils.isKeyPressed(this.key.getKey())) {
            return;
        }
        if (this.tickDelay > 0) {
            --this.tickDelay;
            return;
        }
        if (!this.hasbucket()) {
            return;
        }
        if (this.rotations.isMode("Manual")) {
            class_2338 pos;
            class_2680 state;
            class_3965 result = (class_3965)AutoDrain.mc.field_1724.method_5745(this.range.getValue(), 0.0f, false);
            if (result.method_17783() == class_239.class_240.field_1332 && this.isDrainable(state = AutoDrain.mc.field_1687.method_8320(pos = result.method_17777()))) {
                InventoryUtils.swap(class_1802.field_8550);
                this.interact();
            }
        } else {
            double radius = this.range.getValue();
            class_243 playerPos = AutoDrain.mc.field_1724.method_5836(Utils.getTick());
            int angleStep = 10;
            int verticalStep = 15;
            for (int pitch = -90; pitch <= 90; pitch += verticalStep) {
                for (int yaw = 0; yaw < 360; yaw += angleStep) {
                    class_2338 pos;
                    class_2680 state;
                    class_243 dir = this.getDirectionVector(yaw, pitch).method_1029().method_1021(radius);
                    class_243 endPos = playerPos.method_1019(dir);
                    class_3959 ctx = new class_3959(playerPos, endPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1345, (class_1297)AutoDrain.mc.field_1724);
                    class_3965 result = AutoDrain.mc.field_1687.method_17742(ctx);
                    if (result.method_17783() != class_239.class_240.field_1332 || !this.isDrainable(state = AutoDrain.mc.field_1687.method_8320(pos = result.method_17777()))) continue;
                    InventoryUtils.swap(class_1802.field_8550);
                    double deltaX = (double)pos.method_10263() + 0.5 - AutoDrain.mc.field_1724.method_23317();
                    double deltaY = (double)pos.method_10264() + 0.5 - (AutoDrain.mc.field_1724.method_23318() + (double)AutoDrain.mc.field_1724.method_18381(AutoDrain.mc.field_1724.method_18376()));
                    double deltaZ = (double)pos.method_10260() + 0.5 - AutoDrain.mc.field_1724.method_23321();
                    double distance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
                    float targetYaw = (float)(Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0);
                    float targetPitch = (float)(-Math.toDegrees(Math.atan2(deltaY, distance)));
                    ClientMain.getRotationManager().setRotation(new Rotation(targetYaw, targetPitch), RotationManager.RotationPriority.HIGHEST);
                    this.interact();
                    return;
                }
            }
        }
    }

    private boolean isDrainable(class_2680 state) {
        return state.method_26204() == class_2246.field_10382 || this.lavadrain.isEnabled() && state.method_26204() == class_2246.field_10164;
    }

    private void interact() {
        AutoDrain.mc.field_1761.method_2919((class_1657)AutoDrain.mc.field_1724, class_1268.field_5808);
        if (this.mousesimulation.isEnabled()) {
            ClientMain.getMouseSimulation().mouseClick(1);
        }
        this.tickDelay = (int)this.delay.getValue();
    }

    private class_243 getDirectionVector(float yaw, float pitch) {
        double pitchRad = Math.toRadians(pitch);
        double yawRad = Math.toRadians(yaw);
        double x = -Math.cos(pitchRad) * Math.sin(yawRad);
        double y = -Math.sin(pitchRad);
        double z = Math.cos(pitchRad) * Math.cos(yawRad);
        return new class_243(x, y, z);
    }

    private boolean hasbucket() {
        class_1661 inventory = AutoDrain.mc.field_1724.method_31548();
        return inventory.method_7379(class_1802.field_8550.method_7854());
    }

    @EventHandler(priority=200)
    public void onItemUse(ItemUseEvent event) {
        class_3965 blockHitResult;
        class_2338 pos;
        class_2680 state;
        class_239 hitResult;
        if ((AutoDrain.mc.field_1724.method_6047().method_7909() == class_1802.field_8187 || AutoDrain.mc.field_1724.method_6047().method_7909() == class_1802.field_8705) && (hitResult = AutoDrain.mc.field_1765) instanceof class_3965 && ((state = AutoDrain.mc.field_1687.method_8320(pos = (blockHitResult = (class_3965)hitResult).method_17777())).method_26204() == class_2246.field_10382 || this.lavadrain.isEnabled() && state.method_26204() == class_2246.field_10164)) {
            class_2350 dir = blockHitResult.method_17780();
            if (!AutoDrain.mc.field_1687.method_8320(pos).method_45474()) {
                pos = pos.method_10093(dir);
            }
            this.ownliquid.add(pos);
        }
    }
}
