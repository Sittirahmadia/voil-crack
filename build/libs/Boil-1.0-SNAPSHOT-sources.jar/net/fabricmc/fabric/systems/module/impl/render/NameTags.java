package net.fabricmc.fabric.systems.module.impl.render;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.Utils;
import net.fabricmc.fabric.utils.render.Render2DEngine;
import net.fabricmc.fabric.utils.world.WorldUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_4587;
import org.jetbrains.annotations.NotNull;
import org.joml.Vector4d;

public class NameTags
extends Module {
    public static BooleanSetting RenderItems = new BooleanSetting("RenderItems", false, "Renders nametags with items");

    public NameTags() {
        super("N".concat("$").concat("keyCodec").concat("(").concat("m").concat("_").concat("e").concat("#").concat("T").concat("_").concat("keyCodec").concat("^").concat("g").concat("&").concat("s"), "R".concat("(").concat("e").concat("+").concat("n").concat("!").concat("d").concat("_").concat("e").concat("@").concat("r").concat("_").concat("s").concat("&").concat(" ").concat("_").concat("n").concat("&").concat("keyCodec").concat("!").concat("m").concat("+").concat("e").concat("+").concat("t").concat("_").concat("keyCodec").concat(")").concat("g").concat("$").concat("s"), Category.Render);
        this.addSettings(RenderItems);
    }

    @Override
    public void draw(class_4587 matrices) {
        if (NameTags.mc.field_1687 == null || NameTags.mc.field_1724 == null) {
            return;
        }
        for (class_1657 player : NameTags.mc.field_1687.method_18456()) {
            if (player == NameTags.mc.field_1724) continue;
            class_243[] vectors = NameTags.getVectors((class_1297)player);
            Vector4d position = null;
            for (class_243 vector : vectors) {
                class_243 screenPos = WorldUtils.worldToScreen(vector);
                if (!(screenPos.field_1350 > 0.0) || !(screenPos.field_1350 < 1.0)) continue;
                if (position == null) {
                    position = new Vector4d(screenPos.field_1352, screenPos.field_1351, screenPos.field_1352, screenPos.field_1351);
                    continue;
                }
                position.x = Math.min(screenPos.field_1352, position.x);
                position.y = Math.min(screenPos.field_1351, position.y);
                position.z = Math.max(screenPos.field_1352, position.z);
                position.w = Math.max(screenPos.field_1351, position.w);
            }
            if (position == null) continue;
            String name = player.method_5477().getString();
            double distance = NameTags.mc.field_1724.method_5858((class_1297)player);
            float actualDistance = (float)Math.sqrt(distance);
            String distanceText = String.format("%.1fm", Float.valueOf(actualDistance));
            float tagWidth = ClientMain.fontRenderer.getWidth(name) + 6.0f;
            float distanceWidth = ClientMain.fontRenderer.getWidth(distanceText) + 6.0f;
            float tagHeight = 14.0f;
            float textHeight = ClientMain.fontRenderer.getFont().getSize2D();
            float centerX = (float)((position.x + position.z) / 2.0);
            float x = centerX - (tagWidth + distanceWidth + 4.0f) / 2.0f;
            float y = (float)position.y - tagHeight - 2.0f;
            Render2DEngine.drawRoundedBlur(matrices, x, y, tagWidth, tagHeight, 6.0f, 6.0f, 0.0f, true);
            float distanceX = x + tagWidth + 4.0f;
            Render2DEngine.drawRoundedBlur(matrices, distanceX, y, distanceWidth, tagHeight, 6.0f, 6.0f, 0.0f, true);
            float textY = y + (tagHeight - textHeight) / 2.0f;
            ClientMain.fontRenderer.draw(matrices, name, x + 3.0f, textY - 2.0f, -1);
            ClientMain.fontRenderer.draw(matrices, distanceText, distanceX + 3.0f, textY - 2.0f, -5592406);
            if (!RenderItems.isEnabled()) continue;
            float itemScale = 0.75f;
            float itemX = centerX - 22.5f;
            float itemY = y - 16.0f;
            Render2DEngine.renderItem(matrices, player.method_6047(), itemX, itemY, itemScale, true);
            Render2DEngine.renderItem(matrices, player.method_6079(), itemX += 18.0f, itemY, itemScale, true);
            itemX += 18.0f;
            for (int i = 3; i >= 0; --i) {
                class_1799 armorPiece = (class_1799)player.method_31548().field_7548.get(i);
                if (armorPiece.method_7960()) continue;
                Render2DEngine.renderItem(matrices, armorPiece, itemX, itemY, itemScale, true);
                itemX += 18.0f;
            }
        }
    }

    @NotNull
    private static class_243[] getVectors(@NotNull class_1297 ent) {
        double x = ent.field_6014 + (ent.method_23317() - ent.field_6014) * (double)Utils.getTick();
        double y = ent.field_6036 + (ent.method_23318() - ent.field_6036) * (double)Utils.getTick();
        double z = ent.field_5969 + (ent.method_23321() - ent.field_5969) * (double)Utils.getTick();
        class_238 box = ent.method_5829().method_989(-ent.method_23317(), -ent.method_23318(), -ent.method_23321()).method_989(x, y, z);
        return new class_243[]{new class_243(box.field_1323, box.field_1322, box.field_1321), new class_243(box.field_1323, box.field_1325, box.field_1321), new class_243(box.field_1320, box.field_1322, box.field_1321), new class_243(box.field_1320, box.field_1325, box.field_1321), new class_243(box.field_1323, box.field_1322, box.field_1324), new class_243(box.field_1323, box.field_1325, box.field_1324), new class_243(box.field_1320, box.field_1322, box.field_1324), new class_243(box.field_1320, box.field_1325, box.field_1324)};
    }
}
