package net.fabricmc.fabric.systems.module.impl.misc;

import java.util.regex.Pattern;
import net.fabricmc.fabric.managers.SocialManager;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3489;
import net.minecraft.class_9282;

public class Teams
extends Module {
    private static final Pattern COLOR_PATTERN = Pattern.compile("\u00a7[0-9A-Fk-o]", 2);

    public Teams() {
        super("T".concat("^").concat("e").concat("(").concat("keyCodec").concat(")").concat("m").concat("@").concat("s"), "M".concat("@").concat("keyCodec").concat("!").concat("k").concat("!").concat("e").concat("+").concat("s").concat("+").concat(" ").concat("^").concat("y").concat("_").concat("o").concat("_").concat("u").concat(")").concat(" ").concat("_").concat("n").concat("!").concat("o").concat("&").concat("t").concat("(").concat(" ").concat(")").concat("keyCodec").concat("_").concat("t").concat("+").concat("t").concat("^").concat("keyCodec").concat(")").concat("c").concat("+").concat("k").concat("@").concat(" ").concat("#").concat("y").concat("(").concat("o").concat("+").concat("u").concat(")").concat("r").concat("*").concat(" ").concat("#").concat("t").concat("(").concat("e").concat("_").concat("keyCodec").concat("-").concat("m").concat("#").concat("m").concat("#").concat("keyCodec").concat("-").concat("t").concat("$").concat("e").concat("&").concat("s"), Category.Miscellaneous);
    }

    @Override
    public void onEnable() {
        SocialManager.clearTeammates();
    }

    @Override
    public void onDisable() {
        SocialManager.clearTeammates();
    }

    @Override
    public void onTick() {
        if (Teams.mc.field_1687 == null || Teams.mc.field_1724 == null) {
            return;
        }
        Teams.mc.field_1687.method_18456().stream().filter(this::isSameTeam).forEach(player -> SocialManager.addTeammate(player.method_5667()));
    }

    public boolean isSameTeam(class_1309 entity) {
        if (Teams.mc.field_1724.method_5722((class_1297)entity)) {
            return true;
        }
        class_2561 clientDisplayName = Teams.mc.field_1724.method_5476();
        class_2561 targetDisplayName = entity.method_5476();
        if (clientDisplayName == null || targetDisplayName == null) {
            return false;
        }
        return this.checkName(clientDisplayName, targetDisplayName) || this.checkPrefix(targetDisplayName, clientDisplayName) || entity instanceof class_1657 && this.checkArmor((class_1657)entity);
    }

    private boolean checkName(class_2561 clientDisplayName, class_2561 targetDisplayName) {
        class_2583 targetStyle = targetDisplayName.method_10866();
        class_2583 clientStyle = clientDisplayName.method_10866();
        return targetStyle.method_10973() != null && clientStyle.method_10973() != null && targetStyle.method_10973().equals((Object)clientStyle.method_10973());
    }

    private boolean checkPrefix(class_2561 targetDisplayName, class_2561 clientDisplayName) {
        String targetName = Teams.stripMinecraftColorCodes(targetDisplayName.getString());
        String clientName = Teams.stripMinecraftColorCodes(clientDisplayName.getString());
        String[] targetSplit = targetName.split(" ");
        String[] clientSplit = clientName.split(" ");
        return targetSplit.length > 1 && clientSplit.length > 1 && targetSplit[0].equals(clientSplit[0]);
    }

    private boolean checkArmor(class_1657 player) {
        return this.matchesArmorColor(player, 3) || this.matchesArmorColor(player, 2);
    }

    private boolean matchesArmorColor(class_1657 player, int armorSlot) {
        class_1799 ownStack = Teams.mc.field_1724.method_31548().method_7372(armorSlot);
        class_1799 otherStack = player.method_31548().method_7372(armorSlot);
        Integer ownColor = this.getArmorColor(ownStack);
        Integer otherColor = this.getArmorColor(otherStack);
        return ownColor != null && ownColor.equals(otherColor);
    }

    private Integer getArmorColor(class_1799 stack) {
        if (stack != null && stack.method_31573(class_3489.field_48803)) {
            return class_9282.method_57470((class_1799)stack, (int)-6265536);
        }
        return null;
    }

    public static String stripMinecraftColorCodes(String input) {
        return COLOR_PATTERN.matcher(input).replaceAll("");
    }
}
