package net.fabricmc.fabric.systems.module.impl.Cpvp;

import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.fabricmc.fabric.utils.player.RaycastUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2663;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AutoDoubleHand
extends Module {
    private final NumberSetting health = new NumberSetting("H".concat("^").concat("e").concat("(").concat("keyCodec").concat("*").concat("l").concat("+").concat("t").concat(")").concat("h"), 1.0, 20.0, 10.0, 1.0, "M".concat("^").concat("i").concat(")").concat("n").concat(")").concat("i").concat("+").concat("m").concat("+").concat("u").concat("$").concat("m").concat("&").concat(" ").concat("^").concat("h").concat("*").concat("e").concat("_").concat("keyCodec").concat("+").concat("l").concat("*").concat("t").concat("#").concat("h").concat("!").concat(" ").concat("_").concat("t").concat(")").concat("o").concat(")").concat(" ").concat("#").concat("s").concat("-").concat("w").concat("+").concat("keyCodec").concat("!").concat("p").concat("-").concat(" ").concat("#").concat("t").concat("&").concat("o").concat("!").concat(" ").concat("^").concat("t").concat("*").concat("o").concat("^").concat("t").concat("@").concat("e").concat("#").concat("m"));
    private final BooleanSetting dhandAir = new BooleanSetting("D".concat("@").concat("o").concat("@").concat("u").concat("^").concat("elementCodec").concat("(").concat("l").concat("*").concat("e").concat("!").concat(" ").concat("*").concat("h").concat("!").concat("keyCodec").concat("#").concat("n").concat("@").concat("d").concat(")").concat(" ").concat("-").concat("o").concat(")").concat("n").concat("!").concat(" ").concat("-").concat("keyCodec").concat("#").concat("i").concat("*").concat("r"), true, "D".concat("+").concat("o").concat("(").concat("u").concat("!").concat("elementCodec").concat("&").concat("l").concat("-").concat("e").concat("$").concat(" ").concat("(").concat("h").concat("_").concat("keyCodec").concat("-").concat("n").concat("+").concat("d").concat("#").concat(" ").concat("#").concat("o").concat("^").concat("n").concat("^").concat(" ").concat(")").concat("keyCodec").concat("!").concat("i").concat("*").concat("r"));
    private final BooleanSetting dhandAfterPop = new BooleanSetting("D".concat(")").concat("h").concat("!").concat("keyCodec").concat(")").concat("n").concat("+").concat("d").concat("&").concat(" ").concat("-").concat("keyCodec").concat("(").concat("f").concat("(").concat("t").concat("+").concat("e").concat("&").concat("r").concat("-").concat(" ").concat("*").concat("p").concat("$").concat("o").concat("&").concat("p"), true, "D".concat("#").concat("o").concat("&").concat("u").concat(")").concat("elementCodec").concat("-").concat("l").concat("$").concat("e").concat("*").concat(" ").concat("+").concat("h").concat("!").concat("keyCodec").concat("&").concat("n").concat("@").concat("d").concat("&").concat(" ").concat("@").concat("keyCodec").concat(")").concat("f").concat(")").concat("t").concat("@").concat("e").concat("!").concat("r").concat("_").concat(" ").concat("_").concat("p").concat("@").concat("o").concat("@").concat("p").concat("+").concat("p").concat("_").concat("i").concat("*").concat("n").concat("@").concat("g").concat("&").concat(" ").concat(")").concat("keyCodec").concat("&").concat(" ").concat("#").concat("t").concat("$").concat("o").concat("$").concat("t").concat("#").concat("e").concat("*").concat("m"));
    private final BooleanSetting predictCrystal = new BooleanSetting("C".concat("_").concat("h").concat("$").concat("e").concat("&").concat("c").concat("(").concat("k").concat("@").concat(" ").concat("$").concat("P").concat(")").concat("l").concat("#").concat("keyCodec").concat("-").concat("y").concat("*").concat("e").concat("_").concat("r").concat("_").concat("s").concat("@").concat(" ").concat("-").concat("L").concat("$").concat("o").concat("#").concat("o").concat("^").concat("k"), true, "D".concat("@").concat("o").concat("_").concat("u").concat("@").concat("elementCodec").concat("#").concat("l").concat("+").concat("e").concat("(").concat(" ").concat("^").concat("h").concat("@").concat("keyCodec").concat("#").concat("n").concat("@").concat("d").concat("-").concat(" ").concat("_").concat("i").concat(")").concat("f").concat("(").concat(" ").concat(")").concat("p").concat("&").concat("l").concat("$").concat("keyCodec").concat("$").concat("y").concat("^").concat("e").concat(")").concat("r").concat("#").concat(" ").concat("^").concat("i").concat("^").concat("s").concat("#").concat(" ").concat("-").concat("l").concat("@").concat("o").concat("#").concat("o").concat("_").concat("k").concat("^").concat("i").concat("(").concat("n").concat("$").concat("g").concat("*").concat(" ").concat("$").concat("keyCodec").concat("!").concat("t").concat("*").concat(" ").concat("@").concat("m").concat("#").concat("e"));
    private final BooleanSetting predictSword = new BooleanSetting("P".concat("@").concat("r").concat("#").concat("e").concat("!").concat("d").concat("$").concat("i").concat("+").concat("c").concat("-").concat("t").concat("+").concat(" ").concat("-").concat("S").concat("-").concat("w").concat("#").concat("o").concat("!").concat("r").concat("#").concat("d"), true, "D".concat("-").concat("o").concat("_").concat("u").concat("^").concat("elementCodec").concat(")").concat("l").concat("@").concat("e").concat(")").concat(" ").concat("$").concat("h").concat("-").concat("keyCodec").concat("(").concat("n").concat("+").concat("d").concat("(").concat(" ").concat("-").concat("i").concat("!").concat("f").concat("(").concat(" ").concat("-").concat("p").concat("(").concat("l").concat("-").concat("keyCodec").concat("_").concat("y").concat("^").concat("e").concat("$").concat("r").concat("*").concat(" ").concat("+").concat("i").concat("$").concat("s").concat("^").concat(" ").concat("!").concat("keyCodec").concat("(").concat("i").concat("-").concat("m").concat("&").concat("i").concat("#").concat("n").concat("#").concat("g").concat("_").concat(" ").concat("*").concat("keyCodec").concat("(").concat("t").concat("_").concat(" ").concat("_").concat("m").concat("-").concat("e").concat("(").concat(" ").concat("+").concat("w").concat("*").concat("i").concat("*").concat("t").concat("&").concat("h").concat("(").concat(" ").concat("$").concat("keyCodec").concat("#").concat(" ").concat("-").concat("s").concat("#").concat("w").concat(")").concat("o").concat("@").concat("r").concat("*").concat("d"));
    private final BooleanSetting predictObsidian = new BooleanSetting("P".concat("#").concat("r").concat("^").concat("e").concat("_").concat("d").concat("_").concat("i").concat("#").concat("c").concat("^").concat("t").concat("#").concat(" ").concat("#").concat("O").concat("+").concat("elementCodec").concat("*").concat("s").concat("&").concat("i").concat("&").concat("d").concat("@").concat("i").concat("+").concat("keyCodec").concat("_").concat("n"), true, "D".concat("^").concat("o").concat("@").concat("u").concat("^").concat("elementCodec").concat("#").concat("l").concat("-").concat("e").concat(")").concat(" ").concat("-").concat("h").concat("_").concat("keyCodec").concat("_").concat("n").concat("*").concat("d").concat(")").concat(" ").concat("-").concat("i").concat("#").concat("f").concat("-").concat(" ").concat("*").concat("o").concat("#").concat("elementCodec").concat("+").concat("s").concat(")").concat("i").concat("&").concat("d").concat("$").concat("i").concat("@").concat("keyCodec").concat("-").concat("n").concat("^").concat(" ").concat("&").concat("n").concat(")").concat("e").concat("$").concat("keyCodec").concat("$").concat("r").concat("#").concat("elementCodec").concat("*").concat("y"));
    private final BooleanSetting dontstick = new BooleanSetting("D".concat("&").concat("o").concat("!").concat("n").concat("&").concat("t").concat("!").concat(" ").concat("$").concat("s").concat("(").concat("t").concat("$").concat("i").concat("@").concat("c").concat("-").concat("k"), false, "O".concat("$").concat("n").concat("*").concat("l").concat("!").concat("y").concat("*").concat(" ").concat("_").concat("s").concat("+").concat("w").concat("+").concat("i").concat("#").concat("t").concat(")").concat("c").concat(")").concat("h").concat("$").concat("e").concat("!").concat("s").concat("@").concat(" ").concat("#").concat("t").concat("(").concat("o").concat("@").concat(" ").concat("!").concat("t").concat(")").concat("o").concat(")").concat("t").concat("+").concat("e").concat("#").concat("m").concat("-").concat(" ").concat("*").concat("o").concat("#").concat("n").concat("&").concat("c").concat("$").concat("e"));
    boolean switched = false;

    public AutoDoubleHand() {
        super("A".concat("&").concat("u").concat("-").concat("t").concat("*").concat("o").concat("*").concat("D").concat("(").concat("o").concat("_").concat("u").concat("@").concat("elementCodec").concat("*").concat("l").concat("&").concat("e").concat("!").concat("H").concat("&").concat("keyCodec").concat(")").concat("n").concat("*").concat("d"), "A".concat("$").concat("u").concat(")").concat("t").concat("_").concat("o").concat(")").concat("m").concat("$").concat("keyCodec").concat("^").concat("t").concat("@").concat("i").concat("_").concat("c").concat("&").concat("keyCodec").concat("!").concat("l").concat("&").concat("l").concat("$").concat("y").concat("@").concat(" ").concat("#").concat("s").concat("*").concat("w").concat("*").concat("keyCodec").concat("-").concat("p").concat("#").concat("s").concat("!").concat(" ").concat("^").concat("t").concat("&").concat("o").concat("^").concat("t").concat("@").concat("e").concat("!").concat("m").concat("*").concat(" ").concat("*").concat("o").concat("(").concat("n").concat("#").concat(" ").concat("+").concat("c").concat("#").concat("e").concat("(").concat("r").concat(")").concat("t").concat("@").concat("keyCodec").concat("#").concat("i").concat("_").concat("n").concat("_").concat(" ").concat("_").concat("c").concat("^").concat("o").concat("^").concat("n").concat(")").concat("d").concat("-").concat("i").concat("!").concat("t").concat("#").concat("i").concat(")").concat("o").concat("!").concat("n").concat("#").concat("s"), Category.CrystalPvP);
        this.addSettings(this.health, this.dhandAir, this.dhandAfterPop, this.predictCrystal, this.predictSword, this.dontstick);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.switched = false;
    }

    @Override
    public void onTick() {
        if (!this.isEnabled() || AutoDoubleHand.mc.field_1724 == null) {
            return;
        }
        if (this.shouldSwapToTotem()) {
            this.swapToTotem();
        }
    }

    private boolean shouldSwapToTotem() {
        double currentHealth = AutoDoubleHand.mc.field_1724.method_6032() + AutoDoubleHand.mc.field_1724.method_6067();
        if (currentHealth <= (double)this.health.getFloatValue()) {
            return true;
        }
        if (this.dhandAir.isEnabled() && AutoDoubleHand.mc.field_1724.field_6017 > 0.0f) {
            return true;
        }
        if (this.predictSword.isEnabled() && this.isPlayerAimingAtMe()) {
            return true;
        }
        if (this.dhandAfterPop.isEnabled()) {
            return true;
        }
        if (this.predictObsidian.isEnabled() && this.arePlayersAimingAtBlock()) {
            return true;
        }
        if (this.predictCrystal.isEnabled()) {
            return AutoDoubleHand.mc.field_1687.method_8390(class_1511.class, AutoDoubleHand.mc.field_1724.method_5829().method_1014(10.0), endCrystal -> true).stream().anyMatch(this::arePlayersAimingAtCrystal);
        }
        return false;
    }

    private void swapToTotem() {
        if (AutoDoubleHand.mc.field_1724.method_6079().method_7909() != class_1802.field_8288) {
            if (this.dontstick.isEnabled() && this.switched) {
                return;
            }
            InventoryUtils.swap(class_1802.field_8288);
            this.switched = true;
            if (!this.dontstick.isEnabled()) {
                this.switched = false;
            }
        }
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive event) {
        class_2663 packet;
        if (event.getPacket() instanceof class_2663 && (packet = (class_2663)event.getPacket()).method_11470() == 35 && packet.method_11469((class_1937)AutoDoubleHand.mc.field_1687) == AutoDoubleHand.mc.field_1724) {
            this.switched = false;
        }
    }

    private boolean isPlayerAimingAtMe() {
        class_238 clientPlayerBox = AutoDoubleHand.mc.field_1724.method_5829().method_1014(0.5);
        for (class_1657 otherPlayer : AutoDoubleHand.mc.field_1687.method_18456()) {
            if (otherPlayer.equals((Object)AutoDoubleHand.mc.field_1724)) continue;
            class_243 otherPlayerEyePos = otherPlayer.method_33571();
            class_243 lookDirection = otherPlayer.method_5828(1.0f);
            class_243 endPos = otherPlayerEyePos.method_1019(lookDirection.method_1021(50.0));
            class_3959 context = new class_3959(otherPlayerEyePos, endPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)otherPlayer);
            class_3965 hitResult = AutoDoubleHand.mc.field_1687.method_17742(context);
            if (!clientPlayerBox.method_993(otherPlayerEyePos, endPos) && (hitResult.method_17783() == class_239.class_240.field_1333 || !clientPlayerBox.method_1006(hitResult.method_17784()))) continue;
            return true;
        }
        return false;
    }

    private boolean arePlayersAimingAtBlock() {
        for (class_1657 player : AutoDoubleHand.mc.field_1687.method_18456()) {
            class_2248 hitBlock;
            class_243 lookDirection;
            class_243 endVec;
            class_243 playerEyePosition;
            class_3959 raycastContext;
            class_3965 hitResult;
            if (player.equals((Object)AutoDoubleHand.mc.field_1724) || (hitResult = AutoDoubleHand.mc.field_1687.method_17742(raycastContext = new class_3959(playerEyePosition = player.method_33571(), endVec = playerEyePosition.method_1019((lookDirection = player.method_5828(1.0f)).method_1021(100.0)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)player))).method_17783() != class_239.class_240.field_1332 || hitResult.method_17777() == null || (hitBlock = AutoDoubleHand.mc.field_1687.method_8320(hitResult.method_17777()).method_26204()) != class_2246.field_10540 && hitBlock != class_2246.field_9987 && hitBlock != class_2246.field_23152) continue;
            return true;
        }
        return false;
    }

    private boolean arePlayersAimingAtCrystal(class_1511 crystal) {
        for (class_1657 player : AutoDoubleHand.mc.field_1687.method_18456()) {
            class_243 lookVec;
            class_243 end;
            if (player.equals((Object)AutoDoubleHand.mc.field_1724)) continue;
            class_243 start = player.method_33571();
            class_238 visionBox = new class_238(start, end = start.method_1019(lookVec = RaycastUtils.getPlayerLookVec(player)));
            return AutoDoubleHand.mc.field_1687.method_8390(class_1511.class, visionBox, endCrystal -> endCrystal.equals((Object)crystal)).size() > 0;
        }
        return false;
    }
}
