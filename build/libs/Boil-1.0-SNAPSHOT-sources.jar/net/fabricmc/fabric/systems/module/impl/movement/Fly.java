package net.fabricmc.fabric.systems.module.impl.movement;

import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.EventUpdate;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_1690;
import net.minecraft.class_243;

public class Fly
extends Module {
    private final NumberSetting speed = new NumberSetting("S".concat("!").concat("p").concat("$").concat("e").concat("$").concat("e").concat("-").concat("d"), 0.01, 50.0, 5.0, 1.0, "M".concat("_").concat("o").concat("&").concat("v").concat("$").concat("e").concat("$").concat("m").concat("+").concat("e").concat("#").concat("n").concat("_").concat("t").concat("_").concat(" ").concat("(").concat("s").concat("&").concat("p").concat("@").concat("e").concat("-").concat("e").concat("&").concat("d").concat("#").concat(" ").concat("!").concat("o").concat("&").concat("f").concat("*").concat(" ").concat("*").concat("t").concat("^").concat("h").concat("+").concat("e").concat("+").concat(" ").concat("$").concat("elementCodec").concat("#").concat("o").concat("#").concat("keyCodec").concat("!").concat("t"));
    private final NumberSetting verticalSpeed = new NumberSetting("V".concat(")").concat("e").concat("*").concat("r").concat("*").concat("t").concat("$").concat("i").concat("*").concat("c").concat("^").concat("keyCodec").concat("*").concat("l").concat("-").concat("S").concat("#").concat("p").concat("&").concat("e").concat("(").concat("e").concat("+").concat("d"), 0.01, 5.0, 0.2, 0.01, "V".concat("^").concat("e").concat("-").concat("r").concat("#").concat("t").concat("-").concat("i").concat("_").concat("c").concat("+").concat("keyCodec").concat(")").concat("l").concat("^").concat(" ").concat("^").concat("s").concat("$").concat("p").concat("#").concat("e").concat("+").concat("e").concat(")").concat("d").concat("_").concat(" ").concat("!").concat("w").concat("(").concat("h").concat("*").concat("i").concat("_").concat("l").concat("$").concat("e").concat("(").concat(" ").concat("^").concat("f").concat("*").concat("l").concat("(").concat("y").concat("!").concat("i").concat("(").concat("n").concat("+").concat("g"));
    private final NumberSetting glideFactor = new NumberSetting("G".concat(")").concat("l").concat(")").concat("i").concat(")").concat("d").concat("$").concat("e").concat("+").concat("F").concat("(").concat("keyCodec").concat("$").concat("c").concat("-").concat("t").concat("^").concat("o").concat(")").concat("r"), 0.0, 1.0, 0.95, 0.01, "G".concat("#").concat("l").concat("$").concat("i").concat(")").concat("d").concat("-").concat("e").concat("*").concat(" ").concat(")").concat("f").concat("^").concat("keyCodec").concat(")").concat("c").concat("-").concat("t").concat("_").concat("o").concat("@").concat("r").concat("-").concat(" ").concat("(").concat("f").concat("^").concat("o").concat("$").concat("r").concat("!").concat(" ").concat(")").concat("s").concat("!").concat("m").concat("@").concat("o").concat(")").concat("o").concat("#").concat("t").concat("^").concat("h").concat("*").concat("e").concat("@").concat("r").concat("*").concat(" ").concat(")").concat("m").concat("-").concat("o").concat("-").concat("v").concat("*").concat("e").concat(")").concat("m").concat("^").concat("e").concat("+").concat("n").concat("@").concat("t"));
    private double fixedY;

    public Fly() {
        super("F".concat("!").concat("l").concat("+").concat("y"), "A".concat("_").concat("l").concat("!").concat("l").concat("*").concat("o").concat("_").concat("w").concat("+").concat("s").concat("*").concat(" ").concat("!").concat("y").concat("#").concat("o").concat("$").concat("u").concat("-").concat(" ").concat(")").concat("t").concat("#").concat("o").concat("_").concat(" ").concat("*").concat("f").concat("+").concat("l").concat("_").concat("y").concat("*").concat(" ").concat("(").concat("w").concat("&").concat("i").concat(")").concat("t").concat("+").concat("h").concat("@").concat(" ").concat("_").concat("y").concat("^").concat("o").concat("&").concat("u").concat("#").concat("r").concat("!").concat(" ").concat("+").concat("elementCodec").concat("+").concat("o").concat("!").concat("keyCodec").concat("-").concat("t"), Category.Movement);
        this.addSettings(this.speed, this.verticalSpeed, this.glideFactor);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (Fly.mc.field_1724 == null || !(Fly.mc.field_1724.method_5854() instanceof class_1690)) {
            this.toggle();
            return;
        }
        this.fixedY = Fly.mc.field_1724.method_23318();
    }

    @Override
    public void onDisable() {
        super.onDisable();
        if (Fly.mc.field_1724 != null && Fly.mc.field_1724.method_5854() instanceof class_1690) {
            class_1690 boat = (class_1690)Fly.mc.field_1724.method_5854();
            boat.method_18799(class_243.field_1353);
        }
    }

    @EventHandler
    public void onUpdate(EventUpdate e) {
        if (Fly.mc.field_1724 == null || !(Fly.mc.field_1724.method_5854() instanceof class_1690)) {
            return;
        }
        this.handleBoatFly();
    }

    private void handleBoatFly() {
        class_1690 boat = (class_1690)Fly.mc.field_1724.method_5854();
        if (boat == null) {
            return;
        }
        double speedValue = this.speed.getFloatValue();
        double verticalSpeedValue = this.verticalSpeed.getFloatValue();
        double glideFactorValue = this.glideFactor.getFloatValue();
        class_243 velocity = boat.method_18798();
        boolean forward = Fly.mc.field_1690.field_1894.method_1434();
        boolean backward = Fly.mc.field_1690.field_1881.method_1434();
        boolean left = Fly.mc.field_1690.field_1913.method_1434();
        boolean right = Fly.mc.field_1690.field_1849.method_1434();
        boolean up = Fly.mc.field_1690.field_1903.method_1434();
        boolean down = Fly.mc.field_1690.field_1832.method_1434();
        class_243 inputVelocity = class_243.field_1353;
        if (forward) {
            inputVelocity = inputVelocity.method_1019(boat.method_5720().method_1021(speedValue));
        }
        if (backward) {
            inputVelocity = inputVelocity.method_1020(boat.method_5720().method_1021(speedValue));
        }
        if (left) {
            inputVelocity = inputVelocity.method_1019(boat.method_5720().method_1024((float)Math.toRadians(90.0)).method_1021(speedValue));
        }
        if (right) {
            inputVelocity = inputVelocity.method_1019(boat.method_5720().method_1024((float)Math.toRadians(-90.0)).method_1021(speedValue));
        }
        if (up) {
            inputVelocity = inputVelocity.method_1031(0.0, verticalSpeedValue, 0.0);
        }
        if (down) {
            inputVelocity = inputVelocity.method_1023(0.0, verticalSpeedValue, 0.0);
        }
        class_243 newVelocity = velocity.method_1021(glideFactorValue).method_1019(inputVelocity.method_1021(1.0 - glideFactorValue));
        boat.method_18799(newVelocity);
    }
}
