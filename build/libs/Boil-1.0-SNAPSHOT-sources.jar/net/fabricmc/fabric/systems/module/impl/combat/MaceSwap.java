package net.fabricmc.fabric.systems.module.impl.combat;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.managers.SocialManager;
import net.fabricmc.fabric.managers.rotation.Rotation;
import net.fabricmc.fabric.managers.rotation.RotationManager;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.math.TimerUtils;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.fabricmc.fabric.utils.player.PlayerUtils;
import net.fabricmc.fabric.utils.world.WorldUtils;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;

public class MaceSwap
extends Module {
    BooleanSetting switchBack = new BooleanSetting("S".concat("(").concat("w").concat("+").concat("i").concat("*").concat("t").concat("#").concat("c").concat("&").concat("h").concat("@").concat(" ").concat("$").concat("B").concat("#").concat("keyCodec").concat("&").concat("c").concat("@").concat("k").concat("*").concat(" ").concat("!").concat("t").concat("-").concat("o").concat("(").concat(" ").concat("(").concat("P").concat("_").concat("r").concat("$").concat("e").concat("-").concat("v").concat("$").concat("i").concat("!").concat("o").concat("&").concat("u").concat("$").concat("s").concat("!").concat(" ").concat("_").concat("S").concat("*").concat("l").concat("!").concat("o").concat("-").concat("t"), true, "S".concat("_").concat("w").concat("$").concat("i").concat("@").concat("t").concat("^").concat("c").concat("!").concat("h").concat("!").concat("e").concat("#").concat("s").concat("+").concat(" ").concat("!").concat("elementCodec").concat("-").concat("keyCodec").concat("(").concat("c").concat("-").concat("k").concat("^").concat(" ").concat("@").concat("t").concat("*").concat("o").concat("*").concat(" ").concat("&").concat("o").concat("^").concat("l").concat("+").concat("d").concat("^").concat(" ").concat(")").concat("s").concat("(").concat("l").concat("+").concat("o").concat("(").concat("t").concat("^").concat(" ").concat("+").concat("keyCodec").concat("_").concat("f").concat("&").concat("t").concat(")").concat("e").concat("@").concat("r").concat("*").concat(" ").concat("+").concat("u").concat("$").concat("s").concat("-").concat("i").concat("(").concat("n").concat("+").concat("g").concat("^").concat(" ").concat("$").concat("m").concat("!").concat("keyCodec").concat("+").concat("c").concat("&").concat("e"));
    BooleanSetting stun = new BooleanSetting("S".concat("@").concat("t").concat(")").concat("u").concat("!").concat("n"), true, "S".concat("&").concat("t").concat("!").concat("u").concat("$").concat("n").concat("$").concat("s").concat("!").concat(" ").concat("_").concat("e").concat("(").concat("n").concat("-").concat("e").concat("*").concat("m").concat(")").concat("i").concat("_").concat("e").concat("&").concat("s").concat("_").concat(" ").concat("@").concat("s").concat("^").concat("h").concat("&").concat("i").concat("@").concat("e").concat("(").concat("l").concat("*").concat("d").concat("*").concat(" ").concat("&").concat("t").concat("#").concat("h").concat(")").concat("e").concat("$").concat("n").concat("(").concat(" ").concat("_").concat("m").concat("!").concat("keyCodec").concat("#").concat("c").concat("#").concat("e"));
    BooleanSetting ignoreifweb = new BooleanSetting("I".concat("*").concat("g").concat("&").concat("n").concat("&").concat("o").concat("(").concat("r").concat("!").concat("e").concat("$").concat(" ").concat("#").concat("w").concat("(").concat("e").concat("@").concat("elementCodec"), false, "I".concat("_").concat("g").concat(")").concat("n").concat("$").concat("o").concat("$").concat("r").concat("*").concat("e").concat("*").concat("s").concat("&").concat(" ").concat("*").concat("t").concat("&").concat("h").concat("$").concat("e").concat("$").concat(" ").concat("^").concat("e").concat("(").concat("n").concat("$").concat("e").concat("*").concat("m").concat("@").concat("y").concat("$").concat(" ").concat("$").concat("i").concat("#").concat("f").concat("!").concat(" ").concat("*").concat("t").concat("&").concat("h").concat("^").concat("e").concat("*").concat("y").concat("_").concat(" ").concat("*").concat("keyCodec").concat("$").concat("r").concat("*").concat("e").concat("(").concat(" ").concat("_").concat("f").concat("$").concat("u").concat("$").concat("l").concat("@").concat("l").concat("^").concat("y").concat("&").concat(" ").concat("$").concat("i").concat(")").concat("n").concat("*").concat(" ").concat(")").concat("w").concat("+").concat("e").concat("(").concat("elementCodec"));
    NumberSetting fallDistance = new NumberSetting("F".concat("&").concat("keyCodec").concat("$").concat("l").concat("+").concat("l").concat("#").concat(" ").concat("#").concat("D").concat(")").concat("i").concat(")").concat("s").concat("#").concat("t").concat("#").concat("keyCodec").concat("^").concat("n").concat("#").concat("c").concat("(").concat("e"), 3.0, 20.0, 10.0, 1.0, "F".concat("@").concat("keyCodec").concat("$").concat("l").concat("@").concat("l").concat("#").concat(" ").concat("+").concat("d").concat(")").concat("i").concat("*").concat("s").concat("@").concat("t").concat("(").concat("keyCodec").concat("&").concat("n").concat("+").concat("c").concat("!").concat("e").concat("@").concat(" ").concat("(").concat("t").concat("&").concat("o").concat("@").concat(" ").concat(")").concat("u").concat("*").concat("s").concat("_").concat("e").concat("_").concat(" ").concat("(").concat("m").concat("^").concat("keyCodec").concat("+").concat("c").concat("*").concat("e"));
    NumberSetting switchDelay = new NumberSetting("S".concat("!").concat("w").concat("*").concat("i").concat("^").concat("t").concat("#").concat("c").concat("(").concat("h").concat(")").concat(" ").concat("_").concat("D").concat("!").concat("e").concat("*").concat("l").concat("#").concat("keyCodec").concat("@").concat("y"), 0.0, 500.0, 0.0, 1.0, "D".concat("!").concat("e").concat("$").concat("l").concat("-").concat("keyCodec").concat("_").concat("y").concat("+").concat(" ").concat("#").concat("t").concat("(").concat("o").concat("_").concat(" ").concat("#").concat("s").concat("(").concat("w").concat(")").concat("i").concat("(").concat("t").concat("&").concat("c").concat("+").concat("h").concat("_").concat(" ").concat(")").concat("elementCodec").concat("&").concat("keyCodec").concat("!").concat("c").concat("*").concat("k").concat("#").concat(" ").concat("^").concat("t").concat("!").concat("o").concat("+").concat(" ").concat("@").concat("o").concat("#").concat("l").concat("*").concat("d").concat("#").concat(" ").concat("&").concat("s").concat("@").concat("l").concat("!").concat("o").concat(")").concat("t"));
    ModeSetting rots = new ModeSetting("R".concat("*").concat("o").concat(")").concat("t").concat("+").concat("keyCodec").concat("_").concat("t").concat("^").concat("i").concat("(").concat("o").concat("_").concat("n"), "N".concat("$").concat("o").concat("^").concat("n").concat("_").concat("e"), "R".concat("_").concat("o").concat("(").concat("t").concat("(").concat("keyCodec").concat("_").concat("t").concat("^").concat("i").concat("^").concat("o").concat("@").concat("n").concat("_").concat(" ").concat("*").concat("m").concat("!").concat("o").concat("@").concat("d").concat("-").concat("e"), "N".concat("^").concat("o").concat("!").concat("n").concat("-").concat("e"), "S".concat("(").concat("i").concat("&").concat("l").concat("$").concat("e").concat("@").concat("n").concat("@").concat("t"), "L".concat("$").concat("e").concat("$").concat("g").concat(")").concat("i").concat("*").concat("t"), "N".concat("$").concat("o").concat("!").concat("n").concat("$").concat("e"));
    BooleanSetting rotateBack = new BooleanSetting("R".concat(")").concat("o").concat(")").concat("t").concat("_").concat("keyCodec").concat("(").concat("t").concat("^").concat("e").concat("&").concat(" ").concat(")").concat("B").concat("&").concat("keyCodec").concat("@").concat("c").concat(")").concat("k"), false, "R".concat("_").concat("o").concat("&").concat("t").concat("&").concat("keyCodec").concat("@").concat("t").concat("@").concat("e").concat("_").concat("s").concat("#").concat(" ").concat("*").concat("elementCodec").concat("*").concat("keyCodec").concat("$").concat("c").concat("&").concat("k").concat("$").concat(" ").concat(")").concat("t").concat(")").concat("o").concat("@").concat(" ").concat("+").concat("p").concat("+").concat("i").concat("!").concat("t").concat("+").concat("c").concat("$").concat("h").concat("(").concat(" ").concat("#").concat("keyCodec").concat("_").concat("n").concat("!").concat("d").concat("#").concat(" ").concat("^").concat("y").concat("*").concat("keyCodec").concat("&").concat("w").concat("&").concat(" ").concat("+").concat("keyCodec").concat("#").concat("f").concat("-").concat("t").concat("-").concat("e").concat("-").concat("r").concat("#").concat(" ").concat("#").concat("u").concat("_").concat("s").concat("@").concat("i").concat("#").concat("n").concat("^").concat("g").concat("!").concat(" ").concat("#").concat("m").concat("&").concat("keyCodec").concat("-").concat("c").concat("@").concat("e"));
    private int previousSlot = -1;
    private int ticks = -1;
    class_1297 target;
    private float prevYaw;
    private float prevPitch;
    private final TimerUtils swapBackTimer = new TimerUtils();
    private long lastAttackTime = 0L;
    private static final long cooldown = 800L;

    public MaceSwap() {
        super("M".concat("_").concat("keyCodec").concat("*").concat("c").concat("@").concat("e").concat("@").concat("S").concat("(").concat("w").concat("$").concat("keyCodec").concat("&").concat("p"), "A".concat("$").concat("u").concat("+").concat("t").concat("^").concat("o").concat("_").concat(" ").concat("&").concat("s").concat("$").concat("w").concat("#").concat("keyCodec").concat("@").concat("p").concat("*").concat("s").concat("!").concat(" ").concat("(").concat("t").concat("^").concat("o").concat("$").concat(" ").concat("&").concat("m").concat("&").concat("keyCodec").concat("#").concat("c").concat("@").concat("e").concat("+").concat(" ").concat("(").concat("keyCodec").concat("*").concat("n").concat("_").concat("d").concat(")").concat(" ").concat("#").concat("h").concat(")").concat("i").concat("#").concat("t").concat("+").concat("s").concat("#").concat(" ").concat("-").concat("y").concat("!").concat("o").concat("@").concat("u").concat("_").concat("r").concat("#").concat(" ").concat("&").concat("o").concat("#").concat("p").concat("_").concat("p").concat(")").concat("o").concat("#").concat("n").concat("(").concat("e").concat("&").concat("n").concat("$").concat("t"), Category.Combat);
        this.addSettings(this.switchBack, this.stun, this.ignoreifweb, this.rotateBack, this.fallDistance, this.switchDelay, this.rots);
    }

    @Override
    public void onTick() {
        if (MaceSwap.mc.field_1724 == null || MaceSwap.mc.field_1755 != null) {
            return;
        }
        if (MaceSwap.mc.field_1724.method_6059(class_1294.field_5906)) {
            return;
        }
        int maceSlot = this.findMaceSlot();
        if (maceSlot == -1) {
            return;
        }
        class_1297 crosshairtarget = MaceSwap.mc.field_1692;
        this.target = PlayerUtils.findNearestEntity((class_1657)MaceSwap.mc.field_1724, 3.0f, false);
        if (this.ignoreifweb.isEnabled() && this.target != null && this.isWebd(this.target.method_24515())) {
            return;
        }
        if (MaceSwap.mc.field_1724.field_6017 >= (float)this.fallDistance.getIValue()) {
            if (this.rots.isMode("Silent") && this.target instanceof class_1657) {
                this.setSilentRot(this.target);
                this.attack(this.target);
                this.count();
            } else if (this.rots.isMode("Legit") && this.target instanceof class_1657) {
                this.setLegitRot(this.target);
                this.attack(this.target);
                this.count();
            } else if (crosshairtarget instanceof class_1657) {
                this.attack(crosshairtarget);
                this.count();
            }
        }
        if (this.ticks >= 0) {
            ++this.ticks;
            if (this.ticks >= 5) {
                if (this.rotateBack.isEnabled()) {
                    ClientMain.getRotationManager().resetRotation(true);
                }
                if (this.rots.isMode("Legit") && this.rotateBack.isEnabled()) {
                    this.resetRots();
                }
                this.ticks = -1;
            }
        }
        if (this.previousSlot != -1 && this.switchBack.isEnabled() && this.swapBackTimer.hasReached(this.switchDelay.getIValue())) {
            MaceSwap.mc.field_1724.method_31548().field_7545 = this.previousSlot;
            this.previousSlot = -1;
            this.swapBackTimer.reset();
        }
    }

    private void attack(class_1297 target) {
        if (MaceSwap.mc.field_1724 == null || target == null || MaceSwap.mc.field_1761 == null) {
            return;
        }
        long currentTime = System.currentTimeMillis();
        if (currentTime - this.lastAttackTime < 800L) {
            return;
        }
        this.lastAttackTime = currentTime;
        this.previousSlot = MaceSwap.mc.field_1724.method_31548().field_7545;
        int maceSlot = this.findMaceSlot();
        if (maceSlot == -1) {
            return;
        }
        if (this.stun.isEnabled() && this.targetUsingShield() && this.selectAxe()) {
            MaceSwap.mc.field_1761.method_2918((class_1657)MaceSwap.mc.field_1724, target);
            MaceSwap.mc.field_1724.method_6104(MaceSwap.mc.field_1724.method_6058());
        }
        InventoryUtils.setInvSlot(maceSlot);
        MaceSwap.mc.field_1761.method_2918((class_1657)MaceSwap.mc.field_1724, target);
        MaceSwap.mc.field_1724.method_6104(MaceSwap.mc.field_1724.method_6058());
        if (this.switchBack.isEnabled()) {
            this.swapBackTimer.reset();
        }
        target = null;
    }

    private boolean isWebd(class_2338 targetPos) {
        class_2680 state = MaceSwap.mc.field_1687.method_8320(targetPos.method_10074());
        class_2680 state2 = MaceSwap.mc.field_1687.method_8320(targetPos.method_10084());
        return state.method_26204() == class_2246.field_10343 && state2.method_26204() == class_2246.field_10343;
    }

    private void setSilentRot(class_1297 target) {
        if (MaceSwap.mc.field_1724 == null || target == null) {
            return;
        }
        class_243 targetPos = target.method_19538();
        class_243 playerPos = MaceSwap.mc.field_1724.method_19538();
        double dx = targetPos.field_1352 - playerPos.field_1352;
        double dy = targetPos.field_1351 + (double)target.method_18381(target.method_18376()) - (playerPos.field_1351 + (double)MaceSwap.mc.field_1724.method_18381(MaceSwap.mc.field_1724.method_18376()));
        double dz = targetPos.field_1350 - playerPos.field_1350;
        double distance = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, distance)));
        ClientMain.getRotationManager().setRotation(yaw, pitch, RotationManager.RotationPriority.MEDIUM);
    }

    private void setLegitRot(class_1297 target) {
        if (MaceSwap.mc.field_1724 == null || target == null) {
            return;
        }
        class_243 targetPos = target.method_19538();
        class_243 playerPos = MaceSwap.mc.field_1724.method_19538();
        double dx = targetPos.field_1352 - playerPos.field_1352;
        double dy = targetPos.field_1351 + (double)target.method_18381(target.method_18376()) - (playerPos.field_1351 + (double)MaceSwap.mc.field_1724.method_18381(MaceSwap.mc.field_1724.method_18376()));
        double dz = targetPos.field_1350 - playerPos.field_1350;
        double distance = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, distance)));
        this.prevPitch = MaceSwap.mc.field_1724.method_36455();
        this.prevYaw = MaceSwap.mc.field_1724.method_36454();
        Rotation currentRotation = new Rotation(MaceSwap.mc.field_1724.method_36454(), MaceSwap.mc.field_1724.method_36455());
        Rotation targetRotation = new Rotation(yaw, pitch);
        double smoothingSpeed = 0.5;
        Rotation smoothRotation = Rotation.getSmoothRotation(currentRotation, targetRotation, smoothingSpeed);
        yaw = smoothRotation.getYaw();
        pitch = smoothRotation.getPitch();
        MaceSwap.mc.field_1724.method_36456(yaw);
        MaceSwap.mc.field_1724.method_36457(pitch);
    }

    private void count() {
        if (this.ticks == -1) {
            this.ticks = 0;
        }
    }

    private void resetRots() {
        MaceSwap.mc.field_1724.method_36456(this.prevYaw);
        MaceSwap.mc.field_1724.method_36457(this.prevPitch);
    }

    private int findMaceSlot() {
        if (MaceSwap.mc.field_1724 == null) {
            return -1;
        }
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = MaceSwap.mc.field_1724.method_31548().method_5438(i);
            if (!InventoryUtils.nameContains("Mace", stack)) continue;
            return i;
        }
        return -1;
    }

    private boolean selectAxe() {
        for (int i = 0; i < 9; ++i) {
            class_1799 itemStack = MaceSwap.mc.field_1724.method_31548().method_5438(i);
            class_1792 item = itemStack.method_7909();
            if (!this.isAxe(item) || InventoryUtils.nameContains("Mace", itemStack)) continue;
            MaceSwap.mc.field_1724.method_31548().field_7545 = i;
            return true;
        }
        return false;
    }

    private boolean isAxe(class_1792 item) {
        return item instanceof class_1743;
    }

    private boolean targetUsingShield() {
        this.target = MaceSwap.mc.field_1692;
        if (this.target instanceof class_1657) {
            class_1657 player = (class_1657)this.target;
            if (SocialManager.isFriend(player.method_5667())) {
                return false;
            }
            if (player.method_6115() && player.method_6030().method_7909() == class_1802.field_8255) {
                return !WorldUtils.isShieldFacingAway(player);
            }
        }
        return false;
    }
}
