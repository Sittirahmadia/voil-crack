package net.fabricmc.fabric.systems.module.impl.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.AttackEntityEvent;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.ColorPickerSetting;
import net.fabricmc.fabric.gui.setting.MultiOptionSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting2;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.packet.backtrack.TimedPacket;
import net.fabricmc.fabric.utils.render.ColorUtil;
import net.fabricmc.fabric.utils.render.Render3DEngine;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_2616;
import net.minecraft.class_2661;
import net.minecraft.class_2663;
import net.minecraft.class_2684;
import net.minecraft.class_2708;
import net.minecraft.class_2739;
import net.minecraft.class_2749;
import net.minecraft.class_2767;
import net.minecraft.class_2777;
import net.minecraft.class_3532;
import net.minecraft.class_3928;
import net.minecraft.class_4587;
import net.minecraft.class_5900;
import net.minecraft.class_7438;

public class Backtrack
extends Module {
    NumberSetting2 delay2 = new NumberSetting2("D".concat("*").concat("e").concat("!").concat("l").concat("^").concat("keyCodec").concat("#").concat("y"), 1.0, 10000.0, 500.0, 1200.0, 1.0, "D".concat(")").concat("e").concat("@").concat("l").concat("^").concat("keyCodec").concat("^").concat("y").concat("*").concat(" ").concat("^").concat("f").concat("&").concat("o").concat("+").concat("r").concat("*").concat(" ").concat("*").concat("t").concat("^").concat("h").concat("*").concat("e").concat("(").concat(" ").concat("*").concat("elementCodec").concat("$").concat("keyCodec").concat(")").concat("c").concat("#").concat("k").concat("-").concat("t").concat("*").concat("r").concat(")").concat("keyCodec").concat("_").concat("c").concat("^").concat("k"));
    ColorPickerSetting boxcolor = new ColorPickerSetting("B".concat("&").concat("o").concat("!").concat("x").concat("&").concat(" ").concat(")").concat("C").concat("^").concat("o").concat("#").concat("l").concat("*").concat("o").concat("_").concat("r"), new Color(130, 120, 255, 145), "C".concat("@").concat("o").concat("&").concat("l").concat("_").concat("o").concat("!").concat("r").concat("#").concat(" ").concat("$").concat("o").concat("!").concat("f").concat("&").concat(" ").concat("@").concat("t").concat("-").concat("h").concat("_").concat("e").concat("#").concat(" ").concat("#").concat("r").concat(")").concat("e").concat("$").concat("keyCodec").concat("!").concat("l").concat("+").concat(" ").concat("&").concat("p").concat("(").concat("o").concat("#").concat("s").concat("!").concat("i").concat("+").concat("t").concat("$").concat("i").concat("(").concat("o").concat("-").concat("n").concat("#").concat(" ").concat("^").concat("elementCodec").concat("*").concat("o").concat(")").concat("x"));
    NumberSetting range = new NumberSetting("R".concat("_").concat("keyCodec").concat("-").concat("n").concat("&").concat("g").concat("(").concat("e"), 1.0, 6.0, 4.5, 0.1, "R".concat("!").concat("keyCodec").concat("*").concat("n").concat("!").concat("g").concat("#").concat("e").concat("(").concat(" ").concat("!").concat("f").concat("#").concat("o").concat("-").concat("r").concat("@").concat(" ").concat("&").concat("t").concat("*").concat("h").concat("$").concat("e").concat("_").concat(" ").concat("$").concat("elementCodec").concat("+").concat("keyCodec").concat("-").concat("c").concat("$").concat("k").concat("_").concat("t").concat("&").concat("r").concat("_").concat("keyCodec").concat("$").concat("c").concat("#").concat("k").concat("-").concat(" ").concat("*").concat("t").concat("^").concat("o").concat(")").concat(" ").concat("&").concat("d").concat("-").concat("i").concat("*").concat("s").concat("#").concat("keyCodec").concat("!").concat("elementCodec").concat("!").concat("l").concat("&").concat("e"));
    BooleanSetting render = new BooleanSetting("R".concat("@").concat("e").concat("$").concat("n").concat("@").concat("d").concat(")").concat("e").concat("(").concat("r"), true, "R".concat("(").concat("e").concat("+").concat("n").concat("#").concat("d").concat("(").concat("e").concat("_").concat("r").concat("+").concat(" ").concat("$").concat("t").concat("-").concat("h").concat("^").concat("e").concat(")").concat(" ").concat("!").concat("r").concat("$").concat("e").concat("^").concat("keyCodec").concat("*").concat("l").concat("_").concat(" ").concat("&").concat("p").concat("(").concat("o").concat("@").concat("s").concat("$").concat("i").concat("*").concat("t").concat("&").concat("i").concat("!").concat("o").concat("!").concat("n"));
    BooleanSetting sendPacketsWithDelay = new BooleanSetting("S".concat("_").concat("e").concat("^").concat("n").concat("&").concat("d").concat("+").concat(" ").concat("!").concat("P").concat("$").concat("keyCodec").concat("&").concat("c").concat("&").concat("k").concat("&").concat("e").concat(")").concat("t").concat("+").concat("s").concat("#").concat(" ").concat(")").concat("D").concat("#").concat("e").concat("_").concat("l").concat("_").concat("keyCodec").concat("#").concat("y").concat("#").concat("e").concat(")").concat("d"), true, "S".concat("+").concat("e").concat("#").concat("n").concat(")").concat("d").concat("+").concat(" ").concat("*").concat("p").concat("(").concat("keyCodec").concat("@").concat("c").concat("&").concat("k").concat("!").concat("e").concat("*").concat("t").concat(")").concat("s").concat("&").concat(" ").concat("!").concat("w").concat("$").concat("i").concat("-").concat("t").concat("+").concat("h").concat("+").concat(" ").concat("-").concat("d").concat("&").concat("e").concat(")").concat("l").concat("&").concat("keyCodec").concat("+").concat("y"));
    MultiOptionSetting options = new MultiOptionSetting("O".concat("@").concat("p").concat("&").concat("t").concat("*").concat("i").concat("&").concat("o").concat(")").concat("n").concat("@").concat("s"), "S".concat(")").concat("t").concat("*").concat("u").concat("@").concat("f").concat("*").concat("f").concat("$").concat(" ").concat("@").concat("t").concat("_").concat("o").concat("!").concat(" ").concat("_").concat("f").concat("+").concat("l").concat("$").concat("u").concat("-").concat("s").concat("-").concat("h").concat("^").concat(" ").concat("!").concat("p").concat("&").concat("keyCodec").concat("(").concat("c").concat("+").concat("k").concat("&").concat("e").concat("+").concat("t").concat("!").concat("s").concat("^").concat(" ").concat("-").concat("o").concat("#").concat("n"), "U".concat("$").concat("p").concat(")").concat("d").concat("(").concat("keyCodec").concat("$").concat("t").concat("!").concat("e").concat("*").concat("H").concat("&").concat("e").concat("_").concat("keyCodec").concat("$").concat("l").concat("^").concat("t").concat("(").concat("h"), "U".concat("^").concat("p").concat("$").concat("d").concat("&").concat("keyCodec").concat("#").concat("t").concat("^").concat("e").concat(")").concat("S").concat("$").concat("h").concat("#").concat("i").concat("+").concat("e").concat("*").concat("l").concat("*").concat("d"), "K".concat("+").concat("e").concat("+").concat("e").concat("!").concat("p").concat(")").concat("S").concat("#").concat("o").concat("*").concat("u").concat("&").concat("n").concat("(").concat("d"), "S".concat("!").concat("t").concat("+").concat("o").concat("^").concat("p").concat("&").concat("R").concat("&").concat("keyCodec").concat("+").concat("n").concat("*").concat("g").concat("+").concat("e"));
    private final Queue<TimedPacket> packetQueue = new ConcurrentLinkedQueue<TimedPacket>();
    private final List<class_2596<?>> skipPackets = new ArrayList();
    private class_1297 target;
    private class_243 pos;
    private int currentLatency = 0;
    private boolean dumpNextTick = false;

    public Backtrack() {
        super("B".concat("!").concat("keyCodec").concat(")").concat("c").concat(")").concat("k").concat("$").concat("t").concat("!").concat("r").concat("@").concat("keyCodec").concat("+").concat("c").concat("_").concat("k"), "L".concat("+").concat("keyCodec").concat("@").concat("g").concat("#").concat("s").concat("^").concat(" ").concat(")").concat("e").concat("$").concat("n").concat("@").concat("e").concat("!").concat("m").concat(")").concat("i").concat("#").concat("e").concat("*").concat("s").concat("-").concat(" ").concat("*").concat("i").concat("*").concat("n").concat("+").concat("t").concat("+").concat("o").concat("^").concat(" ").concat("&").concat("p").concat("!").concat("r").concat("-").concat("e").concat("&").concat("v").concat("^").concat("i").concat("$").concat("o").concat("*").concat("u").concat("^").concat("s").concat("+").concat(" ").concat("&").concat("p").concat("*").concat("o").concat("@").concat("s").concat("_").concat("i").concat("&").concat("t").concat("*").concat("i").concat("@").concat("o").concat("&").concat("n").concat(")").concat("s"), Category.Combat);
        this.addSettings(this.render, this.sendPacketsWithDelay, this.range, this.delay2, this.options, this.boxcolor);
    }

    @Override
    public void onEnable() {
        this.packetQueue.clear();
        this.skipPackets.clear();
        this.target = null;
        this.pos = null;
    }

    @Override
    public void onDisable() {
        this.dumpPackets();
        this.target = null;
        this.pos = null;
    }

    @EventHandler(priority=200)
    public void onPacketReceive(PacketEvent.Receive e) {
        if (this.target == null || Backtrack.mc.field_1687 == null) {
            return;
        }
        if (!this.cancelPackets(this.target)) {
            return;
        }
        class_2596<?> p = e.getPacket();
        try {
            class_2777 packet;
            class_2739 etu;
            if (this.target == null || !this.target.method_5805()) {
                this.dumpNextTick = true;
                return;
            }
            if (e.isCancelled()) {
                return;
            }
            if (p instanceof class_2767 && this.options.getOption("KeepSound").isEnabled()) {
                return;
            }
            if (p instanceof class_2749 && this.options.getOption("UpdateHealth").isEnabled()) {
                return;
            }
            if (p instanceof class_2739 && (etu = (class_2739)p).comp_1127() != Backtrack.mc.field_1724.method_5628() && this.options.getOption("UpdateShield").isEnabled()) {
                return;
            }
            if (p instanceof class_2663 || p instanceof class_7438 || p instanceof class_2616 || p instanceof class_5900) {
                return;
            }
            if (e.getPacket() instanceof class_2777 && (packet = (class_2777)e.packet).method_11916() == this.target.method_5628()) {
                this.pos = new class_243(packet.method_11917(), packet.method_11919(), packet.method_11918());
            }
            if (e.packet instanceof class_2684 && ((class_2684)e.packet).method_11645((class_1937)Backtrack.mc.field_1687) == this.target || e.packet instanceof class_2777 && ((class_2777)e.packet).method_11916() == this.target.method_5628()) {
                this.pos = e.packet instanceof class_2684 ? new class_243(this.pos.field_1352 + (double)((class_2684)e.packet).method_36150() / 4096.0, this.pos.field_1351 + (double)((class_2684)e.packet).method_36151() / 4096.0, this.pos.field_1350 + (double)((class_2684)e.packet).method_36152() / 4096.0) : new class_243(((class_2777)e.packet).method_11917(), ((class_2777)e.packet).method_11919(), ((class_2777)e.packet).method_11918());
                if ((double)class_3532.method_15355((float)((float)Backtrack.mc.field_1724.method_5707(this.pos))) > this.range.getValue() && this.options.getOption("StopRange").isEnabled()) {
                    this.dumpNextTick = true;
                    return;
                }
            }
            if (p instanceof class_2708 || p instanceof class_2661) {
                this.dumpNextTick = true;
                this.target = null;
                this.pos = null;
                return;
            }
            long delay = this.sendPacketsWithDelay.isEnabled() ? (long)((double)System.currentTimeMillis() + this.delay2.getRandomValue()) : 0L;
            this.packetQueue.add(new TimedPacket(p, delay));
            e.cancel();
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    @Override
    public void onWorldRender(class_4587 matrices) {
        if (this.render.isEnabled() && this.target != null && this.pos != null) {
            Color boxcolor2 = ColorUtil.addAlpha(this.boxcolor.getColor(), 145);
            Render3DEngine.drawBox(this.pos, boxcolor2, matrices);
        }
    }

    @Override
    public void onTick() {
        this.setSuffix(this.currentLatency);
        if (this.dumpNextTick) {
            this.dumpPackets();
            this.dumpNextTick = false;
            return;
        }
        if (Backtrack.mc.field_1755 instanceof class_3928) {
            this.dumpPackets();
        }
        if (!this.packetQueue.isEmpty()) {
            TimedPacket timedPacket = this.packetQueue.peek();
            if (timedPacket != null && timedPacket.getTimer().hasCooldownElapsed(this.currentLatency)) {
                this.dumpPackets();
            } else if (this.sendPacketsWithDelay.isEnabled() && timedPacket != null && System.currentTimeMillis() >= timedPacket.getMillis()) {
                this.dumpPackets();
            }
        }
    }

    @EventHandler
    public void onAttack(AttackEntityEvent.Pre event) {
        int newLatency;
        if (!this.cancelPackets(event.target)) {
            return;
        }
        if (this.target != event.target) {
            this.target = event.target;
            this.pos = this.target.method_19538();
        }
        if ((newLatency = (int)this.delay2.getRandomValue()) != this.currentLatency) {
            this.currentLatency = newLatency;
        }
    }

    private boolean cancelPackets(class_1297 entity) {
        boolean result = entity != null && entity.method_5805();
        return result;
    }

    private void dumpPackets() {
        if (mc.method_1562() == null) {
            return;
        }
        while (!this.packetQueue.isEmpty()) {
            TimedPacket timedPacket = this.packetQueue.poll();
            if (timedPacket == null) continue;
            class_2596 packet = timedPacket.getPacket();
            this.skipPackets.add(packet);
            mc.execute(() -> packet.method_11054((class_2547)mc.method_1562()));
            this.currentLatency = 0;
        }
        this.target = null;
        this.pos = null;
    }
}
