package net.fabricmc.fabric.systems.module.impl.player;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.EntitySpawnEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.managers.rotation.Rotation;
import net.fabricmc.fabric.managers.rotation.RotationManager;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1684;
import net.minecraft.class_1776;
import net.minecraft.class_243;
import net.minecraft.class_3532;

public class PearlChase
extends Module {
    private ModeSetting rotation = new ModeSetting("R".concat("*").concat("o").concat(")").concat("t").concat("+").concat("keyCodec").concat("#").concat("t").concat("!").concat("i").concat("@").concat("o").concat("@").concat("n"), "N".concat("!").concat("o").concat("#").concat("r").concat("*").concat("m").concat("(").concat("keyCodec").concat("(").concat("l"), "R".concat("#").concat("o").concat("!").concat("t").concat("@").concat("keyCodec").concat("(").concat("t").concat("@").concat("i").concat("-").concat("o").concat("&").concat("n").concat("&").concat(" ").concat(")").concat("t").concat("#").concat("y").concat("-").concat("p").concat("-").concat("e"), "N".concat("^").concat("o").concat("(").concat("r").concat("#").concat("m").concat("_").concat("keyCodec").concat("*").concat("l"), "S".concat("#").concat("i").concat("!").concat("l").concat(")").concat("e").concat("_").concat("n").concat("*").concat("t"));
    private BooleanSetting onlyifHeatlhBigger = new BooleanSetting("H".concat("+").concat("e").concat("_").concat("keyCodec").concat("$").concat("l").concat("_").concat("t").concat("_").concat("h").concat("^").concat(" ").concat("-").concat("c").concat("&").concat("h").concat("$").concat("e").concat("_").concat("c").concat("@").concat("k"), false, "O".concat("-").concat("n").concat("*").concat("l").concat("!").concat("y").concat("_").concat(" ").concat("+").concat("c").concat(")").concat("h").concat("&").concat("keyCodec").concat("_").concat("s").concat("-").concat("e").concat("+").concat("s").concat("_").concat(" ").concat("@").concat("p").concat("*").concat("e").concat("^").concat("keyCodec").concat("(").concat("r").concat("!").concat("l").concat("$").concat(" ").concat("+").concat("i").concat("_").concat("f").concat("-").concat(" ").concat("(").concat("y").concat("$").concat("o").concat("@").concat("u").concat("&").concat("r").concat(")").concat(" ").concat("(").concat("h").concat("_").concat("e").concat("$").concat("keyCodec").concat("+").concat("l").concat("$").concat("t").concat("#").concat("h").concat("!").concat(" ").concat("$").concat("i").concat("!").concat("s").concat("@").concat(" ").concat("@").concat("m").concat(")").concat("o").concat("#").concat("r").concat("+").concat("e").concat("@").concat(" ").concat("&").concat("t").concat("!").concat("h").concat("_").concat("keyCodec").concat("_").concat("n").concat("@").concat(" ").concat("^").concat("t").concat("^").concat("h").concat("*").concat("e").concat("*").concat("i").concat("&").concat("r").concat("&").concat(" ").concat("$").concat("h").concat("*").concat("e").concat("$").concat("keyCodec").concat("_").concat("l").concat("+").concat("t").concat("#").concat("h"));
    private class_1684 targetPearl;

    public PearlChase() {
        super("P".concat("@").concat("e").concat(")").concat("keyCodec").concat("$").concat("r").concat("#").concat("l").concat("-").concat("C").concat("+").concat("h").concat("@").concat("keyCodec").concat("^").concat("s").concat("^").concat("e"), "M".concat("+").concat("keyCodec").concat("*").concat("k").concat(")").concat("e").concat("#").concat("s").concat("^").concat(" ").concat("$").concat("y").concat("!").concat("o").concat("*").concat("u").concat("_").concat(" ").concat("!").concat("c").concat("&").concat("h").concat("!").concat("keyCodec").concat("*").concat("s").concat("&").concat("e").concat("!").concat(" ").concat("#").concat("t").concat("+").concat("h").concat("&").concat("e").concat("$").concat(" ").concat("@").concat("e").concat("#").concat("n").concat("$").concat("e").concat("!").concat("m").concat("*").concat("y").concat("$").concat(" ").concat("$").concat("p").concat("*").concat("e").concat(")").concat("keyCodec").concat("+").concat("r").concat("*").concat("l"), Category.Player);
        this.addSettings(this.rotation, this.onlyifHeatlhBigger);
    }

    @EventHandler
    private void onEntitySpawn(EntitySpawnEvent e) {
        class_1684 pearl;
        class_1297 owner;
        class_1297 entity = e.getEntity();
        if (entity instanceof class_1684 && (owner = (pearl = (class_1684)entity).method_24921()) != null && !owner.method_5667().equals(PearlChase.mc.field_1724.method_5667())) {
            this.targetPearl = pearl;
        }
    }

    @Override
    public void onTick() {
        class_1297 entity;
        if (this.targetPearl == null || this.targetPearl.method_31481()) {
            return;
        }
        if (this.onlyifHeatlhBigger.isEnabled() && (entity = this.targetPearl.method_24921()) instanceof class_1309) {
            class_1309 owner = (class_1309)entity;
            if (PearlChase.mc.field_1724.method_6032() <= owner.method_6032()) {
                return;
            }
        }
        class_243 pearlPos = this.targetPearl.method_19538();
        class_243 playerPos = PearlChase.mc.field_1724.method_19538().method_1031(0.0, (double)PearlChase.mc.field_1724.method_18381(PearlChase.mc.field_1724.method_18376()), 0.0);
        class_243 diff = pearlPos.method_1020(playerPos);
        double distXZ = Math.sqrt(diff.field_1352 * diff.field_1352 + diff.field_1350 * diff.field_1350);
        float yaw = (float)(class_3532.method_15349((double)diff.field_1350, (double)diff.field_1352) * 57.29577951308232) - 90.0f;
        float pitch = (float)(-(class_3532.method_15349((double)diff.field_1351, (double)distXZ) * 57.29577951308232));
        if (this.rotation.getMode().equals("Normal")) {
            PearlChase.mc.field_1724.method_36456(yaw);
            PearlChase.mc.field_1724.method_36457(pitch);
        } else if (this.rotation.getMode().equals("Silent")) {
            ClientMain.getRotationManager().setRotation(new Rotation(yaw, pitch), RotationManager.RotationPriority.MEDIUM);
        }
        int pearlSlot = -1;
        for (int i = 0; i < 9; ++i) {
            if (!(PearlChase.mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1776)) continue;
            pearlSlot = i;
            break;
        }
        if (pearlSlot != -1) {
            PearlChase.mc.field_1724.method_31548().field_7545 = pearlSlot;
            PearlChase.mc.field_1761.method_2919((class_1657)PearlChase.mc.field_1724, class_1268.field_5808);
            this.targetPearl = null;
            ClientMain.getRotationManager().resetRotation(true);
        }
    }
}
