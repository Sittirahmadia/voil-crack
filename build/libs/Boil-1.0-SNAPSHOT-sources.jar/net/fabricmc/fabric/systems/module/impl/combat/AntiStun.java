package net.fabricmc.fabric.systems.module.impl.combat;

import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1819;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2616;
import net.minecraft.class_3959;
import net.minecraft.class_3965;

public class AntiStun
extends Module {
    BooleanSetting healthCheck = new BooleanSetting("H".concat("&").concat("e").concat("_").concat("keyCodec").concat("+").concat("l").concat("^").concat("t").concat("+").concat("h").concat("(").concat(" ").concat("@").concat("C").concat("$").concat("h").concat("*").concat("e").concat(")").concat("c").concat("+").concat("k"), true, "I".concat("@").concat("f").concat("#").concat(" ").concat("$").concat("h").concat("+").concat("e").concat("(").concat("keyCodec").concat("#").concat("l").concat("!").concat("t").concat("@").concat("h").concat(")").concat(" ").concat("_").concat("i").concat("&").concat("s").concat("$").concat(" ").concat("$").concat("elementCodec").concat("(").concat("e").concat("$").concat("l").concat(")").concat("o").concat("-").concat("w").concat("$").concat(" ").concat("+").concat("keyCodec").concat(")").concat(" ").concat(")").concat("c").concat("(").concat("e").concat("&").concat("r").concat("*").concat("t").concat("-").concat("keyCodec").concat("+").concat("i").concat("@").concat("n").concat("@").concat(" ").concat("(").concat("v").concat("@").concat("keyCodec").concat("(").concat("l").concat("_").concat("u").concat("_").concat("e").concat("!").concat(" ").concat("#").concat("i").concat("!").concat("t").concat("^").concat(" ").concat("-").concat("w").concat("-").concat("o").concat("@").concat("n").concat("@").concat("t").concat("#").concat(" ").concat(")").concat("u").concat("#").concat("n").concat("&").concat("s").concat("^").concat("h").concat("&").concat("i").concat("(").concat("e").concat("#").concat("l").concat("^").concat("d"));
    NumberSetting health = new NumberSetting("H".concat("^").concat("e").concat("+").concat("keyCodec").concat("^").concat("l").concat("*").concat("t").concat("-").concat("h"), 1.0, 19.0, 10.0, 1.0, "I".concat("$").concat("f").concat("*").concat(" ").concat("*").concat("h").concat("$").concat("e").concat("(").concat("keyCodec").concat("_").concat("l").concat(")").concat("t").concat("@").concat("h").concat("@").concat(" ").concat("+").concat("i").concat("+").concat("s").concat("$").concat(" ").concat("!").concat("elementCodec").concat("^").concat("e").concat("&").concat("l").concat("$").concat("o").concat("@").concat("w").concat("!").concat(" ").concat("(").concat("t").concat("!").concat("h").concat("-").concat("i").concat("_").concat("s").concat("$").concat(" ").concat("^").concat("v").concat("$").concat("keyCodec").concat("&").concat("l").concat(")").concat("u").concat("&").concat("e").concat("^").concat(" ").concat("#").concat("i").concat("$").concat("t").concat("&").concat(" ").concat("!").concat("w").concat("_").concat("o").concat("#").concat("n").concat("&").concat("t").concat("#").concat(" ").concat("^").concat("u").concat("!").concat("n").concat("&").concat("s").concat("^").concat("h").concat("_").concat("i").concat("+").concat("e").concat("@").concat("l").concat("&").concat("d"));
    boolean unShield;

    public AntiStun() {
        super("A".concat("-").concat("n").concat("*").concat("t").concat("_").concat("i").concat(")").concat("S").concat("$").concat("t").concat("-").concat("u").concat("!").concat("n"), "U".concat("^").concat("n").concat("!").concat("-").concat("(").concat("s").concat("@").concat("h").concat("^").concat("i").concat("&").concat("e").concat("&").concat("l").concat("+").concat("d").concat("#").concat("s").concat("-").concat(" ").concat(")").concat("w").concat("!").concat("h").concat("(").concat("e").concat("#").concat("n").concat("$").concat(" ").concat("@").concat("e").concat("_").concat("n").concat("+").concat("e").concat("-").concat("m").concat("+").concat("y").concat("+").concat(" ").concat("#").concat("t").concat("_").concat("r").concat(")").concat("i").concat(")").concat("e").concat("#").concat("s").concat("(").concat(" ").concat("+").concat("t").concat(")").concat("o").concat("@").concat(" ").concat("#").concat("keyCodec").concat("-").concat("t").concat("(").concat("t").concat("@").concat("keyCodec").concat("^").concat("c").concat("^").concat("k").concat("+").concat(" ").concat("^").concat("y").concat("$").concat("o").concat("_").concat("u").concat(")").concat(" ").concat("-").concat("w").concat("*").concat("i").concat("$").concat("t").concat(")").concat("h").concat("!").concat(" ").concat("+").concat("keyCodec").concat("#").concat("n").concat("*").concat(" ").concat("-").concat("keyCodec").concat("#").concat("x").concat("#").concat("e"), Category.Combat);
        this.addSettings(this.healthCheck, this.health);
    }

    @Override
    public void onTick() {
        if (AntiStun.mc.field_1724 == null || AntiStun.mc.field_1687 == null) {
            return;
        }
        if (AntiStun.mc.field_1724.method_6058() == class_1268.field_5810 && AntiStun.mc.field_1724.method_6079().method_7909() instanceof class_1819) {
            if (this.healthCheck.isEnabled() && (double)AntiStun.mc.field_1724.method_6032() <= this.health.getValue()) {
                this.unShield = false;
                return;
            }
            if (this.unShield) {
                this.unShield = false;
            }
        }
    }

    private boolean isPlayerAimingAtMe() {
        class_238 clientPlayerBox = AntiStun.mc.field_1724.method_5829().method_1014(0.5);
        for (class_1657 otherPlayer : AntiStun.mc.field_1687.method_18456()) {
            if (otherPlayer.equals((Object)AntiStun.mc.field_1724) || !(otherPlayer.method_6047().method_7909() instanceof class_1743)) continue;
            class_243 otherPlayerEyePos = otherPlayer.method_33571();
            class_243 lookDirection = otherPlayer.method_5828(1.0f);
            class_243 endPos = otherPlayerEyePos.method_1019(lookDirection.method_1021(50.0));
            class_3959 context = new class_3959(otherPlayerEyePos, endPos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)otherPlayer);
            class_3965 hitResult = AntiStun.mc.field_1687.method_17742(context);
            if (!clientPlayerBox.method_993(otherPlayerEyePos, endPos) && (hitResult.method_17783() == class_239.class_240.field_1333 || !clientPlayerBox.method_1006(hitResult.method_17784()))) continue;
            return true;
        }
        return false;
    }

    private boolean isWithinBlocks() {
        for (class_1657 otherPlayer : AntiStun.mc.field_1687.method_18456()) {
            double distance;
            if (otherPlayer.equals((Object)AntiStun.mc.field_1724) || !((distance = AntiStun.mc.field_1724.method_5858((class_1297)otherPlayer)) <= 9.0)) continue;
            return true;
        }
        return false;
    }

    @EventHandler
    public void onPacket(PacketEvent.Receive event) {
        class_2616 packet;
        class_2596<?> packet2 = event.getPacket();
        if (packet2 instanceof class_2616 && (packet = (class_2616)packet2).method_11267() == 0 && packet.method_11269() != AntiStun.mc.field_1724.method_5628() && this.isWithinBlocks() && this.isPlayerAimingAtMe()) {
            AntiStun.mc.field_1724.method_6075();
        }
    }
}
