package net.fabricmc.fabric.systems.module.impl.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.render.Render2DEngine;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_9801;

public class Radar
extends Module {
    private final int radarSize = 80;
    private final int radarX = 2;
    private final int radarY = 30;

    public Radar() {
        super("R".concat("@").concat("keyCodec").concat("#").concat("d").concat("*").concat("keyCodec").concat("-").concat("r"), "s".concat("^").concat("h").concat("$").concat("o").concat("^").concat("w").concat("#").concat("s").concat("!").concat(" ").concat(")").concat("w").concat("&").concat("h").concat("#").concat("e").concat("@").concat("r").concat("$").concat("e").concat("_").concat(" ").concat("+").concat("o").concat("*").concat("t").concat("-").concat("h").concat("&").concat("e").concat("$").concat("r").concat(")").concat(" ").concat("$").concat("p").concat("_").concat("l").concat("-").concat("keyCodec").concat("^").concat("y").concat(")").concat("e").concat("$").concat("r").concat("&").concat("s").concat("*").concat(" ").concat("+").concat("keyCodec").concat("$").concat("r").concat("$").concat("e"), Category.Render);
    }

    @Override
    public void draw(class_4587 matrices) {
        if (Radar.mc.field_1724 == null || Radar.mc.field_1687 == null) {
            return;
        }
        Render2DEngine.drawRoundedBlur(matrices, 2.0f, 30.0f, 80.0f, 80.0f, 6.0f, 14.0f, 0.0f, true);
        Render2DEngine.drawCircle(matrices, Color.WHITE, 42.0, 70.0, 3.0, 20);
        this.drawFOVCone(matrices, 42.0, 70.0, 20.0, 90.0, new Color(255, 255, 255, 200));
        for (class_1297 entity : Radar.mc.field_1687.method_18112()) {
            if (entity == Radar.mc.field_1724 || !(entity instanceof class_1657)) continue;
            this.drawEntityOnRadar(matrices, entity, Color.RED);
        }
    }

    public void drawFOVCone(class_4587 matrices, double centerX, double centerY, double radius, double fovAngle, Color color) {
        double playerLook = Math.toRadians(Radar.mc.field_1724.method_36454());
        double leftX = centerX + radius * Math.cos(playerLook + Math.toRadians(fovAngle));
        double leftY = centerY + radius * Math.sin(playerLook + Math.toRadians(fovAngle));
        double rightX = centerX + radius * Math.cos(playerLook - Math.toRadians(fovAngle));
        double rightY = centerY + radius * Math.sin(playerLook - Math.toRadians(fovAngle));
        Radar.drawTriangle(matrices, centerX, centerY, leftX, leftY, rightX, rightY, color);
    }

    public static void drawTriangle(class_4587 matrices, double x1, double y1, double x2, double y2, double x3, double y3, Color color) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(class_757::method_34539);
        class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27379, class_290.field_1576);
        float r = (float)color.getRed() / 255.0f;
        float g = (float)color.getGreen() / 255.0f;
        float b = (float)color.getBlue() / 255.0f;
        float a = (float)color.getAlpha() / 255.0f;
        buffer.method_22912((float)x1, (float)y1, 0.0f).method_22915(r, g, b, a);
        buffer.method_22912((float)x2, (float)y2, 0.0f).method_22915(r, g, b, a);
        buffer.method_22912((float)x3, (float)y3, 0.0f).method_22915(r, g, b, a);
        class_286.method_43433((class_9801)buffer.method_60800());
        RenderSystem.disableBlend();
    }

    private void drawEntityOnRadar(class_4587 matrices, class_1297 entity, Color color) {
        if (Radar.mc.field_1724 == null) {
            return;
        }
        class_243 playerPos = Radar.mc.field_1724.method_19538();
        class_243 entityPos = entity.method_19538();
        double radarHalf = 40.0;
        double radarCenterX = 2.0 + radarHalf;
        double radarCenterY = 30.0 + radarHalf;
        double scale = radarHalf / 50.0;
        double offsetX = (entityPos.field_1352 - playerPos.field_1352) * scale;
        double offsetZ = (entityPos.field_1350 - playerPos.field_1350) * scale;
        double posX = radarCenterX + offsetX;
        double posY = radarCenterY + offsetZ;
        posX = Math.max(2.0, Math.min(82.0, posX));
        posY = Math.max(30.0, Math.min(110.0, posY));
        Render2DEngine.drawCircle(matrices, color, posX, posY, 3.0, 20);
    }
}
