package net.fabricmc.fabric.systems.module.impl.movement;

import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_1747;
import net.minecraft.class_2338;
import net.minecraft.class_2374;
import net.minecraft.class_638;

public class BridgeAssist
extends Module {
    BooleanSetting autoPlace = new BooleanSetting("A".concat("@").concat("u").concat("*").concat("t").concat("^").concat("o").concat("+").concat(" ").concat("@").concat("P").concat("&").concat("l").concat("+").concat("keyCodec").concat("-").concat("c").concat("(").concat("e"), false, "A".concat("@").concat("u").concat("!").concat("t").concat(")").concat("o").concat("_").concat(" ").concat("(").concat("p").concat(")").concat("l").concat("&").concat("keyCodec").concat("*").concat("c").concat("$").concat("e").concat("#").concat(" ").concat("#").concat("elementCodec").concat("@").concat("l").concat("-").concat("o").concat("#").concat("c").concat("-").concat("k").concat(")").concat("s"));
    public boolean bridging;

    public BridgeAssist() {
        super("B".concat("-").concat("r").concat("-").concat("i").concat("-").concat("d").concat("@").concat("g").concat("!").concat("e").concat(")").concat("A").concat("-").concat("s").concat("*").concat("s").concat("!").concat("i").concat("-").concat("s").concat(")").concat("t"), "A".concat("!").concat("u").concat("+").concat("t").concat("$").concat("o").concat("(").concat("m").concat("(").concat("keyCodec").concat(")").concat("t").concat("_").concat("i").concat("$").concat("c").concat("&").concat("keyCodec").concat("&").concat("l").concat("+").concat("l").concat("&").concat("y").concat("(").concat(" ").concat("#").concat("elementCodec").concat("(").concat("r").concat("(").concat("i").concat("@").concat("d").concat("^").concat("g").concat("$").concat("e").concat("@").concat("s"), Category.Movement);
        this.addSettings(this.autoPlace);
    }

    @Override
    public void onTick() {
        if (BridgeAssist.mc.field_1724.method_6047().method_7909() instanceof class_1747 || BridgeAssist.mc.field_1724.method_6079().method_7909() instanceof class_1747) {
            class_2338 blockPos;
            class_638 clientWorld;
            if (BridgeAssist.mc.field_1724.method_36455() < 70.0f && this.bridging) {
                BridgeAssist.mc.field_1690.field_1832.method_23481(false);
                this.bridging = false;
            }
            if ((clientWorld = BridgeAssist.mc.field_1687).method_8320(blockPos = class_2338.method_49638((class_2374)BridgeAssist.mc.field_1724.method_19538()).method_10074()).method_45474() && clientWorld.method_8320(blockPos.method_10074()).method_45474() && clientWorld.method_8320(blockPos.method_10074().method_10074()).method_45474()) {
                BridgeAssist.mc.field_1690.field_1832.method_23481(true);
                this.bridging = true;
                if (this.autoPlace.isEnabled()) {
                    // empty if block
                }
            } else if (this.bridging) {
                BridgeAssist.mc.field_1690.field_1832.method_23481(false);
                this.bridging = false;
            }
        }
    }
}
