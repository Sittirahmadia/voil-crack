package net.fabricmc.fabric.systems.module.impl.player;

import java.awt.Color;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.AttackEntityEvent;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.api.astral.events.WorldRenderEvent;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.Utils;
import net.fabricmc.fabric.utils.player.ChatUtils;
import net.fabricmc.fabric.utils.render.Render2DEngine;
import net.fabricmc.fabric.utils.world.WorldUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2596;
import net.minecraft.class_2663;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import org.joml.Quaternionf;

public class Tracker
extends Module {
    ModeSetting mode = new ModeSetting("M".concat("$").concat("o").concat("+").concat("d").concat(")").concat("e"), "A".concat("@").concat("t").concat("*").concat("t").concat("&").concat("keyCodec").concat("*").concat("c").concat("(").concat("k").concat("(").concat("e").concat("&").concat("d"), "M".concat("(").concat("o").concat(")").concat("d").concat(")").concat("e").concat("*").concat(" ").concat("$").concat("o").concat("#").concat("f").concat("!").concat(" ").concat("^").concat("t").concat("+").concat("h").concat("!").concat("e").concat(")").concat(" ").concat("@").concat("t").concat("#").concat("r").concat("^").concat("keyCodec").concat("-").concat("c").concat("#").concat("k").concat("-").concat("e").concat("&").concat("r"), "C".concat("@").concat("l").concat("_").concat("o").concat("*").concat("s").concat("*").concat("e").concat("-").concat("s").concat("#").concat("t"), "A".concat("-").concat("t").concat("!").concat("t").concat("&").concat("keyCodec").concat("!").concat("c").concat("*").concat("k").concat("(").concat("e").concat(")").concat("d"));
    private final Map<UUID, Integer> gaps = new HashMap<UUID, Integer>();
    private final Map<UUID, Integer> crystals = new HashMap<UUID, Integer>();
    private final Map<UUID, Integer> totems = new HashMap<UUID, Integer>();
    private final Map<UUID, Integer> exp = new HashMap<UUID, Integer>();
    private static class_1657 target;
    private static final Set<Class<?>> loggedPackets;

    public Tracker() {
        super("T".concat("#").concat("r").concat("-").concat("keyCodec").concat("#").concat("c").concat("-").concat("k").concat("&").concat("e").concat(")").concat("r"), "T".concat("(").concat("r").concat("@").concat("keyCodec").concat("+").concat("c").concat("_").concat("k").concat("@").concat("s").concat("_").concat(" ").concat("#").concat("i").concat("-").concat("t").concat("_").concat("e").concat("!").concat("m").concat("!").concat("s").concat("#").concat(" ").concat("&").concat("o").concat("!").concat("f").concat("*").concat(" ").concat("+").concat("t").concat("!").concat("h").concat("+").concat("e").concat("@").concat(" ").concat("!").concat("o").concat("(").concat("t").concat("@").concat("h").concat("^").concat("e").concat("*").concat("r").concat("!").concat(" ").concat(")").concat("p").concat("!").concat("l").concat(")").concat("keyCodec").concat("#").concat("y").concat("(").concat("e").concat("*").concat("r"), Category.Player);
        this.addSettings(this.mode);
    }

    @Override
    public void onEnable() {
        this.clearAllMaps();
    }

    @Override
    public void onDisable() {
        this.clearAllMaps();
    }

    private void clearAllMaps() {
        this.gaps.clear();
        this.crystals.clear();
        this.totems.clear();
        this.exp.clear();
    }

    @Override
    public void draw(class_4587 matrices) {
        if (Tracker.mc.field_1724 == null || Tracker.mc.field_1687 == null || target == null) {
            return;
        }
        UUID targetUUID = target.method_5667();
        Render2DEngine.drawRoundedBlur(matrices, 10.0f, 10.0f, 120.0f, 80.0f, 6.0f, 14.0f, 0.0f, true);
        Render2DEngine.renderItem(matrices, class_1802.field_8463.method_7854(), 15.0f, 15.0f, 1.0f, false);
        Render2DEngine.renderItem(matrices, class_1802.field_8288.method_7854(), 15.0f, 35.0f, 1.0f, false);
        Render2DEngine.renderItem(matrices, class_1802.field_8287.method_7854(), 15.0f, 55.0f, 1.0f, false);
        Render2DEngine.renderItem(matrices, class_1802.field_8301.method_7854(), 15.0f, 75.0f, 1.0f, false);
        ClientMain.fontRenderer.draw(matrices, "Gaps: " + String.valueOf(this.gaps.getOrDefault(targetUUID, 0)), 35.0f, 13.0f, Color.white.getRGB());
        ClientMain.fontRenderer.draw(matrices, "Totems: " + String.valueOf(this.totems.getOrDefault(targetUUID, 0)), 35.0f, 33.0f, Color.white.getRGB());
        ClientMain.fontRenderer.draw(matrices, "Exp: " + String.valueOf(this.exp.getOrDefault(targetUUID, 0)), 35.0f, 53.0f, Color.white.getRGB());
        ClientMain.fontRenderer.draw(matrices, "Crystals: " + String.valueOf(this.crystals.getOrDefault(targetUUID, 0)), 35.0f, 72.0f, Color.white.getRGB());
        this.renderEntityFullBody(matrices, target, mc.method_22683().method_4486() - 900, 160, 30, -20.0f, 180.0f);
    }

    private void renderEntityFullBody(class_4587 matrices, class_1657 entity, int x, int y, int scale, float mouseX, float mouseY) {
        matrices.method_22903();
        matrices.method_46416((float)x, (float)y, 50.0f);
        matrices.method_22905((float)scale, (float)scale, (float)scale);
        Quaternionf xRotation = new Quaternionf().rotateX((float)Math.toRadians(180.0));
        matrices.method_22907(xRotation);
        Quaternionf yRotation = new Quaternionf().rotateY((float)Math.toRadians(mouseY));
        matrices.method_22907(yRotation);
        entity.method_5880(false);
        mc.method_1561().method_3954((class_1297)entity, 0.0, 0.0, 0.0, 0.0f, Utils.getTick(), matrices, (class_4597)mc.method_22940().method_23000(), 0xF000F0);
        entity.method_5880(false);
        matrices.method_22909();
    }

    @EventHandler
    public void onPacket(PacketEvent.Receive e) {
        class_2663 packet;
        class_1297 entity;
        class_2596<?> packet2;
        if (Tracker.mc.field_1724 == null || Tracker.mc.field_1687 == null || target == null) {
            return;
        }
        Class packetClass = e.getPacket().getClass();
        if (e.getPacket() instanceof class_2663) {
            ChatUtils.addChatMessage("Received packet: " + packetClass.getSimpleName() + " status: " + ((class_2663)e.getPacket()).method_11470());
        }
        if ((packet2 = e.getPacket()) instanceof class_2663 && (entity = (packet = (class_2663)packet2).method_11469((class_1937)Tracker.mc.field_1687)) instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            if (entity != Tracker.mc.field_1724) {
                UUID playerUUID = player.method_5667();
                if (packet.method_11470() == 9) {
                    class_1799 mainHand = player.method_6047();
                    class_1799 offHand = player.method_6079();
                    if (mainHand.method_7909() == class_1802.field_8463 || offHand.method_7909() == class_1802.field_8463) {
                        this.gaps.put(playerUUID, this.gaps.getOrDefault(playerUUID, 0) + 1);
                    }
                } else if (packet.method_11470() == 35) {
                    this.totems.put(playerUUID, this.totems.getOrDefault(playerUUID, 0) + 1);
                }
            }
        }
    }

    @EventHandler
    public void onRender(WorldRenderEvent e) {
        if (Tracker.mc.field_1724 == null || Tracker.mc.field_1687 == null) {
            return;
        }
        if (this.mode.getMode().equals("Closest")) {
            target = (class_1657)WorldUtils.findNearestEntity((class_1657)Tracker.mc.field_1724, 3.0f, false);
        }
    }

    @EventHandler
    public void onAttack(AttackEntityEvent e) {
        if (Tracker.mc.field_1724 == null || Tracker.mc.field_1687 == null) {
            return;
        }
        class_1297 entity = e.getTarget();
        if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            if (this.mode.getMode().equals("Attacked")) {
                target = player;
            }
        }
    }

    static {
        loggedPackets = new HashSet();
    }
}
