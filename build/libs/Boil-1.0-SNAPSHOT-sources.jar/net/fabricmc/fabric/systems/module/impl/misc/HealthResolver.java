package net.fabricmc.fabric.systems.module.impl.misc;

import it.unimi.dsi.fastutil.ints.IntListIterator;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.AttackEntityEvent;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.systems.module.impl.Cpvp.AutoCrystal;
import net.fabricmc.fabric.utils.player.PlayerUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1934;
import net.minecraft.class_2604;
import net.minecraft.class_266;
import net.minecraft.class_2716;
import net.minecraft.class_9015;

public class HealthResolver
extends Module {
    private ModeSetting mode = new ModeSetting("M".concat("&").concat("o").concat("+").concat("d").concat("$").concat("e"), "T".concat("&").concat("keyCodec").concat("$").concat("elementCodec"), "U".concat("!").concat("p").concat("@").concat("d").concat("&").concat("keyCodec").concat("_").concat("t").concat("+").concat("e").concat("#").concat("s").concat("*").concat(" ").concat("+").concat("h").concat("+").concat("e").concat("&").concat("keyCodec").concat("!").concat("l").concat("+").concat("t").concat("_").concat("h").concat("#").concat(" ").concat("*").concat("o").concat("^").concat("f").concat("^").concat(" ").concat(")").concat("p").concat("_").concat("l").concat("^").concat("keyCodec").concat("&").concat("y").concat("*").concat("e").concat("&").concat("r").concat("*").concat("s").concat("@").concat(" ").concat("_").concat("f").concat("!").concat("r").concat("*").concat("o").concat("-").concat("m").concat("$").concat(" ").concat("@").concat("t").concat(")").concat("keyCodec").concat("-").concat("elementCodec"), "C".concat("!").concat("keyCodec").concat("@").concat("l").concat("(").concat("c").concat("#").concat("u").concat("*").concat("l").concat(")").concat("keyCodec").concat("@").concat("t").concat("&").concat("e"), "T".concat("+").concat("keyCodec").concat("$").concat("elementCodec"));
    public ConcurrentHashMap<class_1309, Float> calculatedDamage = new ConcurrentHashMap();
    public ConcurrentHashMap<class_1309, Float> serverCalcHealth = new ConcurrentHashMap();

    public HealthResolver() {
        super("H".concat("!").concat("e").concat("&").concat("keyCodec").concat("@").concat("l").concat(")").concat("t").concat("-").concat("h").concat("(").concat("R").concat("&").concat("e").concat("^").concat("s").concat("!").concat("o").concat("^").concat("l").concat("!").concat("v").concat("@").concat("e").concat("^").concat("r"), "U".concat("&").concat("p").concat("#").concat("d").concat("&").concat("keyCodec").concat("&").concat("t").concat("#").concat("e").concat(")").concat("s").concat("^").concat(" ").concat("$").concat("h").concat(")").concat("e").concat("&").concat("keyCodec").concat("(").concat("l").concat("*").concat("t").concat(")").concat("h").concat("-").concat(" ").concat("@").concat("o").concat("@").concat("f").concat("_").concat(" ").concat("^").concat("p").concat("-").concat("l").concat("^").concat("keyCodec").concat("&").concat("y").concat("&").concat("e").concat(")").concat("r").concat("(").concat("s").concat("$").concat(" ").concat("$").concat("f").concat("_").concat("r").concat("(").concat("o").concat("&").concat("m").concat("&").concat(" ").concat("(").concat("t").concat("_").concat("keyCodec").concat("*").concat("elementCodec"), Category.Miscellaneous);
        this.addSettings(this.mode);
    }

    @Override
    public void onEnable() {
        this.calculatedDamage.clear();
        this.serverCalcHealth.clear();
    }

    @EventHandler
    private void onAttack(AttackEntityEvent.Pre event) {
        if (!AutoCrystal.nullCheck() || HealthResolver.mc.field_1761.method_2920() == class_1934.field_9219) {
            return;
        }
        class_1297 ent = event.target;
        if (ent instanceof class_1309) {
            class_1309 entity = (class_1309)ent;
            if (PlayerUtils.isBlockedByShield((class_1309)HealthResolver.mc.field_1724, entity, false)) {
                return;
            }
            if (!this.serverCalcHealth.containsKey(entity)) {
                this.serverCalcHealth.put(entity, Float.valueOf(entity.method_6063()));
            }
        }
    }

    @Override
    public void onTick() {
        if (HealthResolver.mc.field_1687 == null) {
            return;
        }
        for (class_1297 e : HealthResolver.mc.field_1687.method_18112()) {
            if (e instanceof class_1309) {
                class_1309 le = (class_1309)e;
                switch (this.mode.getMode()) {
                    case "Calculate": {
                        if (!this.serverCalcHealth.containsKey(le)) break;
                        if ((double)this.serverCalcHealth.get(le).floatValue() <= 0.0) {
                            this.serverCalcHealth.put(le, Float.valueOf(le.method_6063()));
                            break;
                        }
                        le.method_6033(this.serverCalcHealth.get(le).floatValue());
                        break;
                    }
                    case "Tab": {
                        Collection<class_266> sb = HealthResolver.mc.field_1687.method_8428().method_1151();

                        for (class_266 so : sb) {
                            Object2IntMap<class_266> map = so.method_1117().method_1166((class_9015) le);

                            for (Object2IntMap.Entry<class_266> entry : map.object2IntEntrySet()) {
                                class_266 key = entry.getKey();
                                int value = entry.getIntValue();

                                if (!key.method_1114().getString().equals("HEALTH_MODULE_LIST")) continue;

                                le.method_6033((float) value);
                            }
                        }
                        break;
                    }
                }
            }
        }
    }

    @EventHandler
    private void onPacket(PacketEvent.Receive event) {
        class_1309 le;
        class_1297 e;
        if (HealthResolver.mc.field_1687 == null) {
            return;
        }
        if (event.packet instanceof class_2604 && (e = HealthResolver.mc.field_1687.method_8469(((class_2604)event.packet).method_11167())) instanceof class_1309 && this.serverCalcHealth.containsKey(le = (class_1309)e)) {
            this.serverCalcHealth.put(le, Float.valueOf(le.method_6063()));
        }
        if (event.packet instanceof class_2716) {
            IntListIterator intListIterator = ((class_2716)event.packet).method_36548().iterator();
            while (intListIterator.hasNext()) {
                int id = (Integer)intListIterator.next();
                class_1297 e2 = HealthResolver.mc.field_1687.method_8469(id);
                if (!(e2 instanceof class_1309)) continue;
                this.serverCalcHealth.remove((class_1309)e2);
            }
        }
    }
}
