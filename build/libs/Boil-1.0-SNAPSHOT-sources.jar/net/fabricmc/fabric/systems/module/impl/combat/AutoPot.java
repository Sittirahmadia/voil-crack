package net.fabricmc.fabric.systems.module.impl.combat;

import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.math.TimerUtils;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1657;

public class AutoPot
extends Module {
    TimerUtils timer = new TimerUtils();
    NumberSetting health = new NumberSetting("H".concat("-").concat("e").concat("(").concat("keyCodec").concat("-").concat("l").concat("^").concat("t").concat(")").concat("h"), 1.0, 19.0, 8.0, 1.0, "M".concat("$").concat("i").concat(")").concat("n").concat("!").concat("i").concat("!").concat("m").concat("(").concat("u").concat("_").concat("m").concat("+").concat(" ").concat("*").concat("h").concat("-").concat("e").concat("^").concat("keyCodec").concat("$").concat("l").concat("^").concat("t").concat("_").concat("h").concat("!").concat(" ").concat("^").concat("t").concat("*").concat("o").concat("^").concat(" ").concat("&").concat("u").concat("#").concat("s").concat("^").concat("e").concat("#").concat(" ").concat("#").concat("p").concat("@").concat("o").concat("&").concat("t").concat("+").concat("i").concat("#").concat("o").concat(")").concat("n"));
    NumberSetting delay = new NumberSetting("D".concat("*").concat("e").concat("_").concat("l").concat("&").concat("keyCodec").concat("-").concat("y"), 2.0, 20.0, 10.0, 1.0, "D".concat("$").concat("e").concat("$").concat("l").concat("*").concat("keyCodec").concat("^").concat("y").concat("(").concat(" ").concat("@").concat("elementCodec").concat("@").concat("e").concat("&").concat("f").concat("(").concat("o").concat("+").concat("r").concat("-").concat("e").concat("$").concat(" ").concat("_").concat("u").concat("-").concat("s").concat("_").concat("i").concat("^").concat("n").concat(")").concat("g").concat(")").concat(" ").concat(")").concat("p").concat("$").concat("o").concat("#").concat("t").concat("!").concat("i").concat("_").concat("o").concat("*").concat("n"));
    BooleanSetting autobuff = new BooleanSetting("A".concat(")").concat("u").concat("#").concat("t").concat("$").concat("o").concat("*").concat("B").concat("!").concat("u").concat("@").concat("f").concat("&").concat("f"), false, "A".concat("(").concat("u").concat("^").concat("t").concat("$").concat("o").concat("-").concat("m").concat("@").concat("keyCodec").concat("*").concat("t").concat("#").concat("i").concat("^").concat("c").concat("-").concat("keyCodec").concat("-").concat("l").concat("(").concat("l").concat("!").concat("y").concat("+").concat(" ").concat("!").concat("elementCodec").concat("+").concat("u").concat("^").concat("f").concat("&").concat("f").concat("^").concat(" ").concat("&").concat("w").concat("#").concat("i").concat("^").concat("t").concat("^").concat("h").concat("(").concat(" ").concat("@").concat("p").concat("$").concat("o").concat("+").concat("t").concat("+").concat("i").concat("#").concat("o").concat("^").concat("n"));
    BooleanSetting spoof = new BooleanSetting("S".concat("!").concat("p").concat("_").concat("o").concat("+").concat("o").concat("&").concat("f").concat("*").concat(" ").concat(")").concat("S").concat("(").concat("l").concat("#").concat("o").concat("^").concat("t"), false, "D".concat("^").concat("o").concat("-").concat("e").concat("-").concat("s").concat("!").concat("n").concat("!").concat("t").concat("&").concat(" ").concat("+").concat("s").concat("@").concat("w").concat("_").concat("i").concat("$").concat("t").concat("^").concat("c").concat("!").concat("h").concat("$").concat(" ").concat("(").concat("t").concat("-").concat("o").concat("!").concat(" ").concat("-").concat("p").concat("_").concat("o").concat("_").concat("t").concat("#").concat("i").concat("#").concat("o").concat("^").concat("n").concat("!").concat(" ").concat(")").concat("s").concat("-").concat("l").concat("$").concat("o").concat("(").concat("t").concat("@").concat(" ").concat("$").concat("w").concat("$").concat("h").concat("*").concat("e").concat("*").concat("n").concat("*").concat(" ").concat("#").concat("t").concat("+").concat("h").concat("_").concat("r").concat(")").concat("o").concat("$").concat("w").concat("+").concat("i").concat(")").concat("n").concat("(").concat("g"));
    ModeSetting rotations = new ModeSetting("R".concat("*").concat("o").concat("-").concat("t").concat("@").concat("keyCodec").concat("_").concat("t").concat("@").concat("i").concat("&").concat("o").concat("@").concat("n").concat("-").concat("s"), "L".concat("_").concat("e").concat("+").concat("g").concat("&").concat("i").concat("$").concat("t"), "R".concat("_").concat("o").concat("(").concat("t").concat("$").concat("keyCodec").concat("@").concat("t").concat("@").concat("i").concat("@").concat("o").concat("+").concat("n").concat("-").concat("s").concat("!").concat(" ").concat("!").concat("m").concat("#").concat("o").concat("*").concat("d").concat("+").concat("e"), "S".concat("@").concat("i").concat("@").concat("l").concat("-").concat("e").concat("@").concat("n").concat("*").concat("t"), "L".concat("*").concat("e").concat("^").concat("g").concat("-").concat("i").concat("&").concat("t"));
    Float prevPitch;
    int potSlot = -1;
    int prevSlot;
    int ticksAfterPotion = 0;

    public AutoPot() {
        super("A".concat("+").concat("u").concat("(").concat("t").concat("+").concat("o").concat("-").concat("P").concat("!").concat("o").concat("_").concat("t"), "A".concat("&").concat("u").concat("+").concat("t").concat(")").concat("o").concat(")").concat("m").concat("+").concat("keyCodec").concat(")").concat("t").concat("@").concat("i").concat("-").concat("c").concat("@").concat("keyCodec").concat("(").concat("l").concat("(").concat("l").concat("#").concat("y").concat("_").concat(" ").concat("*").concat("t").concat("!").concat("h").concat("&").concat("r").concat("*").concat("o").concat("*").concat("w").concat("_").concat("s").concat("^").concat(" ").concat("^").concat("p").concat("-").concat("o").concat("-").concat("t").concat("#").concat("i").concat("@").concat("o").concat("+").concat("n"), Category.Combat);
        this.addSettings(this.health, this.delay, this.autobuff, this.spoof, this.rotations);
    }

    @Override
    public void onTick() {
        super.onTick();
        assert (AutoPot.mc.field_1724 != null);
        if (AutoPot.mc.field_1724.method_6032() <= this.health.getFloatValue() && this.ticksAfterPotion == 0 && this.findInstantHealthPotion()) {
            this.usePotion();
        }
        if (this.autobuff.isEnabled() && this.ticksAfterPotion == 0) {
            if (!AutoPot.mc.field_1724.method_6059(class_1294.field_5924) && this.findBuffPotion((class_1294)class_1294.field_5924)) {
                this.usePotion();
            } else if (!AutoPot.mc.field_1724.method_6059(class_1294.field_5910) && this.findBuffPotion((class_1294)class_1294.field_5910)) {
                this.usePotion();
            } else if (!AutoPot.mc.field_1724.method_6059(class_1294.field_5904) && this.findBuffPotion((class_1294)class_1294.field_5904)) {
                this.usePotion();
            } else if (!AutoPot.mc.field_1724.method_6059(class_1294.field_5918) && this.findBuffPotion((class_1294)class_1294.field_5918)) {
                this.usePotion();
            }
        }
        if (this.ticksAfterPotion > 0) {
            ++this.ticksAfterPotion;
            if ((double)this.ticksAfterPotion > this.delay.getValue()) {
                this.ticksAfterPotion = 0;
            }
        }
    }

    public boolean findInstantHealthPotion() {
        Integer slot = InventoryUtils.findPotion(0, 9, (class_1294)class_1294.field_5915);
        if (slot != null) {
            this.potSlot = slot;
            return true;
        }
        return false;
    }

    public boolean findBuffPotion(class_1294 effect) {
        Integer slot = InventoryUtils.findPotion(0, 9, effect);
        if (slot != null) {
            this.potSlot = slot;
            return true;
        }
        return false;
    }

    private void usePotion() {
        this.prevPitch = Float.valueOf(AutoPot.mc.field_1724.method_36455());
        this.prevSlot = AutoPot.mc.field_1724.method_31548().field_7545;
        AutoPot.mc.field_1724.method_36457(90.0f);
        AutoPot.mc.field_1724.method_31548().field_7545 = this.potSlot;
        assert (AutoPot.mc.field_1761 != null);
        AutoPot.mc.field_1761.method_2919((class_1657)AutoPot.mc.field_1724, class_1268.field_5808);
        ++this.ticksAfterPotion;
        if (this.spoof.isEnabled()) {
            AutoPot.mc.field_1724.method_31548().field_7545 = this.prevSlot;
        } else if (this.timer.hasReached(1000.0)) {
            AutoPot.mc.field_1724.method_31548().field_7545 = this.potSlot;
            this.timer.reset();
        }
        if (this.rotations.getMode().equals("Silent")) {
            AutoPot.mc.field_1724.method_36457(this.prevPitch.floatValue());
        } else if (this.rotations.getMode().equals("Legit") && this.timer.hasReached(1000.0)) {
            AutoPot.mc.field_1724.method_36457(this.prevPitch.floatValue());
            this.timer.reset();
        }
    }
}
