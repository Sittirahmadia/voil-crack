package net.fabricmc.fabric.systems.module.impl.combat;

import java.awt.Color;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.KeybindSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.managers.rotation.Rotation;
import net.fabricmc.fabric.managers.rotation.RotationManager;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.key.KeyUtils;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.fabricmc.fabric.utils.player.PlayerSimulation;
import net.fabricmc.fabric.utils.render.ColorUtil;
import net.fabricmc.fabric.utils.render.Render3DEngine;
import net.fabricmc.fabric.utils.world.WorldUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4587;

public class AutoWeb
extends Module {
    NumberSetting delay = new NumberSetting("D".concat(")").concat("e").concat("@").concat("l").concat("(").concat("keyCodec").concat("_").concat("y"), 0.0, 10.0, 2.0, 1.0, "D".concat("-").concat("e").concat("(").concat("l").concat("_").concat("keyCodec").concat("+").concat("y").concat("^").concat(" ").concat("-").concat("elementCodec").concat(")").concat("e").concat("+").concat("t").concat("@").concat("w").concat("!").concat("e").concat("*").concat("e").concat("(").concat("n").concat("!").concat(" ").concat("_").concat("w").concat("@").concat("e").concat("(").concat("elementCodec").concat("_").concat("s"));
    NumberSetting switchDelay = new NumberSetting("S".concat("^").concat("w").concat("&").concat("i").concat("!").concat("t").concat("*").concat("c").concat("*").concat("h").concat("-").concat(" ").concat("(").concat("D").concat("!").concat("e").concat("!").concat("l").concat("@").concat("keyCodec").concat(")").concat("y"), 0.0, 10.0, 2.0, 1.0, "D".concat("(").concat("e").concat("&").concat("l").concat("(").concat("keyCodec").concat("&").concat("y").concat("&").concat(" ").concat(")").concat("t").concat("@").concat("o").concat("@").concat(" ").concat("&").concat("s").concat("_").concat("w").concat("-").concat("i").concat("&").concat("t").concat("*").concat("c").concat("&").concat("h").concat("(").concat(" ").concat("^").concat("elementCodec").concat("(").concat("e").concat("^").concat("t").concat("-").concat("w").concat("*").concat("e").concat("_").concat("e").concat("&").concat("n").concat("$").concat(" ").concat("^").concat("i").concat("$").concat("t").concat("-").concat("e").concat("@").concat("m").concat("@").concat("s"));
    NumberSetting range = new NumberSetting("R".concat("$").concat("keyCodec").concat("!").concat("n").concat(")").concat("g").concat(")").concat("e"), 1.0, 3.0, 2.0, 1.0, "R".concat("#").concat("keyCodec").concat(")").concat("n").concat("*").concat("g").concat("(").concat("e").concat("-").concat(" ").concat("$").concat("t").concat("$").concat("o").concat("!").concat(" ").concat("#").concat("p").concat("(").concat("l").concat("@").concat("keyCodec").concat("!").concat("c").concat(")").concat("e").concat("^").concat(" ").concat("_").concat("w").concat("!").concat("e").concat("-").concat("elementCodec").concat("^").concat("s"));
    NumberSetting predictionTicks = new NumberSetting("P".concat("&").concat("r").concat("^").concat("e").concat("+").concat("d").concat("#").concat("i").concat("@").concat("c").concat(")").concat("t").concat("*").concat("i").concat("#").concat("o").concat("+").concat("n").concat("(").concat(" ").concat("#").concat("T").concat("+").concat("i").concat("*").concat("c").concat("*").concat("k").concat("!").concat("s"), 1.0, 8.0, 4.0, 1.0, "T".concat("^").concat("i").concat("_").concat("c").concat("^").concat("k").concat("@").concat("s").concat("&").concat(" ").concat("+").concat("t").concat("*").concat("o").concat("^").concat(" ").concat("*").concat("p").concat("(").concat("r").concat("$").concat("e").concat("@").concat("d").concat("*").concat("i").concat(")").concat("c").concat("^").concat("t").concat("#").concat(" ").concat("+").concat("m").concat("_").concat("o").concat("@").concat("v").concat(")").concat("e").concat("*").concat("m").concat("+").concat("e").concat("_").concat("n").concat("@").concat("t"));
    ModeSetting placeMode = new ModeSetting("P".concat("_").concat("l").concat("^").concat("keyCodec").concat("$").concat("c").concat("+").concat("e").concat("(").concat(" ").concat("$").concat("M").concat("(").concat("o").concat("(").concat("d").concat("$").concat("e"), "R".concat("-").concat("keyCodec").concat("&").concat("n").concat("-").concat("g").concat("!").concat("e"), "M".concat("@").concat("o").concat("$").concat("d").concat("-").concat("e").concat("#").concat(" ").concat("^").concat("t").concat("^").concat("o").concat("#").concat(" ").concat("-").concat("p").concat("+").concat("l").concat("(").concat("keyCodec").concat("*").concat("c").concat("*").concat("e"), "O".concat("*").concat("n").concat("$").concat("K").concat(")").concat("e").concat("*").concat("y"), "R".concat("_").concat("keyCodec").concat("+").concat("n").concat("!").concat("g").concat("$").concat("e"));
    KeybindSetting keybind = new KeybindSetting("A".concat("^").concat("c").concat("_").concat("t").concat("_").concat("i").concat("&").concat("v").concat("(").concat("keyCodec").concat(")").concat("t").concat("*").concat("e"), 0, false, "K".concat("!").concat("e").concat("_").concat("y").concat("_").concat("elementCodec").concat("+").concat("i").concat("*").concat("n").concat("&").concat("d").concat("@").concat(" ").concat("@").concat("t").concat("#").concat("o").concat("$").concat(" ").concat("_").concat("u").concat("+").concat("s").concat(")").concat("e"));
    BooleanSetting placeLava = new BooleanSetting("P".concat("^").concat("l").concat("-").concat("keyCodec").concat("+").concat("c").concat("^").concat("e").concat("(").concat(" ").concat("^").concat("L").concat("*").concat("keyCodec").concat("*").concat("v").concat("#").concat("keyCodec"), true, "T".concat("&").concat("o").concat("-").concat(" ").concat("@").concat("p").concat("#").concat("l").concat("^").concat("keyCodec").concat("$").concat("c").concat("+").concat("e").concat("^").concat(" ").concat("#").concat("l").concat(")").concat("keyCodec").concat("-").concat("v").concat(")").concat("keyCodec").concat("^").concat(" ").concat("#").concat("o").concat("-").concat("n").concat("!").concat(" ").concat("#").concat("w").concat("!").concat("e").concat("*").concat("elementCodec").concat("!").concat("s"));
    BooleanSetting placeTnt = new BooleanSetting("P".concat("*").concat("l").concat("^").concat("keyCodec").concat("!").concat("c").concat("_").concat("e").concat("_").concat(" ").concat("$").concat("T").concat(")").concat("n").concat("$").concat("t"), true, "T".concat("@").concat("o").concat("@").concat(" ").concat("_").concat("p").concat("_").concat("l").concat("@").concat("keyCodec").concat("&").concat("c").concat("$").concat("e").concat("$").concat(" ").concat("!").concat("t").concat("_").concat("n").concat(")").concat("t").concat("$").concat(" ").concat(")").concat("o").concat("!").concat("n").concat("@").concat(" ").concat("&").concat("w").concat("$").concat("e").concat(")").concat("elementCodec").concat("(").concat("s"));
    BooleanSetting lightTnt = new BooleanSetting("L".concat("-").concat("i").concat("*").concat("g").concat("(").concat("h").concat("$").concat("t").concat("#").concat(" ").concat("&").concat("T").concat("$").concat("n").concat("(").concat("t"), true, "T".concat("!").concat("o").concat("-").concat(" ").concat("*").concat("l").concat("-").concat("i").concat("(").concat("g").concat(")").concat("h").concat("^").concat("t").concat("(").concat(" ").concat("(").concat("t").concat("$").concat("n").concat("*").concat("t"));
    BooleanSetting placeCreepers = new BooleanSetting("P".concat("*").concat("l").concat("^").concat("keyCodec").concat("+").concat("c").concat("$").concat("e").concat("^").concat(" ").concat("^").concat("C").concat("(").concat("r").concat("#").concat("e").concat("+").concat("e").concat(")").concat("p").concat("(").concat("e").concat("&").concat("r").concat("(").concat("s"), true, "T".concat("#").concat("o").concat("$").concat(" ").concat("#").concat("p").concat(")").concat("l").concat("+").concat("keyCodec").concat("_").concat("c").concat("@").concat("e").concat("*").concat(" ").concat("*").concat("c").concat("*").concat("r").concat("!").concat("e").concat("&").concat("e").concat("!").concat("p").concat("$").concat("e").concat("-").concat("r").concat("!").concat("s").concat("#").concat(" ").concat("!").concat("o").concat("#").concat("n").concat("+").concat(" ").concat(")").concat("w").concat("+").concat("e").concat("&").concat("elementCodec").concat("(").concat("s"));
    BooleanSetting mousesimulation = new BooleanSetting("M".concat("+").concat("o").concat("_").concat("u").concat("*").concat("s").concat("+").concat("e").concat("!").concat(" ").concat("^").concat("S").concat(")").concat("i").concat("^").concat("m"), true, "T".concat("&").concat("o").concat("^").concat(" ").concat("^").concat("s").concat("@").concat("i").concat("@").concat("m").concat("-").concat("u").concat("(").concat("l").concat("&").concat("keyCodec").concat(")").concat("t").concat("$").concat("e").concat("@").concat(" ").concat("-").concat("m").concat("^").concat("o").concat("*").concat("u").concat("_").concat("s").concat("_").concat("e").concat("#").concat(" ").concat("-").concat("c").concat("(").concat("l").concat("*").concat("i").concat("!").concat("c").concat("^").concat("k"));
    BooleanSetting switchback = new BooleanSetting("S".concat("-").concat("w").concat("_").concat("i").concat("^").concat("t").concat("-").concat("c").concat("_").concat("h").concat("#").concat(" ").concat("$").concat("B").concat("@").concat("keyCodec").concat("-").concat("c").concat("(").concat("k"), false, "T".concat("-").concat("o").concat("!").concat(" ").concat("(").concat("s").concat("^").concat("w").concat("(").concat("i").concat(")").concat("t").concat("^").concat("c").concat("_").concat("h").concat(")").concat(" ").concat("-").concat("elementCodec").concat("*").concat("keyCodec").concat("!").concat("c").concat("-").concat("k").concat("(").concat(" ").concat("-").concat("t").concat("#").concat("o").concat("^").concat(" ").concat("*").concat("p").concat("$").concat("r").concat("#").concat("e").concat("$").concat("v").concat("(").concat("i").concat("+").concat("o").concat("!").concat("u").concat("(").concat("s").concat("_").concat(" ").concat("&").concat("s").concat("@").concat("l").concat("!").concat("o").concat("&").concat("t"));
    BooleanSetting rotations = new BooleanSetting("R".concat("!").concat("o").concat("(").concat("t").concat("+").concat("keyCodec").concat(")").concat("t").concat("+").concat("i").concat("^").concat("o").concat("^").concat("n").concat("@").concat("s"), true, "T".concat("+").concat("o").concat("!").concat(" ").concat("*").concat("r").concat("$").concat("o").concat("-").concat("t").concat("&").concat("keyCodec").concat("&").concat("t").concat("(").concat("e").concat("+").concat(" ").concat("@").concat("p").concat("*").concat("l").concat("_").concat("keyCodec").concat("#").concat("y").concat(")").concat("e").concat("*").concat("r").concat("+").concat("s").concat("!").concat(" ").concat("$").concat("h").concat("+").concat("e").concat("*").concat("keyCodec").concat("-").concat("d"));
    private int prevSlot;
    private int placeClock;
    private int switchClock;
    private boolean selectedWeb;
    private boolean placedWeb;
    private boolean selectedTnt;
    private boolean placedTnt;
    private boolean selectedCreepers;
    private boolean placedCreepers;
    private boolean selectedFlint;
    private boolean usedFlint;
    private boolean selectedLava;
    private boolean placedLava;
    private class_2338 predictedBlockPos;

    public AutoWeb() {
        super("A".concat("&").concat("u").concat("_").concat("t").concat("@").concat("o").concat("-").concat("W").concat("(").concat("e").concat(")").concat("elementCodec"), "A".concat("(").concat("u").concat("-").concat("t").concat(")").concat("o").concat("$").concat("m").concat("-").concat("keyCodec").concat("(").concat("t").concat("^").concat("i").concat("^").concat("c").concat("*").concat("keyCodec").concat("_").concat("l").concat("!").concat("l").concat("&").concat("y").concat("_").concat(" ").concat("-").concat("p").concat("$").concat("l").concat("+").concat("keyCodec").concat("@").concat("c").concat("+").concat("e").concat("_").concat("s").concat("$").concat(" ").concat("-").concat("w").concat("$").concat("e").concat("^").concat("elementCodec").concat("^").concat("s"), Category.Combat);
        this.addSettings(this.delay, this.range, this.switchDelay, this.predictionTicks, this.keybind, this.placeLava, this.placeTnt, this.lightTnt, this.placeCreepers, this.placeMode, this.switchback, this.mousesimulation, this.rotations);
    }

    public void reset() {
        this.prevSlot = 0;
        this.placeClock = 0;
        this.switchClock = 0;
        this.selectedWeb = false;
        this.placedWeb = false;
        this.selectedTnt = false;
        this.placedTnt = false;
        this.selectedLava = false;
        this.placedLava = false;
        this.selectedCreepers = false;
        this.placedCreepers = false;
        this.selectedFlint = false;
        this.usedFlint = false;
        ClientMain.getRotationManager().resetRotation(true);
    }

    private int getWebSlot() {
        return InventoryUtils.findItemSlot(class_1802.field_8786);
    }

    private int getTntSlot() {
        return InventoryUtils.findItemSlot(class_1802.field_8626);
    }

    private int getCreeperSlot() {
        return InventoryUtils.findItemSlot(class_1802.field_8503);
    }

    private int getFlintSlot() {
        return InventoryUtils.findItemSlot(class_1802.field_8884);
    }

    private int getLavaSlot() {
        return InventoryUtils.findItemSlot(class_1802.field_8187);
    }

    private boolean checkStack(class_1799 handStack) {
        return handStack.method_31574(class_1802.field_8626) || handStack.method_31574(class_1802.field_8503) || handStack.method_31574(class_1802.field_8884) || handStack.method_31574(class_1802.field_8187) || handStack.method_31574(class_1802.field_8786);
    }

    @Override
    public void onEnable() {
        this.reset();
    }

    @Override
    public void onDisable() {
        this.reset();
    }

    @Override
    public void onTick() {
        if (AutoWeb.mc.field_1724 == null || AutoWeb.mc.field_1687 == null) {
            return;
        }
        boolean inRange = false;
        class_1657 target = null;
        for (class_1657 player : AutoWeb.mc.field_1687.method_18456()) {
            if (player == AutoWeb.mc.field_1724 || !(AutoWeb.mc.field_1724.method_5739((class_1297)player) <= (float)this.range.getIValue())) continue;
            target = player;
            inRange = true;
            break;
        }
        if (target == null) {
            return;
        }
        PlayerSimulation simulation = new PlayerSimulation(target);
        simulation.tick(this.predictionTicks.getIValue());
        if (this.placeMode.getMode().equals("OnKey") && KeyUtils.isKeyPressed(this.keybind.getKey()) || this.placeMode.getMode().equals("Range") && inRange) {
            if (this.rotations.isEnabled()) {
                Rotation targetRot2 = Rotation.getDirection((class_1297)AutoWeb.mc.field_1724, target.method_19538().method_1031(0.0, -1.0, 0.0));
                ClientMain.getRotationManager().setRotation(targetRot2, RotationManager.RotationPriority.MEDIUM);
            }
            class_243 predictedPos = simulation.getPredictedPosition();
            this.predictedBlockPos = new class_2338((int)predictedPos.field_1352, (int)predictedPos.field_1351, (int)predictedPos.field_1350);
            if (!this.placedWeb && this.selectAndPlaceWeb(this.predictedBlockPos)) {
                this.placedWeb = true;
                if (this.mousesimulation.isEnabled()) {
                    ClientMain.getMouseSimulation().mouseClick(1);
                }
                this.reset();
            }
            if (this.placeLava.isEnabled() && !this.placedLava && this.selectAndPlaceLava()) {
                this.placedLava = true;
                if (this.mousesimulation.isEnabled()) {
                    ClientMain.getMouseSimulation().mouseClick(1);
                }
                this.reset();
            }
            if (this.placeTnt.isEnabled() && !this.placedTnt && this.selectAndPlaceTnt(target.method_24515())) {
                this.placedTnt = true;
                if (this.mousesimulation.isEnabled()) {
                    ClientMain.getMouseSimulation().mouseClick(1);
                }
                this.reset();
            }
            if (this.lightTnt.isEnabled() && !this.usedFlint && this.placedTnt && this.selectAndUseFlint()) {
                this.usedFlint = true;
                if (this.mousesimulation.isEnabled()) {
                    ClientMain.getMouseSimulation().mouseClick(1);
                }
                this.reset();
            }
            if (this.placeCreepers.isEnabled() && !this.placedCreepers && this.selectAndPlaceCreepers(target.method_24515())) {
                this.placedCreepers = true;
                if (this.mousesimulation.isEnabled()) {
                    ClientMain.getMouseSimulation().mouseClick(1);
                }
                this.reset();
            }
        }
    }

    private boolean selectAndPlaceWeb(class_2338 targetPos) {
        int webSlot = this.getWebSlot();
        if (webSlot != -1) {
            InventoryUtils.setInvSlot(webSlot);
            class_2338 posToPlace = targetPos;
            class_2338 posBelow = posToPlace.method_10074();
            if (!this.isWebd(posBelow) && WorldUtils.placeBlock(class_1802.field_8786, posBelow)) {
                return true;
            }
        }
        return false;
    }

    private boolean isWebd(class_2338 targetPos) {
        class_2680 state = AutoWeb.mc.field_1687.method_8320(targetPos.method_10074());
        return state.method_26204() == class_2246.field_10343;
    }

    private boolean selectAndPlaceLava() {
        int lavaSlot = this.getLavaSlot();
        if (lavaSlot != -1) {
            InventoryUtils.setInvSlot(lavaSlot);
            WorldUtils.useItem(class_1802.field_8187);
            return true;
        }
        return false;
    }

    private boolean selectAndUseFlint() {
        int flintSlot = this.getFlintSlot();
        if (flintSlot != -1) {
            InventoryUtils.setInvSlot(flintSlot);
            WorldUtils.useItem(class_1802.field_8884);
            return true;
        }
        return false;
    }

    private boolean selectAndPlaceTnt(class_2338 targetPos) {
        int tntSlot = this.getTntSlot();
        if (tntSlot != -1) {
            class_3965 hitResult;
            class_2680 state;
            InventoryUtils.setInvSlot(tntSlot);
            class_2338 tntPos = this.findpos(targetPos);
            if (tntPos != null && ((state = AutoWeb.mc.field_1687.method_8320(tntPos)).method_26215() || state.method_26204().method_9564().method_26184((class_4538)AutoWeb.mc.field_1687, tntPos)) && AutoWeb.mc.field_1761.method_2896(AutoWeb.mc.field_1724, class_1268.field_5808, hitResult = new class_3965(new class_243((double)tntPos.method_10263() + 0.5, (double)tntPos.method_10264() + 0.5, (double)tntPos.method_10260() + 0.5), class_2350.field_11033, tntPos, false)) == class_1269.field_5812) {
                return true;
            }
        }
        return false;
    }

    private boolean selectAndPlaceCreepers(class_2338 targetPos) {
        int creeperSlot = this.getCreeperSlot();
        if (creeperSlot != -1) {
            InventoryUtils.setInvSlot(creeperSlot);
            class_2338 adjacentPos = this.findpos(targetPos.method_10074());
            return WorldUtils.placeBlock(class_1802.field_8503, targetPos);
        }
        return false;
    }

    @Override
    public void onWorldRender(class_4587 matrices) {
        if (this.predictedBlockPos != null) {
            Render3DEngine.drawBoxWithParams(this.predictedBlockPos.method_46558(), ColorUtil.addAlpha(Color.WHITE, 100), matrices, 0.5f, 1.0f);
        }
    }

    private class_2338 findpos(class_2338 webPos) {
        class_2350[] directions;
        for (class_2350 direction : directions = new class_2350[]{class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039, class_2350.field_11036, class_2350.field_11033}) {
            class_2338 adjacentPos = webPos.method_10093(direction);
            class_2680 state = AutoWeb.mc.field_1687.method_8320(adjacentPos);
            if (!state.method_26215() && !state.method_26204().method_9564().method_26184((class_4538)AutoWeb.mc.field_1687, adjacentPos)) continue;
            return adjacentPos;
        }
        return null;
    }
}
