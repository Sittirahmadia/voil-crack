package net.fabricmc.fabric.systems.module.impl.render;

import java.awt.Color;
import net.fabricmc.fabric.gui.setting.ColorPickerSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.Utils;
import net.fabricmc.fabric.utils.render.ColorUtil;
import net.fabricmc.fabric.utils.render.Render2DEngine;
import net.fabricmc.fabric.utils.render.Render3DEngine;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1675;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1771;
import net.minecraft.class_1776;
import net.minecraft.class_1799;
import net.minecraft.class_1823;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4587;

public class Trajectories
extends Module {
    ColorPickerSetting color = new ColorPickerSetting("C".concat("_").concat("o").concat("_").concat("l").concat("_").concat("o").concat("-").concat("r"), new Color(255, 255, 255), "C".concat("-").concat("o").concat("@").concat("l").concat("!").concat("o").concat("&").concat("r").concat("^").concat(" ").concat("-").concat("o").concat("!").concat("f").concat("#").concat(" ").concat("(").concat("t").concat("_").concat("h").concat("&").concat("e").concat("(").concat(" ").concat("!").concat("t").concat("!").concat("r").concat("#").concat("keyCodec").concat("!").concat("j").concat("-").concat("e").concat("&").concat("c").concat("@").concat("t").concat("*").concat("o").concat("@").concat("r").concat("-").concat("y").concat("_").concat(" ").concat("(").concat("l").concat("!").concat("i").concat("@").concat("n").concat("&").concat("e"));

    public Trajectories() {
        super("T".concat(")").concat("r").concat("+").concat("keyCodec").concat("$").concat("j").concat("$").concat("e").concat("+").concat("c").concat("(").concat("t").concat("@").concat("o").concat("(").concat("r").concat("(").concat("i").concat("-").concat("e").concat("$").concat("s"), "D".concat(")").concat("r").concat("&").concat("keyCodec").concat("*").concat("w").concat(")").concat("s").concat("$").concat(" ").concat("-").concat("w").concat(")").concat("h").concat("@").concat("e").concat("!").concat("r").concat("@").concat("e").concat("!").concat(" ").concat("$").concat("t").concat("(").concat("r").concat("_").concat("keyCodec").concat("$").concat("j").concat("&").concat("e").concat("*").concat("c").concat("@").concat("t").concat("$").concat("o").concat(")").concat("r").concat(")").concat("i").concat("-").concat("e").concat("^").concat("s").concat("_").concat(" ").concat(")").concat("g").concat("$").concat("o"), Category.Render);
    }

    @Override
    public void onWorldRender(class_4587 matrices) {
        Color lineColor;
        if (Trajectories.mc.field_1724 == null || Trajectories.mc.field_1687 == null) {
            return;
        }
        boolean hitEntity = false;
        class_243 end = Trajectories.calcTrajectory(Trajectories.mc.field_1724.method_6047().method_7909().method_7854(), Trajectories.mc.field_1724.method_36454(), Trajectories.mc.field_1724.method_36455(), hitEntity);
        class_243 start = Trajectories.mc.field_1724.method_19538();
        Color color = lineColor = hitEntity ? Color.GREEN : this.color.getColor();
        if (end != null) {
            Render3DEngine.drawLine(start, end, lineColor, matrices);
            Render3DEngine.drawBoxWithParams(end, ColorUtil.addAlpha(lineColor, 125), matrices, 0.3f, 0.5f);
        }
    }

    public static class_243 calcTrajectory(class_1799 itemStack, float yaw, float pitch, boolean hitEntity) {
        float drag;
        float gravity;
        float initialSpeed;
        double x = Render2DEngine.interpolate(Trajectories.mc.field_1724.field_6014, Trajectories.mc.field_1724.method_23317(), Utils.getTick());
        double y = Render2DEngine.interpolate(Trajectories.mc.field_1724.field_6036, Trajectories.mc.field_1724.method_23318(), Utils.getTick());
        double z = Render2DEngine.interpolate(Trajectories.mc.field_1724.field_5969, Trajectories.mc.field_1724.method_23321(), Utils.getTick());
        y += (double)Trajectories.mc.field_1724.method_18381(Trajectories.mc.field_1724.method_18376()) - 0.1;
        double motionX = -class_3532.method_15374((float)(yaw * (float)Math.PI / 180.0f)) * class_3532.method_15362((float)(pitch * (float)Math.PI / 180.0f));
        double motionY = -class_3532.method_15374((float)(pitch * (float)Math.PI / 180.0f));
        double motionZ = class_3532.method_15362((float)(yaw * (float)Math.PI / 180.0f)) * class_3532.method_15362((float)(pitch * (float)Math.PI / 180.0f));
        if (itemStack.method_7909() instanceof class_1753) {
            float power = (float)Trajectories.mc.field_1724.method_6048() / 20.0f;
            if ((power = (power * power + power * 2.0f) / 3.0f) > 1.0f) {
                power = 1.0f;
            }
            initialSpeed = power * 3.0f;
            gravity = 0.05f;
            drag = 0.99f;
        } else if (itemStack.method_7909() instanceof class_1764) {
            initialSpeed = 3.15f;
            gravity = 0.05f;
            drag = 0.99f;
        } else if (itemStack.method_7909() instanceof class_1823 || itemStack.method_7909() instanceof class_1771 || itemStack.method_7909() instanceof class_1776) {
            initialSpeed = 1.5f;
            gravity = 0.03f;
            drag = 0.99f;
        } else {
            return null;
        }
        float norm = class_3532.method_15355((float)((float)(motionX * motionX + motionY * motionY + motionZ * motionZ)));
        motionX = motionX / (double)norm * (double)initialSpeed;
        motionY = motionY / (double)norm * (double)initialSpeed;
        motionZ = motionZ / (double)norm * (double)initialSpeed;
        for (int i = 0; i < 300; ++i) {
            class_243 lastPos = new class_243(x, y, z);
            motionX *= (double)drag;
            motionY *= (double)drag;
            class_243 pos = new class_243(x += motionX, y += (motionY -= (double)gravity), z += (motionZ *= (double)drag));
            class_3966 entityHit = class_1675.method_18077((class_1937)Trajectories.mc.field_1687, (class_1297)Trajectories.mc.field_1724, (class_243)lastPos, (class_243)pos, (class_238)Trajectories.mc.field_1724.method_5829().method_1014(1.0), entity -> !entity.method_7325() && entity instanceof class_1309);
            if (entityHit != null) {
                hitEntity = true;
                return entityHit.method_17784();
            }
            class_3965 bhr = Trajectories.mc.field_1687.method_17742(new class_3959(lastPos, pos, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)Trajectories.mc.field_1724));
            if (bhr != null && bhr.method_17783() == class_239.class_240.field_1332) {
                return bhr.method_17784();
            }
            if (y <= -65.0) break;
        }
        return null;
    }
}
