package net.fabricmc.fabric.systems.module.impl.render;

import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.CameraOffsetEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.mixin.IKeyBinding;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.Utils;
import net.fabricmc.fabric.utils.player.FakePlayerEntity;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_304;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.glfw.GLFW;

public class Freecam
extends Module {
    NumberSetting speed = new NumberSetting("S".concat("-").concat("p").concat(")").concat("e").concat("&").concat("e").concat("^").concat("d"), 0.1, 5.0, 1.0, 0.1, "S".concat("+").concat("p").concat("*").concat("e").concat("*").concat("e").concat(")").concat("d").concat("(").concat(" ").concat("-").concat("o").concat("(").concat("f").concat("@").concat(" ").concat("(").concat("f").concat("#").concat("r").concat("$").concat("e").concat("^").concat("e").concat("&").concat("c").concat(")").concat("keyCodec").concat("#").concat("m"));
    BooleanSetting disableonDAMAGE = new BooleanSetting("D".concat("(").concat("i").concat("&").concat("s").concat("@").concat("keyCodec").concat("$").concat("elementCodec").concat("-").concat("l").concat("&").concat("e").concat("*").concat("O").concat("!").concat("n").concat("*").concat("D").concat("(").concat("keyCodec").concat("^").concat("m").concat("^").concat("keyCodec").concat("@").concat("g").concat("$").concat("e"), false, "D".concat("#").concat("i").concat("#").concat("s").concat("^").concat("keyCodec").concat("@").concat("elementCodec").concat("^").concat("l").concat("*").concat("e").concat(")").concat(" ").concat("&").concat("f").concat("^").concat("r").concat(")").concat("e").concat("!").concat("e").concat("*").concat("c").concat("@").concat("keyCodec").concat("+").concat("m").concat("&").concat(" ").concat("_").concat("i").concat("$").concat("f").concat("$").concat(" ").concat("#").concat("y").concat("&").concat("o").concat("+").concat("u").concat("*").concat(" ").concat("^").concat("g").concat("+").concat("e").concat("*").concat("t").concat("-").concat(" ").concat("@").concat("d").concat("&").concat("keyCodec").concat("-").concat("m").concat("!").concat("keyCodec").concat("!").concat("g").concat("*").concat("e").concat("+").concat("d"));
    public class_243 pos;
    public class_243 pos2;
    private FakePlayerEntity fakePlayer;

    public Freecam() {
        super("F".concat("&").concat("r").concat("&").concat("e").concat("-").concat("e").concat("+").concat("c").concat("*").concat("keyCodec").concat("(").concat("m"), "L".concat("*").concat("e").concat("@").concat("t").concat("$").concat("s").concat("+").concat(" ").concat("!").concat("y").concat("$").concat("o").concat("@").concat("u").concat("!").concat("r").concat("!").concat(" ").concat("@").concat("c").concat("$").concat("keyCodec").concat("^").concat("m").concat("_").concat("e").concat("*").concat("r").concat("*").concat("keyCodec").concat("_").concat(" ").concat("^").concat("m").concat("$").concat("o").concat("^").concat("v").concat("&").concat("e").concat("-").concat(" ").concat("$").concat("f").concat("+").concat("r").concat("&").concat("e").concat("&").concat("e").concat("*").concat("l").concat("_").concat("y"), Category.Render);
        this.addSettings(this.speed, this.disableonDAMAGE);
        this.pos = class_243.field_1353;
        this.pos2 = class_243.field_1353;
    }

    @Override
    public void onEnable() {
        this.pos = this.pos2 = Freecam.mc.field_1724.method_33571();
        this.fakePlayer = new FakePlayerEntity((class_1657)Freecam.mc.field_1724, "Voil", 20.0f, false);
        this.fakePlayer.spawn();
    }

    @Override
    public void onDisable() {
        if (this.fakePlayer != null) {
            this.fakePlayer.despawn();
            this.fakePlayer = null;
        }
    }

    @Override
    public void onTick() {
        Freecam.mc.field_1690.field_1894.method_23481(false);
        Freecam.mc.field_1690.field_1881.method_23481(false);
        Freecam.mc.field_1690.field_1913.method_23481(false);
        Freecam.mc.field_1690.field_1849.method_23481(false);
        Freecam.mc.field_1690.field_1903.method_23481(false);
        Freecam.mc.field_1690.field_1832.method_23481(false);
        float f = (float)Math.PI / 180;
        float f2 = (float)Math.PI;
        class_746 clientPlayerEntity = Freecam.mc.field_1724;
        class_243 vec3d = new class_243((double)(-class_3532.method_15374((float)(-Freecam.mc.field_1724.method_36454() * f - f2))), 0.0, (double)(-class_3532.method_15362((float)(-clientPlayerEntity.method_36454() * f - f2))));
        class_243 vec3d2 = new class_243(0.0, 1.0, 0.0);
        class_243 vec3d3 = vec3d2.method_1036(vec3d);
        class_243 vec3d4 = vec3d.method_1036(vec3d2);
        class_243 vec3d5 = class_243.field_1353;
        class_304 keyBinding = Freecam.mc.field_1690.field_1894;
        if (GLFW.glfwGetKey((long)mc.method_22683().method_4490(), (int)((IKeyBinding)keyBinding).getBoundKey().method_1444()) == 1) {
            vec3d5 = vec3d5.method_1019(vec3d);
        }
        class_304 keyBinding2 = Freecam.mc.field_1690.field_1881;
        if (GLFW.glfwGetKey((long)mc.method_22683().method_4490(), (int)((IKeyBinding)keyBinding2).getBoundKey().method_1444()) == 1) {
            vec3d5 = vec3d5.method_1020(vec3d);
        }
        class_304 keyBinding3 = Freecam.mc.field_1690.field_1913;
        if (GLFW.glfwGetKey((long)mc.method_22683().method_4490(), (int)((IKeyBinding)keyBinding3).getBoundKey().method_1444()) == 1) {
            vec3d5 = vec3d5.method_1019(vec3d3);
        }
        class_304 keyBinding4 = Freecam.mc.field_1690.field_1849;
        if (GLFW.glfwGetKey((long)mc.method_22683().method_4490(), (int)((IKeyBinding)keyBinding4).getBoundKey().method_1444()) == 1) {
            vec3d5 = vec3d5.method_1019(vec3d4);
        }
        class_304 keyBinding5 = Freecam.mc.field_1690.field_1903;
        if (GLFW.glfwGetKey((long)mc.method_22683().method_4490(), (int)((IKeyBinding)keyBinding5).getBoundKey().method_1444()) == 1) {
            vec3d5 = vec3d5.method_1031(0.0, (double)this.speed.getFloatValue(), 0.0);
        }
        class_304 keyBinding6 = Freecam.mc.field_1690.field_1832;
        if (GLFW.glfwGetKey((long)mc.method_22683().method_4490(), (int)((IKeyBinding)keyBinding6).getBoundKey().method_1444()) == 1) {
            vec3d5 = vec3d5.method_1031(0.0, (double)(-this.speed.getFloatValue()), 0.0);
        }
        class_304 keyBinding7 = Freecam.mc.field_1690.field_1867;
        vec3d5 = vec3d5.method_1029().method_1021((double)(this.speed.getFloatValue() * (float)(GLFW.glfwGetKey((long)mc.method_22683().method_4490(), (int)((IKeyBinding)keyBinding7).getBoundKey().method_1444()) == 1 ? 2 : 1)));
        this.pos = this.pos2;
        this.pos2 = this.pos2.method_1019(vec3d5);
        if (this.disableonDAMAGE.isEnabled() && Freecam.mc.field_1724.field_6235 > 0) {
            this.toggle();
            return;
        }
    }

    @EventHandler
    public void event(@NotNull CameraOffsetEvent event) {
        float f = Utils.getTick();
        event.setX(class_3532.method_16436((double)f, (double)this.pos.field_1352, (double)this.pos2.field_1352));
        event.setY(class_3532.method_16436((double)f, (double)this.pos.field_1351, (double)this.pos2.field_1351));
        event.setZ(class_3532.method_16436((double)f, (double)this.pos.field_1350, (double)this.pos2.field_1350));
        event.cancel();
    }
}
