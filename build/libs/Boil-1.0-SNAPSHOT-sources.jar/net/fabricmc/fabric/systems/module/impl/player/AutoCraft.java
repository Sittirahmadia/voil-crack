package net.fabricmc.fabric.systems.module.impl.player;

import java.util.List;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_1792;
import net.minecraft.class_1802;

public class AutoCraft
extends Module {
    private final NumberSetting delay = new NumberSetting("D".concat("(").concat("e").concat(")").concat("l").concat("&").concat("keyCodec").concat("+").concat("y"), 1.0, 10.0, 1.0, 1.0, "D".concat("(").concat("e").concat(")").concat("l").concat(")").concat("keyCodec").concat("#").concat("y").concat("+").concat(" ").concat("+").concat("elementCodec").concat("+").concat("e").concat("+").concat("t").concat("!").concat("w").concat("!").concat("e").concat("-").concat("e").concat("$").concat("n").concat("_").concat(" ").concat("(").concat("e").concat("$").concat("keyCodec").concat("#").concat("c").concat("@").concat("h").concat("^").concat(" ").concat("*").concat("c").concat("-").concat("r").concat("$").concat("keyCodec").concat("(").concat("f").concat("^").concat("t"));
    private final BooleanSetting armor = new BooleanSetting("A".concat(")").concat("r").concat("(").concat("m").concat("@").concat("o").concat("_").concat("r"), true, "A".concat("^").concat("u").concat("@").concat("t").concat("#").concat("o").concat("(").concat("m").concat("*").concat("keyCodec").concat("-").concat("t").concat("!").concat("i").concat("_").concat("c").concat("_").concat("keyCodec").concat("(").concat("l").concat("(").concat("l").concat("_").concat("y").concat("+").concat(" ").concat("$").concat("c").concat(")").concat("r").concat("^").concat("keyCodec").concat("@").concat("f").concat("-").concat("t").concat("^").concat(" ").concat("+").concat("keyCodec").concat("@").concat("r").concat("!").concat("m").concat(")").concat("o").concat("*").concat("r"));
    private final BooleanSetting tools = new BooleanSetting("T".concat("#").concat("o").concat("-").concat("o").concat("@").concat("l").concat("(").concat("s"), true, "A".concat("$").concat("u").concat("*").concat("t").concat("^").concat("o").concat("^").concat("m").concat(")").concat("keyCodec").concat("!").concat("t").concat("&").concat("i").concat(")").concat("c").concat("_").concat("keyCodec").concat("$").concat("l").concat("&").concat("l").concat("(").concat("y").concat("_").concat(" ").concat("+").concat("c").concat("!").concat("r").concat("^").concat("keyCodec").concat("(").concat("f").concat("#").concat("t").concat("@").concat(" ").concat("_").concat("t").concat("&").concat("o").concat(")").concat("o").concat("@").concat("l").concat("@").concat("s"));
    private static final List<class_1792> ARMOR_ITEMS = List.of(class_1802.field_8805, class_1802.field_8058, class_1802.field_8348, class_1802.field_8285, class_1802.field_8743, class_1802.field_8523, class_1802.field_8396, class_1802.field_8660);
    private static final List<class_1792> TOOL_ITEMS = List.of(class_1802.field_8377, class_1802.field_8556, class_1802.field_8250, class_1802.field_8802, class_1802.field_8403, class_1802.field_8475, class_1802.field_8699, class_1802.field_8371);

    public AutoCraft() {
        super("A".concat("*").concat("u").concat("#").concat("t").concat("(").concat("o").concat("&").concat("C").concat("+").concat("r").concat("_").concat("keyCodec").concat("$").concat("f").concat("#").concat("t"), "A".concat("_").concat("u").concat("#").concat("t").concat("#").concat("o").concat("&").concat("m").concat("@").concat("keyCodec").concat("_").concat("t").concat("$").concat("i").concat("!").concat("c").concat("@").concat("keyCodec").concat(")").concat("l").concat("&").concat("l").concat("@").concat("y").concat("+").concat(" ").concat("_").concat("c").concat("&").concat("r").concat("*").concat("keyCodec").concat("@").concat("f").concat("#").concat("t").concat("+").concat(" ").concat("-").concat("i").concat("^").concat("t").concat("$").concat("e").concat("(").concat("m").concat("^").concat("s"), Category.Player);
        this.addSettings(this.delay, this.armor, this.tools);
    }
}
