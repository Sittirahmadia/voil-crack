package net.fabricmc.fabric.systems.module.impl.combat;

import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1748;
import net.minecraft.class_1802;
import net.minecraft.class_2244;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class BedMacro
extends Module {
    BooleanSetting swapTotem = new BooleanSetting("S".concat("(").concat("w").concat("_").concat("keyCodec").concat(")").concat("p").concat("-").concat(" ").concat(")").concat("T").concat("-").concat("o").concat("(").concat("t").concat("_").concat("e").concat("_").concat("m"), true, "S".concat("(").concat("w").concat("&").concat("keyCodec").concat("&").concat("p").concat("&").concat(" ").concat("#").concat("t").concat("@").concat("o").concat("@").concat(" ").concat("-").concat("t").concat(")").concat("o").concat("!").concat("t").concat("+").concat("e").concat("-").concat("m").concat("@").concat(" ").concat("@").concat("elementCodec").concat("^").concat("e").concat("+").concat("f").concat("&").concat("o").concat("$").concat("r").concat("-").concat("e").concat("$").concat(" ").concat("_").concat("e").concat("_").concat("x").concat("-").concat("p").concat("-").concat("l").concat("#").concat("o").concat("$").concat("d").concat("!").concat("i").concat("!").concat("n").concat("!").concat("g").concat("_").concat(" ").concat("&").concat("t").concat("#").concat("h").concat("!").concat("e").concat("#").concat(" ").concat("+").concat("elementCodec").concat(")").concat("e").concat("-").concat("d"));
    BooleanSetting autoReplenish = new BooleanSetting("A".concat("-").concat("u").concat(")").concat("t").concat("+").concat("o").concat("^").concat(" ").concat("-").concat("R").concat("*").concat("e").concat("+").concat("p").concat("_").concat("l").concat("$").concat("e").concat("^").concat("n").concat("_").concat("i").concat("$").concat("s").concat("-").concat("h"), true, "A".concat("^").concat("u").concat(")").concat("t").concat(")").concat("o").concat("#").concat(" ").concat("$").concat("g").concat("_").concat("e").concat("+").concat("t").concat(")").concat("s").concat("-").concat(" ").concat("(").concat("elementCodec").concat("&").concat("e").concat("#").concat("d").concat("(").concat(" ").concat("$").concat("f").concat(")").concat("r").concat("&").concat("o").concat("^").concat("m").concat("+").concat(" ").concat("*").concat("i").concat("-").concat("n").concat("-").concat("v").concat("-").concat("e").concat("$").concat("n").concat("*").concat("t").concat("_").concat("o").concat("(").concat("r").concat("#").concat("y"));

    public BedMacro() {
        super("B".concat("#").concat("e").concat("_").concat("d").concat("-").concat("M").concat("*").concat("keyCodec").concat(")").concat("c").concat(")").concat("r").concat("#").concat("o"), "M".concat("*").concat("keyCodec").concat("@").concat("c").concat("@").concat("r").concat("+").concat("o").concat("&").concat(" ").concat("-").concat("f").concat("&").concat("o").concat("^").concat("r").concat("-").concat(" ").concat("_").concat("elementCodec").concat("(").concat("e").concat("(").concat("d"), Category.Combat);
        this.addSettings(this.swapTotem, this.autoReplenish);
    }

    @Override
    public void onTick() {
        class_3965 blockHitResult;
        class_2338 pos;
        class_2680 blockState;
        class_2248 block;
        class_239 hitResult;
        if (BedMacro.mc.field_1765 != null && BedMacro.mc.field_1765.method_17783() == class_239.class_240.field_1332 && (hitResult = BedMacro.mc.field_1765) instanceof class_3965 && (block = (blockState = BedMacro.mc.field_1687.method_8320(pos = (blockHitResult = (class_3965)hitResult).method_17777())).method_26204()) instanceof class_2244) {
            int currentHotbarSlot;
            int bedSlot;
            if (this.swapTotem.isEnabled()) {
                InventoryUtils.swap(class_1802.field_8288);
                BedMacro.mc.field_1761.method_2896(BedMacro.mc.field_1724, class_1268.field_5808, blockHitResult);
                BedMacro.mc.field_1724.method_6104(class_1268.field_5808);
            } else {
                BedMacro.mc.field_1761.method_2896(BedMacro.mc.field_1724, class_1268.field_5808, blockHitResult);
                BedMacro.mc.field_1724.method_6104(class_1268.field_5808);
            }
            if (this.autoReplenish.isEnabled() && !(BedMacro.mc.field_1724.method_6047().method_7909() instanceof class_1748) && (bedSlot = this.findBedInHotbar()) != -1 && bedSlot != (currentHotbarSlot = BedMacro.mc.field_1724.method_31548().field_7545)) {
                BedMacro.mc.field_1724.method_31548().field_7545 = bedSlot;
            }
        }
    }

    private int findBedInHotbar() {
        for (int i = 0; i < 9; ++i) {
            if (!(BedMacro.mc.field_1724.method_31548().method_5438(i).method_7909() instanceof class_1748)) continue;
            return i;
        }
        return -1;
    }
}
