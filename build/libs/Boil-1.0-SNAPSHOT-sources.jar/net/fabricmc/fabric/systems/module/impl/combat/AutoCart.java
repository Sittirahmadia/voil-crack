package net.fabricmc.fabric.systems.module.impl.combat;

import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.packet.PacketUtils;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.fabricmc.fabric.utils.player.PlayerUtils;
import net.fabricmc.fabric.utils.world.BlockUtils;
import net.fabricmc.fabric.utils.world.WorldUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2443;
import net.minecraft.class_2596;
import net.minecraft.class_2846;
import net.minecraft.class_2885;
import net.minecraft.class_3965;

public class AutoCart
extends Module {
    private final NumberSetting placeDelay = new NumberSetting("R".concat("$").concat("keyCodec").concat("*").concat("i").concat("+").concat("l").concat("@").concat(" ").concat("$").concat("d").concat("!").concat("e").concat("&").concat("l").concat("_").concat("keyCodec").concat("*").concat("y"), 0.0, 10.0, 0.0, 1.0, "D".concat("+").concat("e").concat("-").concat("l").concat("(").concat("keyCodec").concat("&").concat("y").concat("(").concat(" ").concat("_").concat("t").concat("!").concat("o").concat(")").concat(" ").concat("+").concat("p").concat("-").concat("l").concat(")").concat("keyCodec").concat("$").concat("c").concat("_").concat("e").concat("!").concat(" ").concat("*").concat("r").concat("&").concat("keyCodec").concat("-").concat("i").concat("(").concat("l"));
    private final NumberSetting switchDelay = new NumberSetting("C".concat("+").concat("keyCodec").concat("#").concat("r").concat("&").concat("t").concat("(").concat(" ").concat("&").concat("d").concat(")").concat("e").concat(")").concat("l").concat("*").concat("keyCodec").concat("$").concat("y"), 0.0, 10.0, 0.0, 1.0, "D".concat("#").concat("e").concat("-").concat("l").concat("*").concat("keyCodec").concat("*").concat("y").concat("^").concat(" ").concat("(").concat("t").concat("*").concat("o").concat(")").concat(" ").concat("*").concat("s").concat("!").concat("w").concat("#").concat("i").concat("!").concat("t").concat("#").concat("c").concat("_").concat("h").concat("+").concat(" ").concat("!").concat("c").concat("&").concat("keyCodec").concat("!").concat("r").concat("#").concat("t"));
    private final NumberSetting bowSwitchBackDelay = new NumberSetting("B".concat("_").concat("o").concat("!").concat("w").concat("^").concat(" ").concat(")").concat("S").concat("_").concat("w").concat("@").concat("i").concat("#").concat("t").concat("_").concat("c").concat(")").concat("h").concat("(").concat(" ").concat("$").concat("B").concat("@").concat("keyCodec").concat("-").concat("c").concat("#").concat("k").concat("+").concat(" ").concat("_").concat("D").concat("_").concat("e").concat("$").concat("l").concat("*").concat("keyCodec").concat("^").concat("y"), 0.0, 10.0, 0.0, 1.0, "D".concat("_").concat("e").concat("#").concat("l").concat("$").concat("keyCodec").concat("-").concat("y").concat("_").concat(" ").concat("+").concat("t").concat("!").concat("o").concat("*").concat(" ").concat("$").concat("s").concat("+").concat("w").concat("*").concat("i").concat("*").concat("t").concat(")").concat("c").concat("+").concat("h").concat("*").concat(" ").concat("$").concat("elementCodec").concat(")").concat("keyCodec").concat("#").concat("c").concat("-").concat("k").concat("(").concat(" ").concat("#").concat("t").concat("_").concat("o").concat("#").concat(" ").concat(")").concat("t").concat(")").concat("h").concat(")").concat("e").concat(")").concat(" ").concat("+").concat("elementCodec").concat("@").concat("o").concat("+").concat("w").concat("*").concat(" ").concat("+").concat("keyCodec").concat("*").concat("f").concat("!").concat("t").concat("@").concat("e").concat("!").concat("r").concat("_").concat(" ").concat("#").concat("p").concat("^").concat("l").concat("@").concat("keyCodec").concat("#").concat("c").concat("&").concat("i").concat("$").concat("n").concat("-").concat("g").concat("+").concat(" ").concat("@").concat("T").concat(")").concat("N").concat("(").concat("T").concat("#").concat(" ").concat("#").concat("c").concat(")").concat("keyCodec").concat("#").concat("r").concat("_").concat("t"));
    private final BooleanSetting switchBackToBow = new BooleanSetting("S".concat(")").concat("w").concat("-").concat("i").concat("$").concat("t").concat("*").concat("c").concat("#").concat("h").concat("(").concat(" ").concat("@").concat("B").concat("!").concat("keyCodec").concat("+").concat("c").concat(")").concat("k").concat("+").concat(" ").concat("(").concat("t").concat("_").concat("o").concat("!").concat(" ").concat("+").concat("B").concat("!").concat("o").concat("&").concat("w"), true, "S".concat("!").concat("w").concat("#").concat("i").concat("*").concat("t").concat("#").concat("c").concat("#").concat("h").concat("-").concat(" ").concat("&").concat("elementCodec").concat("(").concat("keyCodec").concat("@").concat("c").concat("#").concat("k").concat("+").concat(" ").concat(")").concat("t").concat("^").concat("o").concat("@").concat(" ").concat("^").concat("t").concat("-").concat("h").concat("@").concat("e").concat("_").concat(" ").concat("@").concat("elementCodec").concat("^").concat("o").concat("+").concat("w").concat("-").concat(" ").concat("+").concat("keyCodec").concat("#").concat("f").concat("#").concat("t").concat("+").concat("e").concat("#").concat("r").concat("*").concat(" ").concat("_").concat("p").concat("@").concat("l").concat("*").concat("keyCodec").concat("-").concat("c").concat(")").concat("i").concat("$").concat("n").concat("^").concat("g").concat("*").concat(" ").concat("(").concat("T").concat("-").concat("N").concat("_").concat("T").concat(")").concat(" ").concat("-").concat("c").concat(")").concat("keyCodec").concat("@").concat("r").concat("$").concat("t"));
    private final BooleanSetting safeBlocks = new BooleanSetting("S".concat("!").concat("keyCodec").concat(")").concat("f").concat(")").concat("e").concat("@").concat(" ").concat("!").concat("B").concat("@").concat("l").concat("^").concat("o").concat(")").concat("c").concat("-").concat("k"), true, "P".concat("@").concat("l").concat("&").concat("keyCodec").concat("$").concat("c").concat("_").concat("e").concat("^").concat("s").concat("$").concat(" ").concat("&").concat("keyCodec").concat("^").concat(" ").concat("+").concat("elementCodec").concat("+").concat("l").concat("!").concat("o").concat(")").concat("c").concat("^").concat("k").concat("_").concat(" ").concat("^").concat("elementCodec").concat("&").concat("e").concat("_").concat("t").concat("@").concat("w").concat("+").concat("e").concat("*").concat("e").concat("&").concat("n").concat("(").concat(" ").concat("^").concat("y").concat("*").concat("o").concat("#").concat("u").concat("_").concat(" ").concat("&").concat("keyCodec").concat("+").concat("n").concat("&").concat("d").concat("_").concat(" ").concat("(").concat("t").concat("&").concat("h").concat(")").concat("e").concat(")").concat(" ").concat("*").concat("t").concat("-").concat("n").concat(")").concat("t").concat("&").concat(" ").concat("^").concat("c").concat("(").concat("keyCodec").concat("@").concat("r").concat("^").concat("t"));
    private class_243 rotationVec = class_243.field_1353;
    private int savedslot = -1;
    private class_2338 bp;
    private int placeDelayTicks = 0;
    private int switchDelayTicks = 0;
    private int bowSwitchBackTicks = -1;
    private int railDelayTicks = 0;
    private boolean switchRail = false;
    boolean placeBlock = false;

    public AutoCart() {
        super("C".concat("#").concat("keyCodec").concat("*").concat("r").concat("!").concat("t").concat("$").concat("M").concat("!").concat("keyCodec").concat("#").concat("c").concat("@").concat("r").concat("+").concat("o"), "H".concat("+").concat("e").concat("_").concat("l").concat("-").concat("p").concat("#").concat("s").concat("&").concat(" ").concat("*").concat("y").concat("@").concat("o").concat("!").concat("u").concat("!").concat(" ").concat("+").concat("w").concat("#").concat("i").concat("^").concat("t").concat("*").concat("h").concat("(").concat(" ").concat("*").concat("c").concat("#").concat("keyCodec").concat("$").concat("r").concat("^").concat("t").concat("_").concat(" ").concat("#").concat("p").concat("#").concat("v").concat("-").concat("p"), Category.Combat);
        this.addSettings(this.placeDelay, this.switchDelay, this.bowSwitchBackDelay, this.switchBackToBow, this.safeBlocks);
    }

    @EventHandler
    public void onPacketSendPost(PacketEvent.SendPost event) {
        class_2846 action;
        class_2596<?> packet = event.getPacket();
        if (packet instanceof class_2846 && (action = (class_2846)packet).method_12363() == class_2846.class_2847.field_12974 && AutoCart.mc.field_1724.method_6047().method_7909() == class_1802.field_8102) {
            this.bp = WorldUtils.calcTrajectory(AutoCart.mc.field_1724.method_36454());
            if (this.bp != null && PlayerUtils.squaredDistanceFromEyes(this.bp.method_46558()) <= this.getPow(Float.valueOf(6.0f)) && PlayerUtils.squaredDistanceFromEyes(this.bp.method_46558()) > 3.0f && this.hasRail() && InventoryUtils.hasItem(class_1802.field_8069)) {
                this.savedslot = AutoCart.mc.field_1724.method_31548().field_7545;
                int slot = this.getRail();
                if (this.switchRail) {
                    InventoryUtils.setInvSlot(slot);
                }
                PacketUtils.sendSequencedPacket(s -> new class_2885(class_1268.field_5808, new class_3965(new class_243((double)this.bp.method_10263() + 0.5, (double)this.bp.method_10084().method_10264(), (double)this.bp.method_10260() + 0.5), class_2350.field_11036, this.bp, false), s));
                this.rotationVec = this.bp.method_10084().method_46558();
                this.switchRail = false;
                this.railDelayTicks = this.placeDelay.getIValue();
                this.switchDelayTicks = this.switchDelay.getIValue();
            }
        }
    }

    @Override
    public void onTick() {
        class_2338 blockToPlace;
        int cartSlot = InventoryUtils.findItemSlot(class_1802.field_8069);
        if (this.placeDelayTicks > 0) {
            --this.placeDelayTicks;
        }
        if (this.railDelayTicks > 0) {
            --this.railDelayTicks;
        }
        if (this.switchDelayTicks > 0) {
            --this.switchDelayTicks;
        }
        if (this.railDelayTicks == 0) {
            this.switchRail = true;
        }
        if (this.switchDelayTicks == 0 && this.savedslot != -1) {
            InventoryUtils.setInvSlot(cartSlot);
            PacketUtils.sendSequencedPacket(s -> new class_2885(class_1268.field_5808, new class_3965(new class_243((double)this.bp.method_10263() + 0.5, (double)this.bp.method_10084().method_10264() + 0.125, (double)this.bp.method_10260() + 0.5), class_2350.field_11036, this.bp.method_10084(), false), s));
            this.switchDelayTicks = -1;
            this.placeBlock = true;
            if (this.switchBackToBow.isEnabled()) {
                this.bowSwitchBackTicks = this.bowSwitchBackDelay.getIValue();
            }
        }
        if (this.bowSwitchBackTicks > 0) {
            --this.bowSwitchBackTicks;
        } else if (this.bowSwitchBackTicks == 0 && this.switchBackToBow.isEnabled()) {
            InventoryUtils.swap(class_1802.field_8102);
            this.bowSwitchBackTicks = -1;
        }
        if (this.safeBlocks.isEnabled() && this.placeBlock && (blockToPlace = this.getPlacementPosition()) != null) {
            int slot = this.getBlockSlot();
            InventoryUtils.setInvSlot(slot);
            BlockUtils.place(blockToPlace, class_1268.field_5808, slot, true, true);
            this.placeBlock = false;
        }
    }

    private float getPow(Number value) {
        return ((Float)value).floatValue() * ((Float)value).floatValue();
    }

    private boolean hasRail() {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = AutoCart.mc.field_1724.method_31548().method_5438(i);
            if (stack.method_7909() != class_1802.field_8129 && stack.method_7909() != class_1802.field_8848 && stack.method_7909() != class_1802.field_8211 && stack.method_7909() != class_1802.field_8655) continue;
            return true;
        }
        return false;
    }

    private int getRail() {
        class_1661 inv = AutoCart.mc.field_1724.method_31548();
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = inv.method_5438(i);
            if (!this.isRail(stack.method_7909())) continue;
            return i;
        }
        return -1;
    }

    private int getBlockSlot() {
        for (int i = 0; i < 9; ++i) {
            class_1799 item = AutoCart.mc.field_1724.method_31548().method_5438(i);
            if (!(item.method_7909() instanceof class_1747) || this.isRail(item.method_7909())) continue;
            return i;
        }
        return -1;
    }

    private boolean isRail(class_1792 item) {
        return item == class_1802.field_8129 || item == class_1802.field_8848 || item == class_1802.field_8211 || item == class_1802.field_8655;
    }

    private class_2338 getPlacementPosition() {
        class_243 playerPos = AutoCart.mc.field_1724.method_19538();
        float yaw = AutoCart.mc.field_1724.method_36454();
        double rad = Math.toRadians(yaw);
        double directionX = -Math.sin(rad);
        double directionZ = Math.cos(rad);
        class_243 offset = new class_243(directionX, 0.0, directionZ);
        class_2338 blockPos = new class_2338((int)Math.floor(playerPos.field_1352 + offset.field_1352), (int)Math.floor(playerPos.field_1351), (int)Math.floor(playerPos.field_1350 + offset.field_1350));
        if (PlayerUtils.squaredDistanceFromEyes(blockPos.method_46558()) <= this.getPow(Float.valueOf(6.0f)) && !(AutoCart.mc.field_1687.method_8320(blockPos).method_26204() instanceof class_2443)) {
            return blockPos;
        }
        return null;
    }
}
