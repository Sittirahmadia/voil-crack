package net.fabricmc.fabric.systems.module.impl.Cpvp;

import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1831;
import net.minecraft.class_1832;
import net.minecraft.class_1834;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_3966;

public class CrystalOptimizer
extends Module {
    public CrystalOptimizer() {
        super("C".concat("^").concat("r").concat("_").concat("y").concat("@").concat("s").concat("@").concat("t").concat("^").concat("keyCodec").concat("*").concat("l").concat("-").concat("O").concat("&").concat("p").concat("+").concat("t").concat("(").concat("i").concat("(").concat("m").concat("_").concat("i").concat("*").concat("z").concat("$").concat("e").concat("*").concat("r"), "B".concat("+").concat("r").concat(")").concat("e").concat("@").concat("keyCodec").concat("^").concat("k").concat("-").concat("s").concat("+").concat(" ").concat("@").concat("c").concat(")").concat("r").concat(")").concat("y").concat("&").concat("s").concat("*").concat("t").concat("&").concat("keyCodec").concat("-").concat("l").concat("!").concat("s").concat("+").concat(" ").concat("*").concat("c").concat("*").concat("l").concat("*").concat("i").concat("!").concat("e").concat("!").concat("n").concat("*").concat("t").concat("(").concat(" ").concat("#").concat("s").concat("!").concat("i").concat("+").concat("d").concat("-").concat("e"), Category.CrystalPvP);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    private boolean isTool(class_1799 itemStack) {
        if (!(itemStack.method_7909() instanceof class_1831) || itemStack.method_7909() instanceof class_1794) {
            return false;
        }
        class_1832 material = ((class_1831)itemStack.method_7909()).method_8022();
        return material == class_1834.field_8930 || material == class_1834.field_22033;
    }

    @EventHandler
    public void onPacket(PacketEvent.Send e) {
        class_2596<?> packet = e.getPacket();
        if (packet instanceof class_2824) {
            class_2824 interactPacket = (class_2824)packet;
            interactPacket.method_34209(new class_2824.class_5908(){

                public void method_34219(class_1268 hand) {
                }

                public void method_34220(class_1268 hand, class_243 pos) {
                }

                public void method_34218() {
                    class_3966 entityHitResult;
                    class_1297 entity;
                    class_239 hitResult = mc.field_1765;
                    if (hitResult == null) {
                        return;
                    }
                    if (hitResult.method_17783() == class_239.class_240.field_1331 && (entity = (entityHitResult = (class_3966)hitResult).method_17782()) instanceof class_1511) {
                        class_1293 weakness = mc.field_1724.method_6112(class_1294.field_5911);
                        class_1293 strength = mc.field_1724.method_6112(class_1294.field_5910);
                        if (!(weakness == null || strength != null && strength.method_5578() > weakness.method_5578() || CrystalOptimizer.this.isTool(mc.field_1724.method_6047()))) {
                            return;
                        }
                        entity.method_5768();
                        entity.method_31745(class_1297.class_5529.field_26998);
                        entity.method_36209();
                    }
                }
            });
        }
    }
}
