package net.fabricmc.fabric.systems.module.impl.movement;

import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_3872;
import net.minecraft.class_408;
import net.minecraft.class_498;

public class InventoryMove
extends Module {
    BooleanSetting inventory = new BooleanSetting("I".concat("!").concat("n").concat("-").concat("v").concat("@").concat("e").concat("$").concat("n").concat("!").concat("t").concat("#").concat("o").concat("^").concat("r").concat("(").concat("y"), true, "O".concat("^").concat("n").concat("_").concat("l").concat("-").concat("y").concat("&").concat(" ").concat("_").concat("m").concat("&").concat("o").concat("$").concat("v").concat("*").concat("e").concat(")").concat(" ").concat("#").concat("w").concat("^").concat("h").concat("*").concat("e").concat("#").concat("n").concat("$").concat(" ").concat("(").concat("i").concat("+").concat("n").concat("^").concat("v").concat("@").concat("e").concat("^").concat("n").concat("*").concat("t").concat("!").concat("o").concat("*").concat("r").concat("_").concat("y").concat("+").concat(" ").concat("&").concat("i").concat("&").concat("s").concat("^").concat(" ").concat("$").concat("o").concat("^").concat("p").concat("+").concat("e").concat("!").concat("n"));
    BooleanSetting shift = new BooleanSetting("S".concat("(").concat("h").concat(")").concat("i").concat("(").concat("f").concat("!").concat("t"), false, "B".concat("(").concat("e").concat("^").concat(" ").concat("#").concat("keyCodec").concat("+").concat("elementCodec").concat("-").concat("l").concat("!").concat("e").concat("^").concat(" ").concat("(").concat("t").concat("@").concat("o").concat("(").concat(" ").concat("^").concat("s").concat("(").concat("h").concat("!").concat("i").concat("(").concat("f").concat("^").concat("t").concat(")").concat(" ").concat("+").concat("i").concat("$").concat("n").concat("!").concat(" ").concat("$").concat("G").concat("#").concat("U").concat("!").concat("I").concat("-").concat("s"));

    public InventoryMove() {
        super("I".concat("$").concat("n").concat("*").concat("v").concat("&").concat("e").concat("_").concat("n").concat("#").concat("t").concat("!").concat("o").concat("#").concat("r").concat("*").concat("y").concat("!").concat("M").concat("+").concat("o").concat("#").concat("v").concat("-").concat("e"), "L".concat("@").concat("e").concat("^").concat("t").concat("(").concat("s").concat("!").concat(" ").concat("^").concat("y").concat("_").concat("o").concat("+").concat("u").concat("$").concat(" ").concat("-").concat("m").concat("&").concat("o").concat("(").concat("v").concat("+").concat("e").concat("_").concat(" ").concat("+").concat("w").concat("+").concat("h").concat(")").concat("e").concat("*").concat("n").concat("$").concat(" ").concat("$").concat("i").concat("+").concat("n").concat("-").concat("v").concat("^").concat("e").concat("_").concat("n").concat("_").concat("t").concat("-").concat("o").concat("!").concat("r").concat(")").concat("y").concat("@").concat(" ").concat("-").concat("i").concat("$").concat("s").concat("#").concat(" ").concat("#").concat("o").concat("^").concat("p").concat("@").concat("e").concat(")").concat("n"), Category.Movement);
        this.addSettings(this.inventory, this.shift);
    }

    @Override
    public void onTick() {
        if (this.inventory.isEnabled() && InventoryMove.mc.field_1755 != null && !(InventoryMove.mc.field_1755 instanceof class_408) && !(InventoryMove.mc.field_1755 instanceof class_498) && !(InventoryMove.mc.field_1755 instanceof class_3872)) {
            for (class_304 k : new class_304[]{InventoryMove.mc.field_1690.field_1894, InventoryMove.mc.field_1690.field_1881, InventoryMove.mc.field_1690.field_1913, InventoryMove.mc.field_1690.field_1849, InventoryMove.mc.field_1690.field_1903, InventoryMove.mc.field_1690.field_1867}) {
                k.method_23481(class_3675.method_15987((long)mc.method_22683().method_4490(), (int)class_3675.method_15981((String)k.method_1428()).method_1444()));
            }
            if (this.shift.isEnabled()) {
                InventoryMove.mc.field_1690.field_1832.method_23481(class_3675.method_15987((long)mc.method_22683().method_4490(), (int)class_3675.method_15981((String)InventoryMove.mc.field_1690.field_1832.method_1428()).method_1444()));
            }
        }
    }
}
