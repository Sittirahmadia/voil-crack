package net.fabricmc.fabric.systems.module.impl.Cpvp;

import it.unimi.dsi.fastutil.ints.IntListIterator;
import java.util.HashSet;
import java.util.Set;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.EndCrystalExplosionMcPlayerEvent;
import net.fabricmc.fabric.api.astral.events.EntitySpawnEvent;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.KeybindSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.crystal.CrystalUtils;
import net.fabricmc.fabric.utils.key.KeyUtils;
import net.fabricmc.fabric.utils.player.RaycastUtils;
import net.fabricmc.fabric.utils.world.EntityUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1589;
import net.minecraft.class_1621;
import net.minecraft.class_1657;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_1831;
import net.minecraft.class_1832;
import net.minecraft.class_1834;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2716;
import net.minecraft.class_2824;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4587;

public class AutoCrystal
extends Module {
    public NumberSetting placeTicks = new NumberSetting("P".concat("+").concat("l").concat("&").concat("keyCodec").concat("#").concat("c").concat("&").concat("e").concat("^").concat("T").concat("_").concat("i").concat("^").concat("c").concat("-").concat("k").concat("+").concat("s"), 0.0, 10.0, 0.0, 0.1, "D".concat("@").concat("e").concat("@").concat("l").concat("*").concat("keyCodec").concat("+").concat("y").concat("(").concat(" ").concat("_").concat("elementCodec").concat("#").concat("e").concat("!").concat("f").concat("(").concat("o").concat("_").concat("r").concat("@").concat("e").concat("+").concat(" ").concat("_").concat("p").concat("&").concat("l").concat("^").concat("keyCodec").concat("+").concat("c").concat("!").concat("i").concat("^").concat("n").concat("(").concat("g").concat(")").concat(" ").concat("!").concat("c").concat("_").concat("r").concat("!").concat("y").concat("(").concat("s").concat("^").concat("t").concat("(").concat("keyCodec").concat("$").concat("l"));
    public NumberSetting breakTicks = new NumberSetting("B".concat("-").concat("r").concat("@").concat("e").concat("@").concat("keyCodec").concat("@").concat("k").concat(")").concat("T").concat("#").concat("i").concat("(").concat("c").concat("@").concat("k").concat("&").concat("s"), 0.0, 10.0, 0.0, 0.1, "D".concat("+").concat("e").concat("@").concat("l").concat("*").concat("keyCodec").concat("*").concat("y").concat("!").concat(" ").concat("#").concat("elementCodec").concat("@").concat("e").concat("-").concat("f").concat("&").concat("o").concat("$").concat("r").concat("+").concat("e").concat("^").concat(" ").concat("*").concat("elementCodec").concat("&").concat("r").concat("+").concat("e").concat("-").concat("keyCodec").concat("&").concat("k").concat("*").concat("i").concat("-").concat("n").concat("$").concat("g").concat("#").concat(" ").concat("@").concat("c").concat("#").concat("r").concat("#").concat("y").concat("_").concat("s").concat("@").concat("t").concat("!").concat("keyCodec").concat("-").concat("l"));
    private ModeSetting modeSetting = new ModeSetting("M".concat("!").concat("o").concat("+").concat("d").concat("#").concat("e"), "N".concat(")").concat("o").concat("@").concat("r").concat("+").concat("m").concat("&").concat("keyCodec").concat("^").concat("l"), "M".concat("+").concat("o").concat("*").concat("d").concat("+").concat("e").concat("!").concat(" ").concat("*").concat("t").concat("@").concat("o").concat("^").concat(" ").concat("*").concat("u").concat(")").concat("s").concat("$").concat("e"), "B".concat("!").concat("l").concat("#").concat("keyCodec").concat(")").concat("t").concat("^").concat("keyCodec").concat("@").concat("n").concat("+").concat("t"), "N".concat("(").concat("o").concat("+").concat("r").concat("^").concat("m").concat("!").concat("keyCodec").concat("^").concat("l"));
    private final BooleanSetting activeOnRightClick = new BooleanSetting("O".concat("*").concat("n").concat("*").concat(" ").concat("_").concat("k").concat("#").concat("e").concat("^").concat("y"), true, "O".concat("$").concat("n").concat("+").concat("l").concat("#").concat("y").concat("(").concat(" ").concat("!").concat("keyCodec").concat("#").concat("c").concat("#").concat("t").concat("*").concat("i").concat("#").concat("v").concat("#").concat("keyCodec").concat(")").concat("t").concat("$").concat("e").concat("@").concat("s").concat("!").concat(" ").concat("#").concat("o").concat("(").concat("n").concat(")").concat(" ").concat("^").concat("k").concat("_").concat("e").concat("*").concat("y"));
    private final BooleanSetting clickSimulation = new BooleanSetting("C".concat(")").concat("l").concat("+").concat("i").concat("(").concat("c").concat("(").concat("k").concat("@").concat(" ").concat("!").concat("S").concat("!").concat("i").concat("-").concat("m").concat("(").concat("u").concat("!").concat("l").concat(")").concat("keyCodec").concat("&").concat("t").concat("#").concat("i").concat("-").concat("o").concat("-").concat("n"), false, "S".concat("&").concat("i").concat("^").concat("m").concat("^").concat("u").concat("+").concat("l").concat("&").concat("keyCodec").concat("*").concat("t").concat("&").concat("e").concat("*").concat(" ").concat("+").concat("c").concat("(").concat("l").concat("_").concat("i").concat("-").concat("c").concat("*").concat("k").concat("^").concat("s").concat("&").concat(" ").concat(")").concat("w").concat("@").concat("h").concat("_").concat("i").concat("^").concat("l").concat("*").concat("e").concat("&").concat(" ").concat("#").concat("p").concat("-").concat("l").concat("$").concat("keyCodec").concat("*").concat("c").concat("!").concat("i").concat("@").concat("n").concat("!").concat("g").concat("!").concat("/").concat("*").concat("elementCodec").concat("_").concat("r").concat("$").concat("e").concat("$").concat("keyCodec").concat("$").concat("k").concat("!").concat("i").concat("#").concat("n").concat("#").concat("g"));
    private final BooleanSetting hurtTimePredict = new BooleanSetting("D".concat("*").concat("keyCodec").concat("#").concat("m").concat("*").concat("keyCodec").concat("#").concat("g").concat("(").concat("e").concat("&").concat(" ").concat(")").concat("t").concat("^").concat("i").concat("^").concat("c").concat("(").concat("k"), false, "P".concat("&").concat("r").concat("$").concat("e").concat(")").concat("d").concat("-").concat("i").concat("$").concat("c").concat("&").concat("t").concat("$").concat("s").concat("@").concat(" ").concat("+").concat("h").concat(")").concat("u").concat("^").concat("r").concat("&").concat("t").concat("_").concat(" ").concat("@").concat("t").concat("-").concat("i").concat("@").concat("m").concat("+").concat("e").concat(")").concat(" ").concat("#").concat("t").concat("$").concat("o").concat("@").concat(" ").concat("_").concat("d").concat("!").concat("o").concat("_").concat("u").concat("_").concat("elementCodec").concat("^").concat("l").concat("+").concat("e").concat("!").concat(" ").concat("(").concat("t").concat("@").concat("keyCodec").concat("&").concat("p").concat("&").concat(" ").concat("#").concat("t").concat(")").concat("h").concat("-").concat("e").concat("^").concat(" ").concat("*").concat("t").concat("@").concat("keyCodec").concat(")").concat("r").concat("#").concat("g").concat("_").concat("e").concat("$").concat("t"));
    public static final BooleanSetting nobounce = new BooleanSetting("noBounce", true, "Prevents bouncing crystals");
    private final BooleanSetting stopOnKill = new BooleanSetting("S".concat("$").concat("t").concat("@").concat("o").concat("*").concat("p").concat("!").concat("O").concat("!").concat("n").concat("$").concat("K").concat("$").concat("i").concat("@").concat("l").concat("+").concat("l"), true, "S".concat("_").concat("t").concat("(").concat("o").concat("@").concat("p").concat(")").concat("s").concat("$").concat(" ").concat("^").concat("c").concat("^").concat("r").concat("-").concat("y").concat("^").concat("s").concat("+").concat("t").concat("$").concat("keyCodec").concat("*").concat("l").concat("-").concat("l").concat(")").concat("i").concat(")").concat("n").concat("@").concat("g").concat("_").concat(" ").concat("@").concat("i").concat("^").concat("f").concat(")").concat(" ").concat("_").concat("s").concat("@").concat("o").concat("&").concat("m").concat("*").concat("e").concat("-").concat("o").concat("-").concat("n").concat("&").concat("e").concat("(").concat(" ").concat("*").concat("d").concat("^").concat("i").concat("-").concat("e").concat("+").concat("s"));
    private final BooleanSetting antiweakness = new BooleanSetting("A".concat("^").concat("n").concat("&").concat("t").concat("@").concat("i").concat("$").concat("W").concat("*").concat("e").concat("(").concat("keyCodec").concat(")").concat("k").concat("_").concat("n").concat("_").concat("e").concat("&").concat("s").concat("!").concat("s"), false, "P".concat("^").concat("r").concat("@").concat("e").concat(")").concat("v").concat("!").concat("e").concat("#").concat("n").concat("*").concat("t").concat("$").concat("s").concat("_").concat(" ").concat("+").concat("c").concat("#").concat("r").concat("_").concat("y").concat("_").concat("s").concat("&").concat("t").concat("@").concat("keyCodec").concat("@").concat("l").concat("^").concat("s").concat("-").concat(" ").concat("&").concat("n").concat(")").concat("o").concat("(").concat("t").concat("@").concat(" ").concat("#").concat("elementCodec").concat("!").concat("r").concat("+").concat("e").concat("(").concat("keyCodec").concat("-").concat("k").concat("*").concat("i").concat("!").concat("n").concat("$").concat("g").concat("*").concat(" ").concat("_").concat("w").concat("*").concat("h").concat("@").concat("e").concat("+").concat("n").concat("_").concat(" ").concat("*").concat("y").concat("-").concat("o").concat("$").concat("u").concat("#").concat(" ").concat("_").concat("h").concat("-").concat("keyCodec").concat("@").concat("v").concat("^").concat("e").concat("$").concat(" ").concat("$").concat("w").concat("*").concat("e").concat("!").concat("keyCodec").concat("$").concat("k").concat("*").concat("n").concat("(").concat("e").concat("#").concat("s").concat("@").concat("s"));
    private final BooleanSetting sync = new BooleanSetting("S".concat("@").concat("y").concat("-").concat("n").concat("@").concat("c"), false, "S".concat(")").concat("y").concat("*").concat("n").concat("*").concat("c").concat("-").concat(" ").concat("_").concat("c").concat("-").concat("r").concat("#").concat("y").concat("+").concat("s").concat(")").concat("t").concat(")").concat("keyCodec").concat("@").concat("l").concat("*").concat(" ").concat("&").concat("keyCodec").concat("^").concat("c").concat("+").concat("t").concat("!").concat("i").concat("&").concat("o").concat("(").concat("n").concat("@").concat("s").concat("#").concat(" ").concat("@").concat("w").concat("@").concat("i").concat("-").concat("t").concat("$").concat("h").concat(")").concat(" ").concat("(").concat("s").concat("^").concat("e").concat("-").concat("r").concat("(").concat("v").concat("+").concat("e").concat("*").concat("r").concat("^").concat(" ").concat("_").concat("d").concat("^").concat("keyCodec").concat("(").concat("t").concat("*").concat("keyCodec"));
    private final BooleanSetting idPredict = new BooleanSetting("E".concat("+").concat("n").concat("-").concat("t").concat("_").concat("i").concat("-").concat("t").concat("_").concat("y").concat("#").concat(" ").concat("^").concat("I").concat("$").concat("D").concat("+").concat(" ").concat("#").concat("p").concat("^").concat("r").concat("-").concat("e").concat("*").concat("d").concat("(").concat("i").concat("#").concat("c").concat("+").concat("t"), false, "T".concat("#").concat("r").concat("_").concat("i").concat("_").concat("e").concat("&").concat("s").concat("+").concat(" ").concat("^").concat("t").concat("&").concat("o").concat("-").concat(" ").concat("@").concat("p").concat(")").concat("r").concat("#").concat("e").concat("-").concat("d").concat("(").concat("i").concat("@").concat("c").concat("^").concat("t").concat("+").concat(" ").concat(")").concat("e").concat("*").concat("n").concat("&").concat("t").concat("@").concat("i").concat("&").concat("t").concat("+").concat("y").concat("+").concat(" ").concat("&").concat("I").concat("^").concat("D").concat("@").concat(" ").concat("!").concat("elementCodec").concat("^").concat("e").concat("(").concat("f").concat("@").concat("o").concat("^").concat("r").concat("(").concat("e").concat("_").concat(" ").concat("(").concat("p").concat("#").concat("l").concat("$").concat("keyCodec").concat("-").concat("c").concat("&").concat("i").concat("-").concat("n").concat("#").concat("g"));
    private final KeybindSetting activateKey = new KeybindSetting("A".concat("^").concat("c").concat("^").concat("t").concat("$").concat("i").concat("@").concat("v").concat("&").concat("keyCodec").concat("@").concat("t").concat("-").concat("e"), 0, false, "K".concat("#").concat("e").concat(")").concat("y").concat("+").concat(" ").concat("-").concat("t").concat("-").concat("o").concat("(").concat(" ").concat("+").concat("keyCodec").concat("^").concat("c").concat("(").concat("t").concat("*").concat("i").concat("!").concat("v").concat("+").concat("keyCodec").concat("+").concat("t").concat("*").concat("e").concat("#").concat(" ").concat("!").concat("A").concat("_").concat("u").concat("#").concat("t").concat("#").concat("o").concat("^").concat("C").concat("-").concat("r").concat("$").concat("y").concat("$").concat("s").concat("(").concat("t").concat("$").concat("keyCodec").concat("&").concat("l"));
    private double tickTimer;
    private final Set<Integer> serverCrystals = new HashSet<Integer>();
    private int lastEntityId = -1;

    public AutoCrystal() {
        super("A".concat(")").concat("u").concat("$").concat("t").concat("_").concat("o").concat("^").concat("C").concat("@").concat("r").concat("+").concat("y").concat("(").concat("s").concat("*").concat("t").concat("&").concat("keyCodec").concat("!").concat("l"), "A".concat("@").concat("u").concat("^").concat("t").concat("#").concat("o").concat("&").concat("m").concat("+").concat("keyCodec").concat("$").concat("t").concat("+").concat("i").concat("+").concat("c").concat("$").concat("keyCodec").concat("(").concat("l").concat("*").concat("l").concat("!").concat("y").concat("$").concat(" ").concat("(").concat("p").concat("-").concat("l").concat("+").concat("keyCodec").concat("(").concat("c").concat("_").concat("e").concat("@").concat("s").concat("@").concat(" ").concat("$").concat("keyCodec").concat("+").concat("n").concat("^").concat("d").concat("(").concat(" ").concat(")").concat("elementCodec").concat("@").concat("r").concat(")").concat("e").concat("!").concat("keyCodec").concat("^").concat("k").concat("@").concat("s").concat("^").concat(" ").concat("(").concat("c").concat("(").concat("r").concat("#").concat("y").concat("#").concat("s").concat("$").concat("t").concat("$").concat("keyCodec").concat("$").concat("l").concat("$").concat("s"), Category.CrystalPvP);
        this.addSettings(this.modeSetting, this.placeTicks, this.breakTicks, this.activeOnRightClick, this.clickSimulation, this.hurtTimePredict, this.stopOnKill, nobounce, this.antiweakness, this.sync, this.idPredict, this.activateKey);
        this.tickTimer = 0.0;
    }

    public static boolean nullCheck() {
        return AutoCrystal.mc.field_1724 != null && AutoCrystal.mc.field_1687 != null;
    }

    public void placeCrystal() {
        class_243 rotationVec;
        class_243 targetPos;
        class_243 cameraPos;
        class_3965 hit;
        if (this.passedTicks(this.placeTicks.getValue()) && (hit = AutoCrystal.mc.field_1687.method_17742(new class_3959(cameraPos = AutoCrystal.mc.field_1724.method_5836(0.0f), targetPos = cameraPos.method_1019((rotationVec = AutoCrystal.mc.field_1724.method_5828(0.0f)).method_1021(4.5)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)AutoCrystal.mc.field_1724))).method_17783() == class_239.class_240.field_1332 && CrystalUtils.canPlaceCrystalServer(hit.method_17777()) && (class_2246.field_10540 == AutoCrystal.mc.field_1687.method_8320(hit.method_17777()).method_26204() || class_2246.field_9987 == AutoCrystal.mc.field_1687.method_8320(hit.method_17777()).method_26204()) && AutoCrystal.mc.field_1724.method_6047().method_31574(class_1802.field_8301)) {
            class_1269 result;
            if (this.clickSimulation.isEnabled()) {
                ClientMain.getMouseSimulation().mouseClick(1);
            }
            if ((result = AutoCrystal.mc.field_1761.method_2896(AutoCrystal.mc.field_1724, class_1268.field_5808, hit)).method_23665() && result.method_23666()) {
                AutoCrystal.mc.field_1724.method_6104(class_1268.field_5808);
                if (this.idPredict.isEnabled()) {
                    this.predict();
                }
                this.reset();
            }
        }
    }

    public void breakCrystal() {
        if (this.passedTicks(this.breakTicks.getValue())) {
            class_1297 entity;
            int originalSlot = AutoCrystal.mc.field_1724.method_31548().field_7545;
            if (this.antiweakness.isEnabled() && this.hasWeakness() && !this.isSword(AutoCrystal.mc.field_1724.method_6047())) {
                this.switchToSword();
            }
            if (this.idPredict.isEnabled() && this.lastEntityId != -1 && (entity = AutoCrystal.mc.field_1687.method_8469(this.lastEntityId)) instanceof class_1511) {
                class_1511 crystal = (class_1511)entity;
                if (!RaycastUtils.isLookingAt((class_1297)crystal, 3.0, 0.5f)) {
                    return;
                }
                AutoCrystal.mc.field_1761.method_2918((class_1657)AutoCrystal.mc.field_1724, (class_1297)crystal);
                AutoCrystal.mc.field_1724.method_6104(class_1268.field_5808);
                if (this.clickSimulation.isEnabled()) {
                    ClientMain.getMouseSimulation().mouseClick(0);
                }
                this.reset();
                return;
            }
            class_239 hitResult = AutoCrystal.mc.field_1765;
            if (hitResult instanceof class_3966) {
                class_3966 hit = (class_3966) hitResult;
                class_1297 entity2 = hit.method_17782();
                if (entity2 instanceof class_1511) {
                    class_1511 crystalEntity = (class_1511) entity2;

                    if (this.sync.isEnabled() && !this.serverCrystals.contains(crystalEntity.method_5628())) {
                        return;
                    }

                    AutoCrystal.mc.field_1761.method_2918(AutoCrystal.mc.field_1724, crystalEntity);
                    AutoCrystal.mc.field_1724.method_6104(class_1268.field_5808);

                    if (this.clickSimulation.isEnabled()) {
                        ClientMain.getMouseSimulation().mouseClick(0);
                    }
                    this.reset();
                } else {
                    entity2 = hit.method_17782();
                    if (entity2 instanceof class_1589) {
                        class_1589 magmaCube = (class_1589)entity2;
                        AutoCrystal.mc.field_1761.method_2918((class_1657)AutoCrystal.mc.field_1724, (class_1297)magmaCube);
                        AutoCrystal.mc.field_1724.method_6104(class_1268.field_5808);
                        this.reset();
                    } else {
                        entity2 = hit.method_17782();
                        if (entity2 instanceof class_1621) {
                            class_1621 slime = (class_1621)entity2;
                            AutoCrystal.mc.field_1761.method_2918((class_1657)AutoCrystal.mc.field_1724, (class_1297)slime);
                            AutoCrystal.mc.field_1724.method_6104(class_1268.field_5808);
                            this.reset();
                        }
                    }
                }
            }
            if (this.antiweakness.isEnabled() && AutoCrystal.mc.field_1724.method_31548().field_7545 != originalSlot) {
                AutoCrystal.mc.field_1724.method_31548().field_7545 = originalSlot;
            }
        }
    }

    private void switchToSword() {
        for (int i = 0; i < 9; ++i) {
            class_1799 stack = AutoCrystal.mc.field_1724.method_31548().method_5438(i);
            if (!this.isSword(stack)) continue;
            AutoCrystal.mc.field_1724.method_31548().field_7545 = i;
            break;
        }
    }

    private boolean hasWeakness() {
        class_1293 weakness = AutoCrystal.mc.field_1724.method_6112(class_1294.field_5911);
        return weakness != null;
    }

    private boolean damageTick() {
        boolean anyPlayerMatches = AutoCrystal.mc.field_1687.method_18456().parallelStream().filter(e -> e != AutoCrystal.mc.field_1724).filter(e -> e.method_5858((class_1297)AutoCrystal.mc.field_1724) < 36.0).filter(e -> e.method_49107() == null).filter(e -> !e.method_24828()).anyMatch(e -> e.field_6235 >= 2);
        return anyPlayerMatches && !(AutoCrystal.mc.field_1724.method_6052() instanceof class_1657);
    }

    private boolean isSword(class_1799 stack) {
        return stack.method_7909() instanceof class_1829;
    }

    @EventHandler
    public void onPacket(PacketEvent.Send e) {
        class_2596<?> packet = e.getPacket();
        if (packet instanceof class_2824) {
            class_2824 interactPacket = (class_2824)packet;
            interactPacket.method_34209(new class_2824.class_5908(){

                public void method_34219(class_1268 hand) {
                }

                public void method_34220(class_1268 hand, class_243 pos) {
                }

                public void method_34218() {
                    class_3966 entityHitResult;
                    class_1297 entity;
                    class_239 hitResult = mc.field_1765;
                    if (hitResult == null) {
                        return;
                    }
                    if (hitResult.method_17783() == class_239.class_240.field_1331 && (entity = (entityHitResult = (class_3966)hitResult).method_17782()) instanceof class_1511) {
                        class_1293 weakness = mc.field_1724.method_6112(class_1294.field_5911);
                        class_1293 strength = mc.field_1724.method_6112(class_1294.field_5910);
                        if (!(weakness == null || strength != null && strength.method_5578() > weakness.method_5578() || AutoCrystal.this.isTool(mc.field_1724.method_6047()))) {
                            return;
                        }
                        entity.method_5768();
                        entity.method_31745(class_1297.class_5529.field_26998);
                        entity.method_36209();
                    }
                }
            });
        }
    }

    @EventHandler
    public void onPacketReceive(PacketEvent.Receive event) {
        class_2596<?> packet = event.getPacket();
        if (packet instanceof class_2716) {
            class_2716 destroyPacket = (class_2716) packet;
            for (int id : destroyPacket.method_36548()) {
                this.serverCrystals.remove(id);
            }
        }
    }


    @EventHandler
    public void onEntitySpawn(EntitySpawnEvent event) {
        if (event.getEntity() instanceof class_1511) {
            this.lastEntityId = event.getEntity().method_5628();
            this.serverCrystals.add(event.getEntity().method_5628());
        }
    }

    public boolean passedTicks(double time) {
        return this.tickTimer >= time;
    }

    private boolean isTool(class_1799 itemStack) {
        if (!(itemStack.method_7909() instanceof class_1831) || itemStack.method_7909() instanceof class_1794) {
            return false;
        }
        class_1832 material = ((class_1831)itemStack.method_7909()).method_8022();
        return material == class_1834.field_8930 || material == class_1834.field_22033;
    }

    public void reset() {
        this.tickTimer = 0.0;
    }

    @Override
    public void onWorldRender(class_4587 matrices) {
        if (this.modeSetting.isMode("Blatant")) {
            this.placeCrystal();
            this.breakCrystal();
        }
    }

    @Override
    public void onTick() {
        if (this.activeOnRightClick.isEnabled() && !KeyUtils.isKeyPressed(this.activateKey.getKey())) {
            return;
        }
        if (this.hurtTimePredict.isEnabled() && this.damageTick()) {
            return;
        }
        if (this.stopOnKill.isEnabled() && EntityUtils.isDeadBodyNearby()) {
            return;
        }
        this.tickTimer = AutoCrystal.nullCheck() ? (this.tickTimer += 1.0) : 0.0;
        if (this.modeSetting.isMode("Normal") && AutoCrystal.mc.field_1755 == null) {
            this.placeCrystal();
            this.breakCrystal();
        }
        this.tickTimer += 1.0;
    }

    @EventHandler
    public void onExplosion(EndCrystalExplosionMcPlayerEvent e) {
        this.placeCrystal();
    }

    @Override
    public void onDisable() {
        this.lastEntityId = -1;
        this.serverCrystals.clear();
    }

    private void predict() {
        if (this.lastEntityId == -1) {
            return;
        }
        int predictedId = this.lastEntityId + 1;
        this.serverCrystals.add(predictedId);
        this.lastEntityId = predictedId;
    }
}
