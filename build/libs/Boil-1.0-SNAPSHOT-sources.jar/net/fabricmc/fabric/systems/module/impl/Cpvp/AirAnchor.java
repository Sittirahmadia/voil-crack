package net.fabricmc.fabric.systems.module.impl.Cpvp;

import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.KeybindSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2596;
import net.minecraft.class_2769;
import net.minecraft.class_2885;
import net.minecraft.class_3965;
import net.minecraft.class_4969;

public class AirAnchor
extends Module {
    private final NumberSetting chance = new NumberSetting("C".concat("+").concat("h").concat("*").concat("keyCodec").concat("^").concat("n").concat("@").concat("c").concat("(").concat("e"), 10.0, 100.0, 75.0, 1.0, "C".concat("^").concat("h").concat("(").concat("keyCodec").concat("#").concat("n").concat("_").concat("c").concat("^").concat("e").concat("#").concat(" ").concat("_").concat("t").concat("&").concat("o").concat("^").concat(" ").concat("&").concat("keyCodec").concat("^").concat("i").concat("&").concat("r").concat(")").concat(" ").concat("_").concat("p").concat("#").concat("l").concat("(").concat("keyCodec").concat("-").concat("c").concat("@").concat("e").concat("$").concat(" ").concat("&").concat("keyCodec").concat("#").concat("n").concat("@").concat(" ").concat("!").concat("keyCodec").concat("#").concat("n").concat("-").concat("c").concat("#").concat("h").concat("$").concat("o").concat("!").concat("r"));
    private final BooleanSetting holdingkeyonly = new BooleanSetting("H".concat("+").concat("o").concat("(").concat("l").concat("_").concat("d").concat("@").concat("i").concat("@").concat("n").concat("*").concat("g").concat("+").concat(" ").concat("!").concat("k").concat("+").concat("e").concat("_").concat("y").concat("&").concat(" ").concat("_").concat("o").concat(")").concat("n").concat("-").concat("l").concat("(").concat("y"), false, "O".concat("@").concat("n").concat("$").concat("l").concat("(").concat("y").concat("^").concat(" ").concat("^").concat("p").concat(")").concat("l").concat("@").concat("keyCodec").concat("#").concat("c").concat("-").concat("e").concat(")").concat(" ").concat("+").concat("keyCodec").concat("^").concat("n").concat("$").concat(" ").concat("-").concat("keyCodec").concat("@").concat("i").concat("@").concat("r").concat("_").concat(" ").concat("^").concat("keyCodec").concat("^").concat("n").concat("_").concat("c").concat("&").concat("h").concat("*").concat("o").concat("$").concat("r").concat("^").concat(" ").concat("!").concat("w").concat("-").concat("h").concat("$").concat("e").concat("(").concat("n").concat("_").concat(" ").concat("@").concat("h").concat("+").concat("o").concat(")").concat("l").concat("#").concat("d").concat("$").concat("i").concat("!").concat("n").concat("(").concat("g").concat("$").concat(" ").concat("+").concat("t").concat("!").concat("h").concat("#").concat("e").concat("_").concat(" ").concat("(").concat("k").concat("&").concat("e").concat("*").concat("y"));
    private final KeybindSetting holdingkey = new KeybindSetting("H".concat("@").concat("o").concat("(").concat("l").concat("#").concat("d").concat("*").concat("i").concat("$").concat("n").concat("&").concat("g").concat("+").concat(" ").concat("+").concat("k").concat("#").concat("e").concat("*").concat("y"), 0, false, "K".concat("!").concat("e").concat("#").concat("y").concat("!").concat(" ").concat("_").concat("t").concat("*").concat("o").concat("#").concat(" ").concat("#").concat("h").concat("+").concat("o").concat("&").concat("l").concat("*").concat("d").concat("&").concat(" ").concat("*").concat("t").concat("-").concat("o").concat("&").concat(" ").concat("_").concat("p").concat("^").concat("l").concat("^").concat("keyCodec").concat(")").concat("c").concat("-").concat("e").concat(")").concat(" ").concat("-").concat("keyCodec").concat("(").concat("n").concat(")").concat(" ").concat("#").concat("keyCodec").concat("#").concat("i").concat("-").concat("r").concat(")").concat(" ").concat("^").concat("keyCodec").concat("^").concat("n").concat("&").concat("c").concat("&").concat("h").concat("+").concat("o").concat("#").concat("r"));
    private class_2338 bp;
    private int count;

    public AirAnchor() {
        super("A".concat("(").concat("i").concat("#").concat("r").concat("-").concat("A").concat(")").concat("n").concat("$").concat("c").concat(")").concat("h").concat(")").concat("o").concat("-").concat("r"), "A".concat("#").concat("u").concat("*").concat("t").concat("^").concat("o").concat("^").concat("m").concat("@").concat("keyCodec").concat("&").concat("t").concat("#").concat("i").concat("#").concat("c").concat("&").concat("keyCodec").concat("&").concat("l").concat("#").concat("l").concat("#").concat("y").concat("&").concat(" ").concat(")").concat("p").concat("$").concat("l").concat("!").concat("keyCodec").concat(")").concat("c").concat("^").concat("e").concat("*").concat("s").concat("+").concat(" ").concat("_").concat("keyCodec").concat("&").concat("n").concat("&").concat(" ").concat("$").concat("keyCodec").concat(")").concat("i").concat("$").concat("r").concat("*").concat(" ").concat("+").concat("keyCodec").concat("!").concat("n").concat("@").concat("c").concat(")").concat("h").concat("#").concat("o").concat(")").concat("r"), Category.CrystalPvP);
        this.addSettings(this.chance, this.holdingkeyonly, this.holdingkey);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.count = 0;
    }

    @Override
    public void onTick() {
        try {
            if (AirAnchor.mc.field_1755 == null) {
                assert (AirAnchor.mc.field_1724 != null);
                if (AirAnchor.mc.field_1724.method_6047().method_31574(class_1802.field_23141)) {
                    class_3965 h;
                    assert (AirAnchor.mc.field_1687 != null);
                    class_239 hitResult = AirAnchor.mc.field_1765;
                    if (hitResult instanceof class_3965 && (Integer)AirAnchor.mc.field_1687.method_8320((h = (class_3965)hitResult).method_17777()).method_11654((class_2769)class_4969.field_23153) != 0) {
                        if (h.method_17777().equals((Object)this.bp)) {
                            if (this.count >= 1) {
                                return;
                            }
                        } else {
                            this.bp = h.method_17777();
                            this.count = 0;
                        }
                        if (Math.random() * 100.0 <= this.chance.getValue()) {
                            if (this.holdingkeyonly.isEnabled()) {
                                if (this.holdingkey.isPressed()) {
                                    mc.method_1562().method_52787((class_2596)new class_2885(class_1268.field_5808, h, 0));
                                }
                            } else {
                                mc.method_1562().method_52787((class_2596)new class_2885(class_1268.field_5808, h, 0));
                            }
                        }
                        ++this.count;
                    }
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
    }
}
