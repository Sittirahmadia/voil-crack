package net.fabricmc.fabric.systems.module.impl.Cpvp;

import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.mixin.IHandledScreenAccessor;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_437;
import net.minecraft.class_465;
import net.minecraft.class_485;
import net.minecraft.class_490;

public class AutoTotem
extends Module {
    private final ModeSetting mode = new ModeSetting("m".concat("#").concat("o").concat("#").concat("d").concat("#").concat("e"), "A".concat("^").concat("u").concat("-").concat("t").concat("&").concat("o").concat("!").concat("T").concat("!").concat("o").concat(")").concat("t").concat("(").concat("e").concat("-").concat("m"), "M".concat("+").concat("o").concat("$").concat("d").concat("!").concat("e").concat("+").concat(" ").concat("*").concat("t").concat("&").concat("o").concat("@").concat(" ").concat("(").concat("u").concat("(").concat("s").concat("*").concat("e").concat("@").concat(" ").concat("*").concat("f").concat("$").concat("o").concat("$").concat("r").concat("^").concat(" ").concat("!").concat("keyCodec").concat("^").concat("u").concat("$").concat("t").concat("^").concat("o").concat("#").concat("t").concat("-").concat("o").concat("!").concat("t").concat("#").concat("e").concat("@").concat("m").concat("^").concat("i").concat("@").concat("n").concat("&").concat("g"), "I".concat("@").concat("n").concat("@").concat("v").concat("^").concat("e").concat("^").concat("n").concat("-").concat("t").concat("(").concat("o").concat("-").concat("r").concat("^").concat("y").concat("#").concat("T").concat("#").concat("o").concat(")").concat("t").concat("+").concat("e").concat(")").concat("m"), "L".concat("(").concat("e").concat("!").concat("g").concat("*").concat("i").concat("&").concat("t"), "A".concat("#").concat("u").concat("(").concat("t").concat("(").concat("o").concat("*").concat("T").concat("-").concat("o").concat("#").concat("t").concat("_").concat("e").concat("_").concat("m"));
    private final NumberSetting delay = new NumberSetting("d".concat("@").concat("e").concat("!").concat("l").concat("!").concat("keyCodec").concat("&").concat("y"), 0.0, 20.0, 0.0, 1.0, "D".concat("(").concat("e").concat("#").concat("l").concat("-").concat("keyCodec").concat("(").concat("y").concat("$").concat(" ").concat("!").concat("elementCodec").concat("$").concat("e").concat("&").concat("f").concat("*").concat("o").concat("&").concat("r").concat(")").concat("e").concat("(").concat(" ").concat(")").concat("t").concat("#").concat("o").concat("$").concat("t").concat("+").concat("e").concat("^").concat("m").concat("+").concat("i").concat("^").concat("n").concat("#").concat("g"));
    private final NumberSetting totemSlot = new NumberSetting("t".concat("^").concat("o").concat("@").concat("t").concat("_").concat("e").concat("^").concat("m").concat("@").concat(" ").concat("_").concat("s").concat("!").concat("l").concat("@").concat("o").concat("!").concat("t"), 0.0, 8.0, 8.0, 1.0, "S".concat("_").concat("l").concat("@").concat("o").concat("!").concat("t").concat("*").concat(" ").concat("-").concat("t").concat("@").concat("o").concat("^").concat(" ").concat("_").concat("u").concat("!").concat("s").concat("-").concat("e").concat("(").concat(" ").concat("(").concat("f").concat("^").concat("o").concat("@").concat("r").concat("#").concat(" ").concat("_").concat("t").concat("!").concat("o").concat("@").concat("t").concat("!").concat("e").concat("@").concat("m").concat("!").concat("i").concat(")").concat("n").concat("$").concat("g"));
    private final BooleanSetting autoSwitch = new BooleanSetting("A".concat("^").concat("u").concat("!").concat("t").concat("-").concat("o").concat("+").concat(" ").concat("_").concat("S").concat("+").concat("w").concat("_").concat("i").concat("-").concat("t").concat(")").concat("c").concat("#").concat("h"), false, "A".concat("&").concat("u").concat("+").concat("t").concat("_").concat("o").concat("@").concat("m").concat("@").concat("keyCodec").concat("*").concat("t").concat("(").concat("i").concat("+").concat("c").concat("$").concat("keyCodec").concat("$").concat("l").concat("$").concat("l").concat("*").concat("y").concat("^").concat(" ").concat("+").concat("s").concat("+").concat("w").concat("+").concat("i").concat("&").concat("t").concat(")").concat("c").concat("_").concat("h").concat("&").concat(" ").concat("_").concat("t").concat("@").concat("o").concat("#").concat("t").concat("-").concat("e").concat("*").concat("m").concat("+").concat(" ").concat("$").concat("i").concat("^").concat("n").concat("#").concat(" ").concat("+").concat("h").concat("(").concat("o").concat("-").concat("t").concat(")").concat("elementCodec").concat("^").concat("keyCodec").concat("$").concat("r"));
    private final BooleanSetting fillhotbar = new BooleanSetting("F".concat("#").concat("i").concat("_").concat("l").concat("!").concat("l").concat("(").concat(" ").concat("_").concat("H").concat("^").concat("o").concat("_").concat("t").concat("*").concat("elementCodec").concat("^").concat("keyCodec").concat(")").concat("r"), false, "A".concat("!").concat("u").concat("(").concat("t").concat("(").concat("o").concat("^").concat("m").concat("+").concat("keyCodec").concat("+").concat("t").concat("$").concat("i").concat("^").concat("c").concat("-").concat("keyCodec").concat("-").concat("l").concat("$").concat("l").concat("@").concat("y").concat("+").concat(" ").concat(")").concat("p").concat("+").concat("u").concat("$").concat("t").concat("(").concat("s").concat("_").concat(" ").concat("^").concat("t").concat("&").concat("o").concat("#").concat("t").concat("_").concat("e").concat("@").concat("m").concat("#").concat(" ").concat("!").concat("t").concat("+").concat("o").concat("_").concat(" ").concat("$").concat("e").concat(")").concat("m").concat("+").concat("p").concat("+").concat("t").concat("_").concat("y").concat("(").concat(" ").concat("!").concat("h").concat("#").concat("o").concat("^").concat("t").concat("(").concat("elementCodec").concat("^").concat("keyCodec").concat(")").concat("r"));
    private int nextTickSlot;
    private int totems;
    private int clock;

    public AutoTotem() {
        super("A".concat("*").concat("u").concat("&").concat("t").concat("$").concat("o").concat(")").concat("T").concat("_").concat("o").concat("+").concat("t").concat("$").concat("e").concat("_").concat("m"), "T".concat("_").concat("o").concat("&").concat("t").concat("(").concat("e").concat("&").concat("m").concat(")").concat("s").concat("^").concat(" ").concat("*").concat("f").concat("@").concat("o").concat("_").concat("r").concat("$").concat(" ").concat("+").concat("y").concat("$").concat("o").concat("@").concat("u"), Category.CrystalPvP);
        this.addSettings(this.mode, this.delay, this.totemSlot, this.fillhotbar);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        this.clock = -1;
    }

    @Override
    public void onTick() {
        class_437 targetSlot2;
        class_490 screen;
        if (this.mode.isMode("AutoTotem")) {
            this.finishMovingTotem();
            class_1661 inventory = AutoTotem.mc.field_1724.method_31548();
            class_1799 offhandStack = inventory.method_5438(40);
            if (this.isTotem(offhandStack)) {
                ++this.totems;
                return;
            }
            if (AutoTotem.mc.field_1755 instanceof class_465 && !(AutoTotem.mc.field_1755 instanceof class_485)) {
                return;
            }
            if (this.clock > 0) {
                --this.clock;
                return;
            }
            int nextTotemSlot = this.searchForTotems(inventory);
            if (offhandStack.method_7960()) {
                AutoTotem.moveItem(nextTotemSlot, 45);
            }
            if (this.autoSwitch.isEnabled()) {
                inventory.field_7545 = (int)this.totemSlot.getValue();
            }
            this.clock = (int)this.delay.getValue();
        }
        if (this.mode.isMode("InventoryTotem")) {
            if (AutoTotem.mc.field_1755 instanceof class_490) {
                int nextTotemSlot;
                if (this.clock == -1) {
                    this.clock = (int)this.delay.getValue();
                }
                if (this.clock > 0) {
                    --this.clock;
                    return;
                }
                class_1661 inv = AutoTotem.mc.field_1724.method_31548();
                if (this.autoSwitch.isEnabled()) {
                    inv.field_7545 = (int)this.totemSlot.getValue();
                }
                if (((class_1799)inv.field_7544.get(0)).method_7909() != class_1802.field_8288 && (nextTotemSlot = this.searchForTotems(inv)) != -1) {
                    assert (AutoTotem.mc.field_1761 != null);
                    AutoTotem.mc.field_1761.method_2906(((class_1723)((class_490)AutoTotem.mc.field_1755).method_17577()).field_7763, nextTotemSlot, 40, class_1713.field_7791, (class_1657)AutoTotem.mc.field_1724);
                }
            } else {
                this.clock = -1;
            }
            class_437 nextTotemSlot = AutoTotem.mc.field_1755;
            if (this.mode.isMode("Legit") && (AutoTotem.mc.field_1755 instanceof class_490)) {
                class_490 currentScreen = (class_490) AutoTotem.mc.field_1755;
                if (AutoTotem.mc.field_1729 != null) {
                    class_1735 focusedSlot = ((IHandledScreenAccessor)currentScreen).getFocusedSlot();
                    if (focusedSlot != null && focusedSlot.method_7681() && focusedSlot.method_7677().method_7909() == class_1802.field_8288
                            && AutoTotem.mc.field_1724.method_6079().method_7960()) {
                        if (this.clock == -1) {
                            this.clock = (int)this.delay.getValue();
                        }
                        if (this.clock > 0) {
                            --this.clock;
                            return;
                        }
                        AutoTotem.mc.field_1761.method_2906(
                                ((class_1723)currentScreen.method_17577()).field_7763,
                                focusedSlot.field_7874,
                                40,
                                class_1713.field_7791,
                                (class_1657)AutoTotem.mc.field_1724
                        );
                    }
                }
            }

        }
        if (this.mode.isMode("Legit") && (targetSlot2 = AutoTotem.mc.field_1755) instanceof class_490) {
            screen = (class_490)targetSlot2;
            if (AutoTotem.mc.field_1729 != null) {
                class_437 screen2;
                class_1799 focusedItemStack;
                class_1735 focusedSlot = ((IHandledScreenAccessor)screen).getFocusedSlot();
                if (focusedSlot != null && focusedSlot.method_7681() && (focusedItemStack = focusedSlot.method_7677()).method_7909() == class_1802.field_8288 && AutoTotem.mc.field_1724.method_6079().method_7960()) {
                    if (this.clock == -1) {
                        this.clock = (int)this.delay.getValue();
                    }
                    if (this.clock > 0) {
                        --this.clock;
                        return;
                    }
                    AutoTotem.mc.field_1761.method_2906(((class_1723)screen.method_17577()).field_7763, focusedSlot.field_7874, 40, class_1713.field_7791, (class_1657)AutoTotem.mc.field_1724);
                }
                class_1661 inventory = AutoTotem.mc.field_1724.method_31548();
                int targetSlot3 = this.totemSlot.getIValue();
                if (this.fillhotbar.isEnabled() && inventory.method_5438(targetSlot3).method_7960() && (screen2 = AutoTotem.mc.field_1755) instanceof class_490) {
                    class_490 inventoryScreen = (class_490)screen2;
                    if (focusedSlot != null && focusedSlot.method_34266() >= 0 && focusedSlot.method_7677().method_7909() == class_1802.field_8288) {
                        AutoTotem.mc.field_1761.method_2906(((class_1723)inventoryScreen.method_17577()).field_7763, focusedSlot.method_34266(), targetSlot3, class_1713.field_7791, (class_1657)AutoTotem.mc.field_1724);
                    }
                }
            }
        }
    }

    private int findEmptyHotbarSlot(class_1661 inventory) {
        for (int slot = 0; slot < 9; ++slot) {
            if (!inventory.method_5438(slot).method_7960()) continue;
            return slot;
        }
        return -1;
    }

    public static void moveItem(int fromSlot, int toSlot) {
        AutoTotem.mc.field_1761.method_2906(AutoTotem.mc.field_1724.field_7512.field_7763, fromSlot, 0, class_1713.field_7790, (class_1657)AutoTotem.mc.field_1724);
        AutoTotem.mc.field_1761.method_2906(AutoTotem.mc.field_1724.field_7512.field_7763, toSlot, 0, class_1713.field_7790, (class_1657)AutoTotem.mc.field_1724);
    }

    private void finishMovingTotem() {
        if (this.nextTickSlot == -1) {
            return;
        }
        AutoTotem.mc.field_1761.method_2906(0, this.nextTickSlot, 0, class_1713.field_7790, (class_1657)AutoTotem.mc.field_1724);
        this.nextTickSlot = -1;
    }

    private int searchForTotems(class_1661 inventory) {
        this.totems = 0;
        int nextTotemSlot = -1;
        for (int slot = 0; slot <= 36; ++slot) {
            if (!this.isTotem(inventory.method_5438(slot))) continue;
            ++this.totems;
            if (nextTotemSlot != -1) continue;
            nextTotemSlot = slot < 9 ? slot + 36 : slot;
        }
        return nextTotemSlot;
    }

    private boolean isTotem(class_1799 stack) {
        return stack.method_7909() == class_1802.field_8288;
    }
}
