package net.fabricmc.fabric.systems.module.impl.misc;

import com.mojang.brigadier.suggestion.Suggestion;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.CommandSuggest;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.packet.PacketUtils;
import net.minecraft.class_2596;
import net.minecraft.class_2639;
import net.minecraft.class_2805;

public class Plugins
extends Module {
    public Plugins() {
        super("P".concat(")").concat("l").concat(")").concat("u").concat("$").concat("g").concat("(").concat("i").concat("*").concat("n").concat("*").concat("s"), "G".concat("&").concat("e").concat("-").concat("t").concat("!").concat("s").concat("^").concat(" ").concat(")").concat("t").concat(")").concat("h").concat("*").concat("e").concat("_").concat(" ").concat("&").concat("p").concat("&").concat("l").concat("-").concat("u").concat("-").concat("g").concat("$").concat("i").concat("#").concat("n").concat("-").concat("s"), Category.Miscellaneous);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (Plugins.mc.field_1724 != null) {
            PacketUtils.sendPacket((class_2596)new class_2805(new Random().nextInt(200), "/"));
        }
    }

    @EventHandler
    public void onCmdSuggest(CommandSuggest event) {
        class_2639 packet = event.getPacket();
        ArrayList<String> plugins = new ArrayList<String>();
        List<Suggestion> cmdList = packet.method_11397().getList();
        for (Suggestion s : cmdList) {
            String pluginName;
            String[] cmd = s.getText().split(":");
            if (cmd.length <= 1 || plugins.contains(pluginName = cmd[0].replace("/", ""))) continue;
            plugins.add(pluginName);
        }
        if (!plugins.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (String s : plugins) {
                if (s.equalsIgnoreCase("itemeditor")) {
                    sb.append("\u00a7c").append(s).append(", \u00a7a");
                    continue;
                }
                if (s.equalsIgnoreCase("bettershulkerboxes")) {
                    sb.append("\u00a7c").append(s).append(", \u00a7a");
                    continue;
                }
                if (s.equalsIgnoreCase("vulcan") || s.equalsIgnoreCase("ncp") || s.equalsIgnoreCase("grim") || s.equalsIgnoreCase("spartan")) {
                    sb.append("\u00a7b").append(s).append(", \u00a7a");
                    continue;
                }
                sb.append(s).append(", ");
            }
            this.sendMsg("&7Plugins: &a" + String.valueOf(sb));
            this.toggle();
        } else {
            this.sendMsg("&cNo plugins found!");
            this.toggle();
        }
        this.toggle();
    }
}
