package net.fabricmc.fabric.systems.module.impl.Cpvp;

import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.AttackEntityEvent;
import net.fabricmc.fabric.api.astral.events.PacketEvent;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.packet.PacketUtils;
import net.minecraft.class_1297;
import net.minecraft.class_1802;
import net.minecraft.class_2596;
import net.minecraft.class_2848;

public class TotemHit
extends Module {
    private boolean lastSprintState = false;
    private boolean shouldReSprint;

    public TotemHit() {
        super("T".concat("^").concat("o").concat("(").concat("t").concat("*").concat("e").concat("$").concat("m").concat("!").concat("H").concat("&").concat("i").concat("_").concat("t"), "S".concat("!").concat("t").concat(")").concat("i").concat("-").concat("l").concat(")").concat("l").concat("+").concat(" ").concat("+").concat("d").concat("!").concat("e").concat("@").concat("keyCodec").concat("-").concat("l").concat("+").concat("s").concat("_").concat(" ").concat("^").concat("k").concat("-").concat("elementCodec").concat("#").concat(" ").concat("^").concat("w").concat("_").concat("h").concat("-").concat("e").concat("$").concat("n").concat("_").concat(" ").concat("#").concat("u").concat("!").concat("s").concat("!").concat("i").concat("-").concat("n").concat(")").concat("g").concat("-").concat(" ").concat("_").concat("t").concat("*").concat("o").concat("&").concat("t").concat("(").concat("e").concat("_").concat("m"), Category.CrystalPvP);
    }

    @EventHandler
    public void onAttackPre(AttackEntityEvent.Pre event) {
        if (TotemHit.mc.field_1687 == null || TotemHit.mc.field_1724 == null) {
            return;
        }
        if (!TotemHit.mc.field_1724.method_6047().method_31574(class_1802.field_8288) && !this.canSprint()) {
            return;
        }
        this.shouldReSprint = this.lastSprintState;
        if (this.lastSprintState) {
            PacketUtils.sendPacket((class_2596)new class_2848((class_1297)TotemHit.mc.field_1724, class_2848.class_2849.field_12985));
        }
        PacketUtils.sendPacket((class_2596)new class_2848((class_1297)TotemHit.mc.field_1724, class_2848.class_2849.field_12981));
    }

    @EventHandler
    public void onAttackPost(AttackEntityEvent.Post event) {
        if (TotemHit.mc.field_1687 == null || TotemHit.mc.field_1724 == null) {
            return;
        }
        if (!TotemHit.mc.field_1724.method_6047().method_31574(class_1802.field_8288) && !this.canSprint()) {
            return;
        }
        PacketUtils.sendPacket((class_2596)new class_2848((class_1297)TotemHit.mc.field_1724, class_2848.class_2849.field_12985));
        if (this.shouldReSprint) {
            PacketUtils.sendPacket((class_2596)new class_2848((class_1297)TotemHit.mc.field_1724, class_2848.class_2849.field_12981));
        }
    }

    @EventHandler
    private void onPacket(PacketEvent.Send event) {
        class_2596<?> packet = event.getPacket();
        if (packet instanceof class_2848) {
            class_2848 packet2 = (class_2848)packet;
            switch (packet2.method_12365()) {
                case field_12981: {
                    this.lastSprintState = true;
                    break;
                }
                case field_12985: {
                    this.lastSprintState = false;
                    break;
                }
            }
        }
    }

    private boolean canSprint() {
        return TotemHit.mc.field_1724.method_7344().method_7586() > 6;
    }
}
