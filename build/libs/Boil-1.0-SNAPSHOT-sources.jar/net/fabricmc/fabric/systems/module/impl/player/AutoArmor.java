package net.fabricmc.fabric.systems.module.impl.player;

import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.KeybindSetting;
import net.fabricmc.fabric.gui.setting.ModeSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.key.KeyUtils;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.minecraft.class_1661;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_490;
import net.minecraft.class_7225;
import net.minecraft.class_7924;

public class AutoArmor
extends Module {
    ModeSetting mode = new ModeSetting("M".concat("+").concat("o").concat("_").concat("d").concat("@").concat("e"), "o".concat("@").concat("n").concat("!").concat("K").concat("#").concat("e").concat("_").concat("y"), "A".concat("!").concat("u").concat(")").concat("t").concat("(").concat("o").concat("#").concat("m").concat("*").concat("keyCodec").concat("!").concat("t").concat("_").concat("i").concat("+").concat("c").concat("-").concat("keyCodec").concat("#").concat("l").concat(")").concat("l").concat("_").concat("y").concat("^").concat(" ").concat("*").concat("e").concat("_").concat("q").concat("_").concat("u").concat("+").concat("i").concat("@").concat("p").concat("#").concat("s").concat("(").concat(" ").concat("^").concat("keyCodec").concat("#").concat("r").concat("*").concat("m").concat("#").concat("o").concat("(").concat("r").concat("@").concat(" ").concat(")").concat("o").concat("@").concat("n").concat("$").concat("k").concat("_").concat("e").concat("-").concat("y").concat("@").concat(" ").concat("!").concat("o").concat("&").concat("r").concat("^").concat(" ").concat(")").concat("w").concat("#").concat("h").concat("#").concat("e").concat("*").concat("n").concat("^").concat(" ").concat("-").concat("i").concat("+").concat("n").concat("^").concat("v").concat("(").concat(" ").concat("_").concat("o").concat("^").concat("p").concat("@").concat("e").concat("#").concat("n"), "o".concat("(").concat("n").concat("(").concat("K").concat("^").concat("e").concat("-").concat("y"), "o".concat("+").concat("n").concat(")").concat("I").concat("$").concat("n").concat("*").concat("v").concat("^").concat("e").concat("^").concat("n").concat("@").concat("t").concat("(").concat("o").concat("+").concat("r").concat("+").concat("y"));
    KeybindSetting activateKey = new KeybindSetting("A".concat(")").concat("c").concat("-").concat("t").concat("&").concat("i").concat("(").concat("v").concat("@").concat("keyCodec").concat("+").concat("t").concat("@").concat("e"), 0, false, "K".concat("(").concat("e").concat("^").concat("y").concat("^").concat("elementCodec").concat("!").concat("i").concat("!").concat("n").concat("@").concat("d").concat("-").concat(" ").concat("_").concat("t").concat("#").concat("o").concat("$").concat(" ").concat("^").concat("u").concat("_").concat("s").concat(")").concat("e"));
    BooleanSetting throwjunk = new BooleanSetting("T".concat("_").concat("h").concat("-").concat("r").concat("@").concat("o").concat("$").concat("w").concat("@").concat(" ").concat("&").concat("J").concat("@").concat("u").concat("$").concat("n").concat("*").concat("k"), true, "T".concat("+").concat("o").concat("*").concat(" ").concat("$").concat("t").concat("!").concat("h").concat("@").concat("r").concat("!").concat("o").concat("*").concat("w").concat("@").concat(" ").concat("@").concat("j").concat("!").concat("u").concat("&").concat("n").concat("*").concat("k").concat("#").concat(" ").concat("*").concat("keyCodec").concat("^").concat("r").concat(")").concat("m").concat("!").concat("o").concat("(").concat("r"));

    public AutoArmor() {
        super("A".concat("#").concat("u").concat("-").concat("t").concat("#").concat("o").concat("-").concat("A").concat("_").concat("r").concat("-").concat("m").concat("+").concat("o").concat("(").concat("r"), "A".concat("+").concat("u").concat("^").concat("t").concat("!").concat("o").concat("!").concat("m").concat(")").concat("keyCodec").concat(")").concat("t").concat("_").concat("i").concat("+").concat("c").concat("@").concat("keyCodec").concat("_").concat("l").concat("$").concat("l").concat("&").concat("y").concat("-").concat(" ").concat(")").concat("e").concat(")").concat("q").concat("-").concat("u").concat("-").concat("i").concat("#").concat("p").concat("(").concat("s").concat("@").concat(" ").concat(")").concat("keyCodec").concat("*").concat("r").concat("$").concat("m").concat("&").concat("o").concat("!").concat("r"), Category.Player);
        this.addSettings(this.mode, this.activateKey);
    }

    public boolean shouldEquipArmor() {
        if (this.mode.getMode().equals("onKey")) {
            return KeyUtils.isKeyPressed(this.activateKey.getKey());
        }
        if (this.mode.getMode().equals("onInventory")) {
            return AutoArmor.mc.field_1755 instanceof class_490;
        }
        return false;
    }

    public boolean isWearingBestArmor(class_1799[] bestArmor) {
        class_1661 playerInventory = AutoArmor.mc.field_1724.method_31548();
        for (int i = 0; i < 4; ++i) {
            class_1799 equippedArmor = (class_1799)playerInventory.field_7548.get(i);
            if (bestArmor[i].equals(equippedArmor)) continue;
            return false;
        }
        return true;
    }

    @Override
    public void onTick() {
        if (AutoArmor.mc.field_1724 == null) {
            return;
        }
        if (!this.shouldEquipArmor()) {
            return;
        }
        class_1661 playerInventory = AutoArmor.mc.field_1724.method_31548();
        class_1799[] currentArmor = new class_1799[]{(class_1799)playerInventory.field_7548.get(3), (class_1799)playerInventory.field_7548.get(2), (class_1799)playerInventory.field_7548.get(1), (class_1799)playerInventory.field_7548.get(0)};
        class_1799[] bestArmor = new class_1799[]{(class_1799)playerInventory.field_7548.get(3), (class_1799)playerInventory.field_7548.get(2), (class_1799)playerInventory.field_7548.get(1), (class_1799)playerInventory.field_7548.get(0)};
        int[] bestArmorSlot = new int[]{36, 37, 38, 39};
        for (int slot = 0; slot < playerInventory.field_7547.size(); ++slot) {
            class_1799 itemStack = playerInventory.method_5438(slot);
            class_1792 item = itemStack.method_7909();
            if (!(item instanceof class_1738)) continue;
            class_1738 armorItem = (class_1738)item;
            int index = 3 - (switch (armorItem.method_48398()) {
                case class_1738.class_8051.field_41934 -> 3;
                case class_1738.class_8051.field_41935 -> 2;
                case class_1738.class_8051.field_41936 -> 1;
                case class_1738.class_8051.field_41937 -> 0;
                default -> -1;
            });
            class_1799 bestArmorPiece = bestArmor[index];
            if (bestArmorPiece.method_7909() instanceof class_1738) {
                if (!InventoryUtils.isArmorBetter(bestArmorPiece, itemStack, (class_7225<class_1887>)((class_7225)AutoArmor.mc.field_1724.method_56673().method_30530(class_7924.field_41265)))) continue;
                bestArmor[index] = itemStack;
                bestArmorSlot[index] = slot;
                continue;
            }
            bestArmor[index] = itemStack;
            bestArmorSlot[index] = slot;
        }
        for (int i = 0; i < 4; ++i) {
            if (bestArmor[i].equals(playerInventory.field_7548.get(i))) continue;
            InventoryUtils.move().from(bestArmorSlot[i]).toArmor(Math.abs(i - 3));
        }
    }
}
