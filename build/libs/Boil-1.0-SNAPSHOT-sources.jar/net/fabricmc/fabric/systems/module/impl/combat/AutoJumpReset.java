package net.fabricmc.fabric.systems.module.impl.combat;

import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.math.MathUtil;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_465;

public class AutoJumpReset
extends Module {
    private final NumberSetting jumpResetChance = new NumberSetting("J".concat("@").concat("u").concat("+").concat("m").concat("@").concat("p").concat("&").concat(" ").concat("^").concat("R").concat("&").concat("e").concat("^").concat("s").concat("!").concat("e").concat("_").concat("t").concat("#").concat(" ").concat("&").concat("C").concat("(").concat("h").concat("&").concat("keyCodec").concat(")").concat("n").concat("_").concat("c").concat("!").concat("e"), 1.0, 100.0, 50.0, 1.0, "C".concat("+").concat("h").concat("$").concat("keyCodec").concat("*").concat("n").concat("-").concat("c").concat("*").concat("e").concat("^").concat(" ").concat("-").concat("t").concat("&").concat("o").concat("-").concat(" ").concat("-").concat("j").concat("&").concat("u").concat("_").concat("m").concat("^").concat("p").concat("@").concat(" ").concat("-").concat("o").concat("@").concat("n").concat("#").concat(" ").concat("!").concat("h").concat("-").concat("i").concat("!").concat("t"));

    public AutoJumpReset() {
        super("A".concat("$").concat("u").concat("!").concat("t").concat("!").concat("o").concat(")").concat("J").concat("(").concat("u").concat("_").concat("m").concat("#").concat("p").concat("+").concat("R").concat("#").concat("e").concat("_").concat("s").concat("$").concat("e").concat("#").concat("t"), "A".concat("#").concat("u").concat("#").concat("t").concat("(").concat("o").concat("_").concat("m").concat("$").concat("keyCodec").concat("&").concat("t").concat("&").concat("i").concat("$").concat("c").concat("$").concat("keyCodec").concat("^").concat("l").concat("-").concat("l").concat("_").concat("y").concat("+").concat(" ").concat("$").concat("j").concat("(").concat("u").concat("$").concat("m").concat("*").concat("p").concat("^").concat("s").concat("*").concat(" ").concat("^").concat("o").concat("(").concat("n").concat("(").concat(" ").concat("+").concat("h").concat("*").concat("i").concat("&").concat("t"), Category.Combat);
        this.addSettings(this.jumpResetChance);
    }

    @Override
    public void onTick() {
        this.setSuffix(this.jumpResetChance.getIValue());
        if (AutoJumpReset.mc.field_1724 == null) {
            return;
        }
        if (AutoJumpReset.mc.field_1724.method_6039()) {
            return;
        }
        if (AutoJumpReset.mc.field_1724.method_6115()) {
            return;
        }
        if (AutoJumpReset.mc.field_1755 instanceof class_465) {
            return;
        }
        if (!AutoJumpReset.mc.field_1724.method_24828()) {
            return;
        }
        if (AutoJumpReset.mc.field_1724.field_6254 == 0) {
            return;
        }
        if (AutoJumpReset.mc.field_1724.field_6235 == 0) {
            return;
        }
        if (AutoJumpReset.mc.field_1724.method_5816()) {
            return;
        }
        if (AutoJumpReset.mc.field_1724.method_5757()) {
            return;
        }
        if (AutoJumpReset.mc.field_1724.method_5799()) {
            return;
        }
        if (!this.isInCombat()) {
            return;
        }
        if (AutoJumpReset.mc.field_1724.field_6235 == AutoJumpReset.mc.field_1724.field_6254 - 1 && MathUtil.getRandomInt(0, 100) <= this.jumpResetChance.getIValue()) {
            AutoJumpReset.mc.field_1724.method_6043();
        }
    }

    private boolean isInCombat() {
        assert (AutoJumpReset.mc.field_1687 != null);
        for (class_1657 player : AutoJumpReset.mc.field_1687.method_18456()) {
            if (player.method_31549().field_7477 || player == AutoJumpReset.mc.field_1724 || !player.method_5805() || !(player.method_5739((class_1297)AutoJumpReset.mc.field_1724) <= 6.0f)) continue;
            return true;
        }
        return false;
    }
}
