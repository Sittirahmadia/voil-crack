package net.fabricmc.fabric.systems.module.impl.combat;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.gui.setting.NumberSetting;
import net.fabricmc.fabric.managers.SocialManager;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.math.TimerUtils;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.fabricmc.fabric.utils.world.WorldUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_465;

public class AutoStun
extends Module {
    private final NumberSetting hitDelay = new NumberSetting("H".concat("+").concat("i").concat("$").concat("t").concat("*").concat(" ").concat("*").concat("D").concat("&").concat("e").concat("+").concat("l").concat("&").concat("keyCodec").concat("(").concat("y"), 0.0, 500.0, 0.0, 1.0, "D".concat("-").concat("e").concat(")").concat("l").concat("@").concat("keyCodec").concat("!").concat("y").concat("@").concat(" ").concat("+").concat("t").concat("@").concat("o").concat("(").concat(" ").concat("@").concat("elementCodec").concat("(").concat("r").concat("_").concat("e").concat(")").concat("keyCodec").concat("+").concat("k").concat("!").concat(" ").concat("&").concat("s").concat("(").concat("h").concat(")").concat("i").concat("@").concat("e").concat("*").concat("l").concat("(").concat("d"));
    private final NumberSetting switchDelay = new NumberSetting("S".concat(")").concat("w").concat("+").concat("i").concat("(").concat("t").concat("+").concat("c").concat("&").concat("h").concat("$").concat(" ").concat("^").concat("D").concat("*").concat("e").concat("$").concat("l").concat("&").concat("keyCodec").concat("^").concat("y"), 0.0, 500.0, 0.0, 1.0, "D".concat("^").concat("e").concat("-").concat("l").concat("(").concat("keyCodec").concat(")").concat("y").concat("^").concat(" ").concat(")").concat("t").concat("*").concat("o").concat("!").concat(" ").concat("+").concat("s").concat("(").concat("w").concat("(").concat("i").concat("+").concat("t").concat("!").concat("c").concat("^").concat("h").concat("*").concat(" ").concat("*").concat("elementCodec").concat("$").concat("keyCodec").concat("*").concat("c").concat("@").concat("k").concat("!").concat(" ").concat("!").concat("t").concat("!").concat("o").concat("^").concat(" ").concat("-").concat("o").concat("#").concat("l").concat("+").concat("d").concat("*").concat(" ").concat("!").concat("s").concat("$").concat("l").concat("+").concat("o").concat("^").concat("t"));
    private final NumberSetting chance = new NumberSetting("C".concat("&").concat("h").concat(")").concat("keyCodec").concat("-").concat("n").concat("!").concat("c").concat("&").concat("e"), 0.0, 100.0, 100.0, 1.0, "C".concat("$").concat("h").concat("#").concat("keyCodec").concat("-").concat("n").concat("&").concat("c").concat("$").concat("e").concat("!").concat(" ").concat("@").concat("t").concat(")").concat("o").concat("-").concat(" ").concat("*").concat("p").concat("$").concat("e").concat("#").concat("r").concat("*").concat("f").concat("!").concat("o").concat("^").concat("r").concat("@").concat("m").concat("!").concat(" ").concat("^").concat("keyCodec").concat("_").concat("c").concat("$").concat("t").concat("&").concat("i").concat("#").concat("o").concat("!").concat("n"));
    private final BooleanSetting switchBack = new BooleanSetting("S".concat("_").concat("w").concat("(").concat("i").concat(")").concat("t").concat("@").concat("c").concat("_").concat("h").concat("&").concat(" ").concat("@").concat("B").concat("*").concat("keyCodec").concat("+").concat("c").concat("(").concat("k").concat("*").concat(" ").concat("+").concat("t").concat("!").concat("o").concat("(").concat(" ").concat("_").concat("P").concat("(").concat("r").concat("&").concat("e").concat("+").concat("v").concat("-").concat("i").concat("_").concat("o").concat("(").concat("u").concat("!").concat("s").concat("_").concat(" ").concat("_").concat("S").concat("(").concat("l").concat("#").concat("o").concat(")").concat("t"), true, "S".concat("&").concat("w").concat("*").concat("i").concat("_").concat("t").concat("@").concat("c").concat("*").concat("h").concat("-").concat("e").concat("@").concat("s").concat("$").concat(" ").concat("$").concat("elementCodec").concat("@").concat("keyCodec").concat("$").concat("c").concat("^").concat("k").concat("!").concat(" ").concat("&").concat("t").concat("#").concat("o").concat("!").concat(" ").concat("@").concat("o").concat("^").concat("l").concat("-").concat("d").concat("#").concat(" ").concat("$").concat("s").concat("*").concat("l").concat(")").concat("o").concat("+").concat("t").concat("^").concat(" ").concat("*").concat("keyCodec").concat("@").concat("f").concat("^").concat("t").concat("!").concat("e").concat(")").concat("r").concat("$").concat(" ").concat("^").concat("elementCodec").concat(")").concat("r").concat("@").concat("e").concat("$").concat("keyCodec").concat("@").concat("k").concat("(").concat("i").concat("*").concat("n").concat("@").concat("g").concat("+").concat(" ").concat("@").concat("s").concat("$").concat("h").concat(")").concat("i").concat("^").concat("e").concat(")").concat("l").concat("@").concat("d"));
    private final BooleanSetting block = new BooleanSetting("C".concat("$").concat("keyCodec").concat("#").concat("n").concat("(").concat("c").concat(")").concat("e").concat("*").concat("l").concat("!").concat(" ").concat("-").concat("W").concat("@").concat("h").concat("_").concat("i").concat("$").concat("l").concat("(").concat("e").concat("^").concat(" ").concat("*").concat("B").concat("_").concat("l").concat("&").concat("o").concat("!").concat("c").concat("@").concat("k").concat(")").concat("i").concat(")").concat("n").concat("*").concat("g"), true, "C".concat("+").concat("keyCodec").concat("#").concat("n").concat("@").concat("c").concat("&").concat("e").concat("_").concat("l").concat("#").concat(" ").concat("_").concat("w").concat("(").concat("h").concat("&").concat("i").concat("-").concat("l").concat("#").concat("e").concat("(").concat(" ").concat("*").concat("elementCodec").concat("(").concat("l").concat("+").concat("o").concat("@").concat("c").concat("@").concat("k").concat("$").concat("i").concat("*").concat("n").concat("&").concat("g").concat("@").concat(",").concat("(").concat("e").concat("(").concat("keyCodec").concat("!").concat("t").concat("(").concat("i").concat("(").concat("n").concat("+").concat("g"));
    private final BooleanSetting clickSimulation = new BooleanSetting("C".concat("+").concat("l").concat("_").concat("i").concat("(").concat("c").concat("&").concat("k").concat("&").concat(" ").concat(")").concat("S").concat("+").concat("i").concat("(").concat("m").concat("&").concat("u").concat("#").concat("l").concat("*").concat("keyCodec").concat("^").concat("t").concat("$").concat("i").concat("@").concat("o").concat("@").concat("n"), true, "S".concat("(").concat("i").concat("^").concat("m").concat("$").concat("u").concat("$").concat("l").concat("!").concat("keyCodec").concat("#").concat("t").concat("*").concat("e").concat("@").concat("s").concat(")").concat(" ").concat("!").concat("c").concat("$").concat("l").concat("^").concat("i").concat("^").concat("c").concat("+").concat("k").concat("@").concat("s").concat("-").concat(" ").concat("^").concat("w").concat("#").concat("h").concat("@").concat("i").concat("^").concat("l").concat("_").concat("e").concat("$").concat(" ").concat("+").concat("elementCodec").concat("*").concat("r").concat("&").concat("e").concat("@").concat("keyCodec").concat(")").concat("k").concat("&").concat("i").concat("!").concat("n").concat("+").concat("g").concat("(").concat(" ").concat("#").concat("s").concat("(").concat("h").concat("*").concat("i").concat("-").concat("e").concat("@").concat("l").concat("!").concat("d"));
    private final TimerUtils actionTimer = new TimerUtils();
    private final TimerUtils swapBackTimer = new TimerUtils();
    private int oldSlot = -1;
    private boolean swapped = false;
    private boolean attacked = false;
    private class_1657 lastTarget = null;
    class_1297 target;

    public AutoStun() {
        super("A".concat("*").concat("u").concat("-").concat("t").concat(")").concat("o").concat("+").concat("S").concat("#").concat("t").concat("$").concat("u").concat("(").concat("n"), "A".concat("-").concat("u").concat("@").concat("t").concat("@").concat("o").concat("@").concat("m").concat("-").concat("keyCodec").concat("@").concat("t").concat("@").concat("i").concat("#").concat("c").concat("(").concat("keyCodec").concat("^").concat("l").concat("@").concat("l").concat("-").concat("y").concat("$").concat(" ").concat("(").concat("elementCodec").concat("$").concat("r").concat("_").concat("e").concat("$").concat("keyCodec").concat("*").concat("k").concat("@").concat("s").concat("#").concat(" ").concat("(").concat("s").concat("#").concat("h").concat(")").concat("i").concat(")").concat("e").concat("$").concat("l").concat("(").concat("d"), Category.Combat);
        this.addSettings(this.hitDelay, this.switchDelay, this.chance, this.switchBack, this.block, this.clickSimulation);
    }

    @Override
    public void onEnable() {
        this.resetState();
    }

    @Override
    public void onDisable() {
        if (this.switchBack.isEnabled() && this.oldSlot != -1) {
            AutoStun.mc.field_1724.method_31548().field_7545 = this.oldSlot;
        }
        this.oldSlot = -1;
        super.onDisable();
    }

    @Override
    public void onTick() {
        if (AutoStun.mc.field_1724 == null || AutoStun.mc.field_1755 != null || AutoStun.mc.field_1692 == null) {
            return;
        }
        if (AutoStun.mc.field_1724.method_6039() && this.block.isEnabled()) {
            return;
        }
        if (AutoStun.mc.field_1724.method_6115() && this.block.isEnabled()) {
            return;
        }
        if (AutoStun.mc.field_1755 instanceof class_465) {
            return;
        }
        if (this.targetUsingShield()) {
            if (SocialManager.isFriend(this.target.method_5667()) || SocialManager.isTeammate(this.target.method_5667())) {
                return;
            }
            if (Math.random() * 100.0 > this.chance.getValue()) {
                return;
            }
            if (!this.swapped) {
                this.oldSlot = AutoStun.mc.field_1724.method_31548().field_7545;
                if (this.selectAxe()) {
                    this.swapped = true;
                    this.actionTimer.reset();
                }
            }
            if (this.swapped && this.actionTimer.hasReached(this.hitDelay.getValue())) {
                AutoStun.mc.field_1761.method_2918((class_1657)AutoStun.mc.field_1724, this.target);
                AutoStun.mc.field_1724.method_6104(class_1268.field_5808);
                this.attacked = true;
                this.actionTimer.reset();
                if (this.clickSimulation.isEnabled()) {
                    ClientMain.getMouseSimulation().mouseClick(0);
                }
            }
            if (this.attacked && this.switchBack.isEnabled() && this.swapBackTimer.hasReached(this.switchDelay.getIValue())) {
                AutoStun.mc.field_1724.method_31548().field_7545 = this.oldSlot;
                this.resetState();
            }
        } else {
            if (this.swapped) {
                AutoStun.mc.field_1724.method_31548().field_7545 = this.oldSlot;
            }
            this.resetState();
        }
    }

    private boolean selectAxe() {
        for (int i = 0; i < 9; ++i) {
            class_1799 itemStack = AutoStun.mc.field_1724.method_31548().method_5438(i);
            class_1792 item = itemStack.method_7909();
            if (!this.isAxe(item)) continue;
            AutoStun.mc.field_1724.method_31548().field_7545 = i;
            return true;
        }
        return false;
    }

    private boolean isAxe(class_1792 item) {
        return item instanceof class_1743 && !InventoryUtils.nameContains("Mace", item.method_7854());
    }

    private boolean targetUsingShield() {
        this.target = AutoStun.mc.field_1692;
        if (this.target instanceof class_1657) {
            class_1657 player = (class_1657)this.target;
            if (SocialManager.isFriend(player.method_5667())) {
                return false;
            }
            if (player.method_6115() && player.method_6030().method_7909() == class_1802.field_8255) {
                return !WorldUtils.isShieldFacingAway(player);
            }
        }
        return false;
    }

    private void resetState() {
        this.oldSlot = -1;
        this.swapped = false;
        this.attacked = false;
        this.lastTarget = null;
        this.actionTimer.reset();
        this.swapBackTimer.reset();
    }
}
