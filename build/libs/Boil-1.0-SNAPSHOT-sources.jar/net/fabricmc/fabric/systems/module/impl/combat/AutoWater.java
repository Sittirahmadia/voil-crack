package net.fabricmc.fabric.systems.module.impl.combat;

import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.systems.module.impl.player.NoSlow;
import net.fabricmc.fabric.utils.player.InventoryUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2596;
import net.minecraft.class_2886;
import net.minecraft.class_310;

public class AutoWater
extends Module {
    private BooleanSetting waterInWeb = new BooleanSetting("W".concat("$").concat("keyCodec").concat("!").concat("t").concat("@").concat("e").concat("&").concat("r").concat("+").concat(" ").concat("#").concat("i").concat("_").concat("n").concat("@").concat("s").concat("!").concat("i").concat("#").concat("d").concat("_").concat("e").concat("@").concat(" ").concat("+").concat("w").concat("@").concat("e").concat("^").concat("elementCodec"), false, "A".concat("+").concat("u").concat("+").concat("t").concat(")").concat("o").concat("&").concat("m").concat("#").concat("keyCodec").concat("&").concat("t").concat("(").concat("i").concat("$").concat("c").concat("&").concat("keyCodec").concat(")").concat("l").concat("-").concat("l").concat("!").concat("y").concat("@").concat(" ").concat("+").concat("p").concat("(").concat("l").concat("#").concat("keyCodec").concat(")").concat("c").concat("!").concat("e").concat("$").concat("s").concat("^").concat(" ").concat("_").concat("w").concat("&").concat("keyCodec").concat("#").concat("t").concat("@").concat("e").concat("@").concat("r").concat("_").concat(" ").concat("^").concat("i").concat("-").concat("n").concat("-").concat("s").concat("_").concat("i").concat("$").concat("d").concat("@").concat("e").concat("^").concat(" ").concat("(").concat("w").concat("@").concat("e").concat("^").concat("elementCodec").concat("@").concat("s"));
    private int tickTimer = 0;
    private final class_310 mc = class_310.method_1551();

    public AutoWater() {
        super("A".concat(")").concat("u").concat("&").concat("t").concat("&").concat("o").concat(")").concat("W").concat("^").concat("keyCodec").concat("*").concat("t").concat(")").concat("e").concat("$").concat("r"), "A".concat("-").concat("u").concat("+").concat("t").concat("_").concat("o").concat("*").concat("m").concat("*").concat("keyCodec").concat("(").concat("t").concat("(").concat("i").concat("(").concat("c").concat("!").concat("keyCodec").concat(")").concat("l").concat("^").concat("l").concat(")").concat("y").concat("&").concat(" ").concat(")").concat("p").concat(")").concat("l").concat("(").concat("keyCodec").concat("(").concat("c").concat("@").concat("e").concat("$").concat("s").concat("-").concat(" ").concat("^").concat("w").concat("*").concat("keyCodec").concat("$").concat("t").concat("&").concat("e").concat("+").concat("r").concat("$").concat(" ").concat("-").concat("w").concat("+").concat("h").concat("_").concat("e").concat("&").concat("n").concat("$").concat(" ").concat("^").concat("y").concat("-").concat("o").concat("^").concat("u").concat("!").concat("r").concat("_").concat(" ").concat("!").concat("o").concat("+").concat("n").concat("!").concat(" ").concat("(").concat("f").concat("-").concat("i").concat("^").concat("r").concat("$").concat("e"), Category.Combat);
        this.addSettings(this.waterInWeb);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public void onTick() {
        boolean shouldPlaceWater;
        if (!this.isEnabled()) {
            return;
        }
        if (this.mc.field_1724.method_6059(class_1294.field_5918)) {
            return;
        }
        boolean bl = shouldPlaceWater = this.mc.field_1724.method_5809() || this.waterInWeb.isEnabled() && NoSlow.doesBoxTouchBlock(this.mc.field_1724.method_5829(), class_2246.field_10343);
        if (shouldPlaceWater) {
            ++this.tickTimer;
            try {
                this.mc.field_1724.method_36457(90.0f);
                if (!InventoryUtils.swap(class_1802.field_8705)) return;
                this.mc.method_1562().method_52787((class_2596)new class_2886(class_1268.field_5808, 0, this.mc.field_1724.method_36454(), this.mc.field_1724.method_36455()));
                return;
            }
            catch (Exception e) {
                throw new RuntimeException(e);
            }
        } else {
            this.tickTimer = 0;
        }
    }
}
