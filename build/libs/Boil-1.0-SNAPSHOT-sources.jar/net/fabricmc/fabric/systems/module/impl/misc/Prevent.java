package net.fabricmc.fabric.systems.module.impl.misc;

import net.fabricmc.fabric.api.astral.EventHandler;
import net.fabricmc.fabric.api.astral.events.ItemUseEvent;
import net.fabricmc.fabric.gui.setting.BooleanSetting;
import net.fabricmc.fabric.systems.module.core.Category;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.world.BlockUtils;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_2246;
import net.minecraft.class_239;
import net.minecraft.class_3965;

public class Prevent
extends Module {
    private static final BooleanSetting preventAnchor = new BooleanSetting("Prevent Anchor", true, "Prevents placing anchor on another empty anchor");
    private static final BooleanSetting preventGlowstone = new BooleanSetting("Prevent Glowstone", true, "Prevents placing glowstone on ground");
    private static final BooleanSetting preventEchest = new BooleanSetting("Prevent Echest", true, "Prevents opening an echest with sword or totem");
    private static final BooleanSetting preventDoubleGlowstone = new BooleanSetting("Prevent DoubleGlowstone", true, "Prevents placing double glowstone on anchor");
    private static final BooleanSetting preventShield = new BooleanSetting("Prevent Shield", true, "Prevents blocking with shield when holding blocks");

    public Prevent() {
        super("P".concat("!").concat("r").concat(")").concat("e").concat("-").concat("v").concat(")").concat("e").concat("$").concat("n").concat("!").concat("t"), "P".concat(")").concat("r").concat("_").concat("e").concat("^").concat("v").concat("&").concat("e").concat("_").concat("n").concat("*").concat("t").concat("!").concat("s").concat("^").concat(" ").concat(")").concat("c").concat("$").concat("e").concat("#").concat("r").concat("^").concat("t").concat("+").concat("keyCodec").concat("-").concat("i").concat("+").concat("n").concat("-").concat(" ").concat("_").concat("keyCodec").concat("$").concat("c").concat("$").concat("t").concat("+").concat("i").concat(")").concat("o").concat("!").concat("n").concat("(").concat("s"), Category.Miscellaneous);
        this.addSettings(preventAnchor, preventGlowstone, preventEchest, preventDoubleGlowstone, preventShield);
    }

    @EventHandler
    public void onItemUse(ItemUseEvent.Pre event) {
        if (Prevent.mc.field_1724 == null || Prevent.mc.field_1687 == null) {
            return;
        }
        class_239 hitResult = Prevent.mc.field_1765;
        if (hitResult instanceof class_3965) {
            class_3965 hit = (class_3965)hitResult;
            if (BlockUtils.isAnchorCharged(hit.method_17777()) && preventDoubleGlowstone.isEnabled() && Prevent.mc.field_1724.method_24518(class_1802.field_8801)) {
                event.cancel();
            }
            if (!BlockUtils.isBlock(class_2246.field_23152, hit.method_17777()) && preventGlowstone.isEnabled() && Prevent.mc.field_1724.method_24518(class_1802.field_8801)) {
                event.cancel();
            }
            if (BlockUtils.isAnchorUncharged(hit.method_17777()) && preventAnchor.isEnabled() && Prevent.mc.field_1724.method_24518(class_1802.field_23141)) {
                event.cancel();
            }
            if (BlockUtils.isBlock(class_2246.field_10443, hit.method_17777()) && preventEchest.isEnabled() && (Prevent.mc.field_1724.method_6047().method_7909() instanceof class_1829 || Prevent.mc.field_1724.method_6047().method_7909() == class_1802.field_8301 || Prevent.mc.field_1724.method_6047().method_7909() == class_1802.field_8281 || Prevent.mc.field_1724.method_6047().method_7909() == class_1802.field_23141 || Prevent.mc.field_1724.method_6047().method_7909() == class_1802.field_8801)) {
                event.cancel();
            }
        }
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
}
