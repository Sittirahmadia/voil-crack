package net.fabricmc.fabric.api.astral.events;

import net.fabricmc.fabric.api.astral.Cancellable;
import net.minecraft.class_1268;

public class HandSwingEvent
extends Cancellable {
    private class_1268 hand;

    public HandSwingEvent(class_1268 hand) {
        this.hand = hand;
    }

    public class_1268 getHand() {
        return this.hand;
    }

    public void setHand(class_1268 hand) {
        this.hand = hand;
    }
}
