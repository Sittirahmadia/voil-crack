package net.fabricmc.fabric.api.astral.events;

import net.fabricmc.fabric.api.astral.Cancellable;
import net.minecraft.class_243;

public class EventPlayerTravel
extends Cancellable {
    private class_243 motionVector;

    public EventPlayerTravel(class_243 motionVector) {
        this.motionVector = motionVector;
    }

    public class_243 getMotionVector() {
        return this.motionVector;
    }

    public static class Post
    extends EventPlayerTravel {
        public Post(class_243 motionVector) {
            super(motionVector);
        }
    }

    public static class Pre
    extends EventPlayerTravel {
        public Pre(class_243 motionVector) {
            super(motionVector);
        }
    }
}
