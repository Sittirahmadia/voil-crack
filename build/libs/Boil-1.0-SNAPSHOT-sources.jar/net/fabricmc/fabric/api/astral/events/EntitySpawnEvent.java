package net.fabricmc.fabric.api.astral.events;

import net.fabricmc.fabric.api.astral.Cancellable;
import net.minecraft.class_1297;

public class EntitySpawnEvent
extends Cancellable {
    private final class_1297 entity;

    public EntitySpawnEvent(class_1297 entity) {
        this.entity = entity;
    }

    public class_1297 getEntity() {
        return this.entity;
    }
}
