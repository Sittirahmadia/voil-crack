package net.fabricmc.fabric.api.astral.events;

import net.minecraft.class_4587;

public class WorldRenderEvent {
    private static final WorldRenderEvent INSTANCE = new WorldRenderEvent();
    public class_4587 matrices;
    public float tickDelta;

    public static WorldRenderEvent get(class_4587 matrices, float tickDelta) {
        WorldRenderEvent.INSTANCE.matrices = matrices;
        WorldRenderEvent.INSTANCE.tickDelta = tickDelta;
        return INSTANCE;
    }
}
