package net.fabricmc.fabric.api.astral.events;

import net.fabricmc.fabric.api.astral.Cancellable;
import net.minecraft.class_266;
import net.minecraft.class_332;

public class ScoreboardEvent
extends Cancellable {
    public class_332 context;
    public class_266 objective;

    public ScoreboardEvent(class_332 context, class_266 objective) {
        this.context = context;
        this.objective = objective;
    }
}
