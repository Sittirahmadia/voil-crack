package net.fabricmc.fabric.api.astral.events;

import net.fabricmc.fabric.api.astral.Cancellable;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class Render2DEvent
extends Cancellable {
    public class_4587 matrixStack;
    public class_332 context;
    public int scaledWidth;
    public int scaledHeight;

    public Render2DEvent(class_332 context, class_4587 matrixStack, int scaledWidth, int scaledHeight) {
        this.matrixStack = matrixStack;
        this.context = context;
        this.scaledWidth = scaledWidth;
        this.scaledHeight = scaledHeight;
    }

    public class_4587 getMatrixStack() {
        return this.matrixStack;
    }

    public class_332 getContext() {
        return this.context;
    }

    public int getScaledWidth() {
        return this.scaledWidth;
    }

    public int getScaledHeight() {
        return this.scaledHeight;
    }
}
