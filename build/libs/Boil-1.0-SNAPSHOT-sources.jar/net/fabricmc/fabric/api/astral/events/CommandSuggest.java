package net.fabricmc.fabric.api.astral.events;

import net.fabricmc.fabric.api.astral.Cancellable;
import net.minecraft.class_2639;

public class CommandSuggest
extends Cancellable {
    private final class_2639 packet;

    public CommandSuggest(class_2639 packet) {
        this.packet = packet;
    }

    public class_2639 getPacket() {
        return this.packet;
    }

    public static CommandSuggest get(class_2639 packet) {
        return new CommandSuggest(packet);
    }
}
