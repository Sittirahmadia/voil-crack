package net.fabricmc.fabric.api.astral.events;

import net.fabricmc.fabric.api.astral.Cancellable;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public class AttackEntityEvent
        extends Cancellable {
    public class_1297 target;
    public class_1657 player;

    public class_1297 getTarget() {
        return this.target;
    }

    public class_1657 getPlayer() {
        return this.player;
    }

    public static class Post
            extends AttackEntityEvent {
        private static final Post INSTANCE = new Post();

        public static Post get(class_1657 player, class_1297 target) {
            INSTANCE.setCancelled(false);
            Post.INSTANCE.player = player;
            Post.INSTANCE.target = target;
            return INSTANCE;
        }
    }

    public static class Pre
            extends AttackEntityEvent {
        private static final Pre INSTANCE = new Pre();

        public static Pre get(class_1657 player, class_1297 target) {
            INSTANCE.setCancelled(false);
            Pre.INSTANCE.player = player;
            Pre.INSTANCE.target = target;
            return INSTANCE;
        }
    }
}
