package net.fabricmc.fabric.mixin;

import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.systems.module.impl.Client.Spoofer;
import net.minecraft.class_2720;
import net.minecraft.class_310;
import net.minecraft.class_642;
import net.minecraft.class_8705;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_2720.class})
public class ResourcePackSendS2CPacketMixin {
    @Inject(method={"apply(Lnet/minecraft/network/listener/ClientCommonPacketListener;)V"}, at={@At(value="HEAD")}, cancellable=true)
    private void apply(class_8705 clientCommonPacketListener, CallbackInfo ci) {
        class_642 serverInfo;
        if (ModuleManager.INSTANCE.getModuleByClass(Spoofer.class).isEnabled() && ((Spoofer)ModuleManager.INSTANCE.getModuleByClass(Spoofer.class)).resource.isEnabled() && (serverInfo = class_310.method_1551().method_1558()) != null && serverInfo.method_2990() == class_642.class_643.field_3764) {
            ci.cancel();
        }
    }
}
