package net.fabricmc.fabric.mixin;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.events.MoveFixEvent;
import net.fabricmc.fabric.api.astral.events.VelocityEvent;
import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.managers.rotation.Rotation;
import net.fabricmc.fabric.systems.module.impl.combat.Hitboxes;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1297.class})
public abstract class EntityMixin {
    private float bodyYaw;
    @Shadow
    @Final
    private class_1299<?> type;

    @Shadow
    protected abstract class_243 getRotationVector(float var1, float var2);

    @Shadow
    public abstract float getPitch();

    @Shadow
    public abstract float getYaw();

    @Shadow
    private static class_243 movementInputToVelocity(class_243 movementInput, float speed, float yaw) {
        return null;
    }

    @Unique
    private static class_243 movementInputToVelocityC(class_243 movementInput, float speed, float yaw) {
        double d = movementInput.method_1027();
        if (d < 1.0E-7) {
            return class_243.field_1353;
        }
        class_243 vec3d = (d > 1.0 ? movementInput.method_1029() : movementInput).method_1021((double)speed);
        float f = class_3532.method_15374((float)(yaw * ((float)Math.PI / 180)));
        float g = class_3532.method_15362((float)(yaw * ((float)Math.PI / 180)));
        return new class_243(vec3d.field_1352 * (double)g - vec3d.field_1350 * (double)f, vec3d.field_1351, vec3d.field_1350 * (double)g + vec3d.field_1352 * (double)f);
    }

    @Shadow
    public abstract void remove(class_1297.class_5529 var1);

    @Inject(method={"getTargetingMargin"}, at={@At(value="HEAD")}, cancellable=true)
    private void onGetTargetingMargin(CallbackInfoReturnable<Float> info) {
        double v = ((Hitboxes)ModuleManager.INSTANCE.getModuleByClass(Hitboxes.class)).size.getValue();
        if (!ModuleManager.INSTANCE.getModuleByClass(Hitboxes.class).isEnabled()) {
            return;
        }
        info.setReturnValue((float)v);
    }

    @Inject(method={"getRotationVec"}, at={@At(value="HEAD")}, cancellable=true)
    public void injectFakeRotation(float tickDelta, CallbackInfoReturnable<class_243> cir) {
        Rotation rot = ClientMain.getRotationManager().getServerRotation();
        if ((Object)this == class_310.method_1551().field_1724 && rot != null) {
            cir.setReturnValue(this.getRotationVector(rot.getPitch(), rot.getYaw()));
        }
    }

    @Redirect(method={"updateVelocity"}, at=@At(value="INVOKE", target="Lnet/minecraft/entity/Entity;movementInputToVelocity(Lnet/minecraft/util/math/Vec3d;FF)Lnet/minecraft/util/math/Vec3d;"))
    public class_243 updateVelocityInject(class_243 movementInput, float speed, float yaw) {
        if ((Object)this == class_310.method_1551().field_1724) {
            MoveFixEvent eventYawMoveFix = new MoveFixEvent(yaw);
            ClientMain.EVENTBUS.post(eventYawMoveFix);
            yaw = eventYawMoveFix.getYaw();
        }
        return EntityMixin.movementInputToVelocity(movementInput, speed, yaw);
    }

    @Inject(method={"updateVelocity"}, at={@At(value="HEAD")}, cancellable=true)
    public void elementCodec(float speed, class_243 movementInput, CallbackInfo ci) {
        if ((Object)this == ClientMain.mc.field_1724) {
            ci.cancel();
            VelocityEvent event = new VelocityEvent(movementInput, speed, ClientMain.mc.field_1724.method_36454(), EntityMixin.movementInputToVelocityC(movementInput, speed, ClientMain.mc.field_1724.method_36454()));
            ClientMain.EVENTBUS.post(event);
            ClientMain.mc.field_1724.method_18799(ClientMain.mc.field_1724.method_18798().method_1019(event.getVelocity()));
        }
    }
}
