package net.fabricmc.fabric.mixin;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.events.Render2DEvent;
import net.fabricmc.fabric.api.scripting.ScriptAPI;
import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.systems.module.core.HudModule;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.render.RenderHelper;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_329.class})
public class InGameHudMixin {
    @Unique
    public int scaledWidth;
    @Unique
    public int scaledHeight;

    @Inject(method={"render"}, at={@At(value="RETURN")}, cancellable=true)
    public void renderHud(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            for (Module module : ModuleManager.INSTANCE.getEnabledModules()) {
                module.draw(context.method_51448());
                ScriptAPI.getScriptHooks().triggerEvent("onRenderTwoD", ScriptAPI.getScriptEngine());
                if (!(module instanceof HudModule)) continue;
                HudModule hudModule = (HudModule)module;
                hudModule.draw(context);
            }
        }
    }

    @Inject(at={@At(value="HEAD")}, method={"render"}, cancellable=true)
    void render(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        if (!ClientMain.INSTANCE.isSelfDestructed) {
            RenderHelper.setContext(context);
            if (ClientMain.EVENTBUS.post(new Render2DEvent(context, context.method_51448(), this.scaledWidth, this.scaledHeight)).isCancelled()) {
                ci.cancel();
            }
        }
    }
}
