package net.fabricmc.fabric.mixin;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.events.EventPlayerTravel;
import net.fabricmc.fabric.api.astral.events.JumpEvent;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1657.class})
public class PlayerEntityMixin {
    @Inject(method={"jump"}, at={@At(value="HEAD")})
    private void onJumpPre(CallbackInfo ci) {
        ClientMain.EVENTBUS.post(JumpEvent.Pre.get());
    }

    @Inject(method={"jump"}, at={@At(value="RETURN")})
    private void onJumpPost(CallbackInfo ci) {
        ClientMain.EVENTBUS.post(JumpEvent.Post.get());
    }

    @Inject(method={"travel"}, at={@At(value="HEAD")}, cancellable=true)
    private void onTravelhookPre(class_243 movementInput, CallbackInfo ci) {
        if (ClientMain.mc.field_1724 == null) {
            return;
        }
        EventPlayerTravel.Pre event = new EventPlayerTravel.Pre(movementInput);
        ClientMain.EVENTBUS.post(event);
        if (event.isCancelled()) {
            ClientMain.mc.field_1724.method_5784(class_1313.field_6308, ClientMain.mc.field_1724.method_18798());
            ci.cancel();
        }
    }

    @Inject(method={"travel"}, at={@At(value="RETURN")}, cancellable=true)
    private void onTravelhookPost(class_243 movementInput, CallbackInfo ci) {
        if (ClientMain.mc.field_1724 == null) {
            return;
        }
        EventPlayerTravel.Post event = new EventPlayerTravel.Post(movementInput);
        ClientMain.EVENTBUS.post(event);
        if (event.isCancelled()) {
            ClientMain.mc.field_1724.method_5784(class_1313.field_6308, ClientMain.mc.field_1724.method_18798());
            ci.cancel();
        }
    }
}
