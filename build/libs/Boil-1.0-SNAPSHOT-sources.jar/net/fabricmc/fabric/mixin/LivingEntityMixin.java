package net.fabricmc.fabric.mixin;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1309.class})
public class LivingEntityMixin {
    @Inject(method={"consumeItem"}, at={@At(value="HEAD")})
    private void onEatFood(CallbackInfo ci) {
        class_1309 entity = (class_1309)(Object)this;
    }
}
