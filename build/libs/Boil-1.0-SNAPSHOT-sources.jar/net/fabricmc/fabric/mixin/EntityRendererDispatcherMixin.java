package net.fabricmc.fabric.mixin;

import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.systems.module.impl.render.Chams;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_898;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_898.class})
public class EntityRendererDispatcherMixin {
    @Inject(method={"render"}, at={@At(value="RETURN")})
    public <E extends class_1297> void onRenderPost(E entity, double x, double y, double z, float yaw, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        if (entity instanceof class_1657 && ModuleManager.INSTANCE.getModuleByClass(Chams.class).isEnabled()) {
            GL11.glPolygonOffset((float)1.0f, (float)1100000.0f);
            GL11.glDisable((int)32823);
        }
    }

    @Inject(method={"render"}, at={@At(value="HEAD")}, cancellable=true)
    public <E extends class_1297> void onRenderPre(E entity, double x, double y, double z, float yaw, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        if (entity instanceof class_1657 && ModuleManager.INSTANCE.getModuleByClass(Chams.class).isEnabled()) {
            GL11.glEnable((int)32823);
            GL11.glPolygonOffset((float)1.0f, (float)-1100000.0f);
        }
    }
}
