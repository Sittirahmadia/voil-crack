package net.fabricmc.fabric.mixin;

import net.minecraft.class_1011;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_1011.class})
public interface INativeImage {
    @Accessor(value="pointer")
    public long getPointer();
}
