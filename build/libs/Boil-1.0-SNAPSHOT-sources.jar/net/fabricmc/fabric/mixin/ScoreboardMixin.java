package net.fabricmc.fabric.mixin;

import net.minecraft.class_269;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={class_269.class})
public class ScoreboardMixin {
}
