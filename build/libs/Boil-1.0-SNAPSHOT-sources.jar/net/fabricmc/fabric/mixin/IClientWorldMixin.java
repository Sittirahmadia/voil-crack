package net.fabricmc.fabric.mixin;

import net.minecraft.class_638;
import net.minecraft.class_7202;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_638.class})
public interface IClientWorldMixin {
    @Accessor(value="pendingUpdateManager")
    public class_7202 getPendingUpdateManager();
}
