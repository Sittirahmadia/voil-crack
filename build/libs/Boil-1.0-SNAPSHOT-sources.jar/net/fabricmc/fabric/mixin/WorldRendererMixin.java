package net.fabricmc.fabric.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.events.WorldRenderEvent;
import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.systems.module.core.Module;
import net.fabricmc.fabric.utils.render.RenderHelper;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_757.class})
public abstract class WorldRendererMixin {
    @Inject(at={@At(value="FIELD", target="Lnet/minecraft/client/render/GameRenderer;renderHand:Z", opcode=180, ordinal=0)}, method={"renderWorld"})
    private void onWorldRender(class_9779 tickCounter, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        class_4184 camera = mc.field_1773.method_19418();
        class_4587 matrixStack = new class_4587();
        RenderSystem.getModelViewStack().pushMatrix().mul((Matrix4fc)matrixStack.method_23760().method_23761());
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
        RenderSystem.applyModelViewMatrix();
        Matrix4f projectionMatrix = RenderSystem.getProjectionMatrix();
        ClientMain.EVENTBUS.post(WorldRenderEvent.get(matrixStack, tickCounter.method_60637(false)));
        RenderHelper.setMatrixStack(matrixStack);
        for (Module m : ModuleManager.INSTANCE.getModules()) {
            if (!m.isEnabled()) continue;
            m.onWorldRender(matrixStack);
        }
        RenderSystem.getModelViewStack().popMatrix();
        RenderSystem.applyModelViewMatrix();
    }

    @Inject(at={@At(value="FIELD", target="Lnet/minecraft/client/render/GameRenderer;renderHand:Z", opcode=180, ordinal=0)}, method={"renderWorld"})
    void render3dHook(class_9779 tickCounter, CallbackInfo ci) {
        class_4184 camera = ClientMain.mc.field_1773.method_19418();
        class_4587 matrixStack = new class_4587();
        matrixStack.method_22903();
        matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0f));
        RenderSystem.applyModelViewMatrix();
        RenderHelper.setProjectionMatrix(RenderSystem.getProjectionMatrix());
        RenderHelper.setModelViewMatrix(RenderSystem.getModelViewMatrix());
        RenderHelper.setPositionMatrix(matrixStack.method_23760().method_23761());
        RenderSystem.getModelViewStack().pushMatrix();
        RenderSystem.applyModelViewMatrix();
        RenderSystem.getModelViewStack().popMatrix();
    }
}
