package net.fabricmc.fabric.mixin;

import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_636.class})
public interface IClientPlayerInteractionManagerAccessor {
    @Invoker
    public void callSyncSelectedSlot();
}
