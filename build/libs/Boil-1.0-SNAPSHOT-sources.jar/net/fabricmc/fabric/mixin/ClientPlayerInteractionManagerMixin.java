package net.fabricmc.fabric.mixin;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.events.AttackEntityEvent;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_636.class})
public class ClientPlayerInteractionManagerMixin {
    @Inject(method={"attackEntity"}, at={@At(value="HEAD")}, cancellable=true)
    private void preAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        if (ClientMain.EVENTBUS.post(AttackEntityEvent.Pre.get(player, target)).isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method={"attackEntity"}, at={@At(value="TAIL")})
    private void postAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        ClientMain.EVENTBUS.post(AttackEntityEvent.Post.get(player, target));
    }
}
