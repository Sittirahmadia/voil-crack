package net.fabricmc.fabric.mixin;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(value={class_310.class})
public interface IMinecraftClient {
    @Accessor(value="itemUseCooldown")
    public void setItemUseCooldown(int var1);

    @Accessor(value="itemUseCooldown")
    public int getItemUseCooldown();

    @Invoker
    public void invokeDoItemUse();

    @Invoker
    public boolean invokeDoAttack();
}
