package net.fabricmc.fabric.mixin;

import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value={class_465.class})
public interface IHandledScreenAccessor {
    @Accessor
    public class_1735 getFocusedSlot();

    @Accessor
    public void setFocusedSlot(class_1735 var1);
}
