package net.fabricmc.fabric.mixin;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.security.LoginHandler;
import net.fabricmc.fabric.systems.module.impl.render.Cape;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_490;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_742.class})
public class ClientPlayerEntityMixin {
    @Inject(method={"getSkinTextures"}, at={@At(value="HEAD")}, cancellable=true)
    private void onGetCapeTexture(CallbackInfoReturnable<class_2960> info) {
        Cape capeModule = (Cape)ModuleManager.INSTANCE.getModuleByClass(Cape.class);
        if (capeModule.isEnabled() && this.equals(ClientMain.mc.field_1724)) {
            if (ClientMain.mc.field_1755 instanceof class_490) {
                return;
            }
        } else {
            return;
        }
        info.setReturnValue(this.getTexture((class_1657)(Object)this));
    }

    public class_2960 getTexture(class_1657 player) {
        if (player == ClientMain.mc.field_1724) {
            switch (LoginHandler.plan) {
                case "voil+": {
                    return class_2960.method_60655((String)"tulip", (String)"capes/voilplus.png");
                }
                case "media": {
                    return class_2960.method_60655((String)"tulip", (String)"capes/media.png");
                }
                case "beta": {
                    return class_2960.method_60655((String)"tulip", (String)"capes/beta.png");
                }
                case "staff": 
                case "owner": {
                    return class_2960.method_60655((String)"tulip", (String)"capes/staff.png");
                }
            }
            return this.getDefaultCape();
        }
        return this.getDefaultCape();
    }

    public class_2960 getDefaultCape() {
        return class_2960.method_60655((String)"tulip", (String)"textures/capes/default_cape.png");
    }
}
