package net.fabricmc.fabric.mixin;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.api.astral.events.EndCrystalExplosionMcPlayerEvent;
import net.minecraft.class_1282;
import net.minecraft.class_1511;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_1511.class})
public class EntityEnderCrystalMixin {
    @Shadow
    public int endCrystalAge;

    @Inject(method = "crystalDestroyed", at = @At("HEAD"))
    private void onCrystalDestroyed(class_1282 source, CallbackInfo ci) {
        if (source.method_5529() instanceof class_746) {
            if (ClientMain.getInstance().isSelfDestructed) return;

            int crystalId = ((class_1511) (Object) this).method_5628();

            ClientMain.EVENTBUS.post(new EndCrystalExplosionMcPlayerEvent(crystalId));
        }
    }
}
