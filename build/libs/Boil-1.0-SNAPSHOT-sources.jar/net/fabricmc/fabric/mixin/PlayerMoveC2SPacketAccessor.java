package net.fabricmc.fabric.mixin;

import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={class_2828.class})
public abstract class PlayerMoveC2SPacketAccessor {
}
