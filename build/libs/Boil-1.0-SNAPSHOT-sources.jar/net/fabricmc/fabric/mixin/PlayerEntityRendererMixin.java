package net.fabricmc.fabric.mixin;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.systems.module.impl.render.SwingAnimation;
import net.fabricmc.fabric.utils.Utils;
import net.minecraft.class_1007;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1819;
import net.minecraft.class_572;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1007.class})
public abstract class PlayerEntityRendererMixin {
    @Inject(at={@At(value="RETURN")}, method={"getArmPose"}, cancellable=true)
    @Environment(value=EnvType.CLIENT)
    private static void swordblocking$getArmPose(class_742 abstractClientPlayerEntity, class_1268 hand, CallbackInfoReturnable<class_572.class_573> cir) {
        if (!ModuleManager.INSTANCE.getModuleByClass(SwingAnimation.class).isEnabled()) {
            return;
        }
        class_1799 handStack = abstractClientPlayerEntity.method_5998(hand);
        class_1799 offStack = abstractClientPlayerEntity.method_5998(hand.equals((Object)class_1268.field_5808) ? class_1268.field_5810 : class_1268.field_5808);
        if (!(handStack.method_7909() instanceof class_1819) && !Utils.canWeaponBlock((class_1309)abstractClientPlayerEntity)) {
            return;
        }
        if (offStack.method_7909() instanceof class_1819 && abstractClientPlayerEntity.method_6115()) {
            cir.setReturnValue(class_572.class_573.field_3406);
        } else if (handStack.method_7909() instanceof class_1819) {
            cir.setReturnValue(class_572.class_573.field_3409);
        }
    }
}
