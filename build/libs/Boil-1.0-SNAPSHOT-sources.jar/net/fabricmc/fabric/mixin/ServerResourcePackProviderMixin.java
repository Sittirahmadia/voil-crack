package net.fabricmc.fabric.mixin;

import net.minecraft.class_1066;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={class_1066.class})
public class ServerResourcePackProviderMixin {
}
