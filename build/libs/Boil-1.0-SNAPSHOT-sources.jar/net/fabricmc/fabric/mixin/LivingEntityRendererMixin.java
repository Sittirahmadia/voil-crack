package net.fabricmc.fabric.mixin;

import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.command.Command;
import net.minecraft.class_1309;
import net.minecraft.class_583;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(value={class_922.class})
public abstract class LivingEntityRendererMixin<T extends class_1309, M extends class_583<T>> {
    @ModifyVariable(method={"render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"}, ordinal=5, at=@At(value="STORE", ordinal=3))
    public float changePitch(float oldValue, class_1309 entity) {
        if (Command.mc.field_1724 == null) {
            return oldValue;
        }
        if (entity.equals((Object)ClientMain.mc.field_1724) && ClientMain.getRotationManager().isRotating()) {
            return ClientMain.getRotationManager().getServerRotation().getPitch();
        }
        return oldValue;
    }
}
