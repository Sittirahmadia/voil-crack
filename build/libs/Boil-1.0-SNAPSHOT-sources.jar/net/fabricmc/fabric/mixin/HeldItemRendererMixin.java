package net.fabricmc.fabric.mixin;

import net.fabricmc.fabric.managers.ModuleManager;
import net.fabricmc.fabric.systems.module.impl.render.SwingAnimation;
import net.fabricmc.fabric.utils.render.ItemRenderUtil;
import net.fabricmc.fabric.utils.render.Renderer;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1829;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value={class_759.class})
public class HeldItemRendererMixin {
    @Shadow
    private float equipProgressMainHand;
    @Shadow
    private float prevEquipProgressMainHand;
    @Shadow
    private float prevEquipProgressOffHand;
    @Shadow
    private float equipProgressOffHand;
    @Shadow
    private class_1799 mainHand;
    @Shadow
    private class_1799 offHand;
    @Final
    @Shadow
    private class_310 client;

    @Inject(method={"renderFirstPersonItem"}, at={@At(value="HEAD")})
    public void renderItem(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            return;
        }
        if (item.method_7909() instanceof class_1829) {
            ItemRenderUtil.render(mc.field_1724.method_31548().method_7391(), matrices);
        }
    }

    @Inject(method={"updateHeldItems"}, at={@At(value="HEAD")}, cancellable=true)
    public void updateHeldItems(CallbackInfo ci) {
        class_1799 stack;
        if (ModuleManager.INSTANCE.getModuleByClass(SwingAnimation.class).isEnabled() && Renderer.isValid(stack = this.client.field_1724.method_31548().method_7391()) && stack.method_7909() instanceof class_1829) {
            this.equipProgressMainHand = 1.0f;
            this.equipProgressOffHand = 1.0f;
            this.prevEquipProgressMainHand = this.equipProgressMainHand;
            this.prevEquipProgressOffHand = this.equipProgressOffHand;
            class_746 clientPlayerEntity = this.client.field_1724;
            class_1799 itemStack = clientPlayerEntity.method_6047();
            class_1799 itemStack2 = clientPlayerEntity.method_6079();
            this.mainHand = itemStack;
            this.offHand = itemStack2;
            ci.cancel();
        }
    }

    @ModifyVariable(method={"renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"}, at=@At(value="STORE", ordinal=0), index=6)
    private float modifySwingProgress(float value) {
        class_1799 stack;
        if (ModuleManager.INSTANCE.getModuleByClass(SwingAnimation.class).isEnabled() && Renderer.isValid(stack = this.client.field_1724.method_31548().method_7391()) && stack.method_7909() instanceof class_1829) {
            return 0.0f;
        }
        return value;
    }
}
