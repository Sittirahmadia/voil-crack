package net.fabricmc.fabric.mixin;

import java.util.List;
import net.fabricmc.fabric.ClientMain;
import net.fabricmc.fabric.systems.module.impl.Cpvp.AutoCrystal;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1774;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1838;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={class_1774.class})
public class EndCrystalItemMixin {
    @Unique
    private class_243 getPlayerLookVec(class_1657 p) {
        float f = (float)Math.PI / 180;
        float pi = (float)Math.PI;
        float f1 = class_3532.method_15362((float)(-p.method_36454() * f - pi));
        float f2 = class_3532.method_15374((float)(-p.method_36454() * f - pi));
        float f3 = -class_3532.method_15362((float)(-p.method_36455() * f));
        float f4 = class_3532.method_15374((float)(-p.method_36455() * f));
        return new class_243((double)(f2 * f3), (double)f4, (double)(f1 * f3)).method_1029();
    }

    @Unique
    private class_243 getClientLookVec() {
        assert (ClientMain.mc.field_1724 != null);
        return this.getPlayerLookVec((class_1657)ClientMain.mc.field_1724);
    }

    @Unique
    private boolean isBlock(class_2248 b, class_2338 p) {
        return this.getBlockState(p).method_26204() == b;
    }

    @Unique
    private class_2680 getBlockState(class_2338 p) {
        return ClientMain.mc.field_1687.method_8320(p);
    }

    @Unique
    private boolean canPlaceCrystalServer(class_2338 blockPos) {
        class_2680 blockState = ClientMain.mc.field_1687.method_8320(blockPos);
        if (!blockState.method_27852(class_2246.field_10540) && !blockState.method_27852(class_2246.field_9987)) {
            return false;
        }
        class_2338 blockPos2 = blockPos.method_10084();
        if (!ClientMain.mc.field_1687.method_22347(blockPos2)) {
            return false;
        }
        double d = blockPos2.method_10263();
        double e = blockPos2.method_10264();
        double f = blockPos2.method_10260();
        List list = ClientMain.mc.field_1687.method_8335(null, new class_238(d, e, f, d + 1.0, e + 2.0, f + 1.0));
        return list.isEmpty();
    }

    @Inject(method={"useOnBlock"}, at={@At(value="HEAD")})
    private void onUse(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
        class_3965 blockHit2;
        class_2338 pos;
        class_239 hitResult;
        class_243 e;
        class_3965 blockHit;
        class_1799 mainHandStack;
        if (AutoCrystal.nobounce.isEnabled() && ClientMain.mc.field_1724 != null && (mainHandStack = ClientMain.mc.field_1724.method_6047()).method_31574(class_1802.field_8301) && (this.isBlock(class_2246.field_10540, (blockHit = ClientMain.mc.field_1687.method_17742(new class_3959(e = ClientMain.mc.field_1724.method_33571(), e.method_1019(this.getClientLookVec().method_1021(4.5)), class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)ClientMain.mc.field_1724))).method_17777()) || this.isBlock(class_2246.field_9987, blockHit.method_17777())) && (hitResult = ClientMain.mc.field_1765) instanceof class_3965 && this.canPlaceCrystalServer(pos = (blockHit2 = (class_3965)hitResult).method_17777())) {
            context.method_8041().method_7934(-1);
        }
    }
}
